"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  ShieldCheck,
  Printer,
  Maximize2,
  RotateCw,
  QrCode,
  Building2,
  Phone,
  MapPin,
  CheckCircle2,
  XCircle,
  ExternalLink,
  UserCheck,
  CreditCard
} from "lucide-react";
import { cn } from "@/lib/utils";

interface StudentIdCardProps {
  student: {
    fullName: string;
    studentId: string;
    courseCode: string;
    courseName: string;
    academicYear: string;
    semester: number;
    section: string;
    rollNumber: string;
    department: string;
    admissionSession: string;
    dob?: string | null;
    profilePhoto?: string | null;
    registeredMobile?: string | null;
    fatherName?: string | null;
    motherName?: string | null;
    parentContact?: string | null;
    localAddress?: string | null;
  };
}

export function DigitalIdCardView({ student }: StudentIdCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [isMobile, setIsMobile] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  // Check device capabilities and motion settings
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mediaQuery.matches);
    const handleMotionChange = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handleMotionChange);

    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768 || 'ontouchstart' in window);
    };
    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => {
      mediaQuery.removeEventListener("change", handleMotionChange);
      window.removeEventListener("resize", checkMobile);
    };
  }, []);

  // Subtle 3D Tilt calculation (Desktop only)
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isMobile || reducedMotion || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    // Limit to max 3 degrees
    setTilt({ x: y * -6, y: x * 6 });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  const handlePrint = () => {
    window.print();
  };

  const toggleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  // Safe QR Code URL for non-sensitive verification
  const qrVerificationUrl = `https://campusx.local/verify-id/${encodeURIComponent(student.studentId)}`;
  const qrSvgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(
    qrVerificationUrl
  )}&color=0f284e&bgcolor=ffffff`;

  return (
    <div className="space-y-6">
      {/* Print-specific style override */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #printable-id-card-section,
          #printable-id-card-section * {
            visibility: visible !important;
          }
          #printable-id-card-section {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            background: white !important;
            padding: 20px !important;
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            gap: 30px !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>

      {/* Top Header Controls Bar */}
      <div className="no-print flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-6 hairline shadow-sm">
        <div>
          <h1 className="text-xl font-extrabold text-ink sm:text-2xl flex items-center gap-2">
            <ShieldCheck className="h-6 w-6 text-brand" /> Official Digital Student ID Card
          </h1>
          <p className="text-xs text-muted mt-0.5">
            Physical Study Hall College ID Card format rendered digitally from your authenticated record.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Side Toggle Pill */}
          <div className="inline-flex rounded-xl bg-surface-raised p-1 hairline">
            <button
              onClick={() => setIsFlipped(false)}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all",
                !isFlipped ? "bg-brand text-white shadow-xs" : "text-muted hover:text-ink"
              )}
            >
              <CreditCard className="h-3.5 w-3.5" /> Front Side
            </button>
            <button
              onClick={() => setIsFlipped(true)}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all",
                isFlipped ? "bg-brand text-white shadow-xs" : "text-muted hover:text-ink"
              )}
            >
              <RotateCw className="h-3.5 w-3.5" /> Back Side
            </button>
          </div>

          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="flex items-center gap-1.5 rounded-ctl bg-surface hairline px-3.5 py-2 text-xs font-bold text-ink hover:bg-raised transition-all"
            title="Fullscreen view"
          >
            <Maximize2 className="h-4 w-4 text-brand" /> {isFullScreen ? "Exit Fullscreen" : "Fullscreen"}
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 rounded-ctl bg-brand px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-brand-dark transition-all"
            title="Print or Save PDF"
          >
            <Printer className="h-4 w-4" /> Print Physical ID
          </button>
        </div>
      </div>

      {/* Main Interactive Card Container */}
      <div
        className={cn(
          "transition-all duration-300",
          isFullScreen
            ? "fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto"
            : "flex flex-col items-center justify-center py-4"
        )}
      >
        {isFullScreen && (
          <div className="no-print mb-4 flex items-center justify-between w-full max-w-lg px-2 text-white">
            <span className="text-sm font-bold flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-amber-400" /> Fullscreen ID Card Inspector
            </span>
            <button
              onClick={() => setIsFullScreen(false)}
              className="rounded-lg bg-white/20 px-3 py-1 text-xs font-bold hover:bg-white/30 text-white"
            >
              Close (Esc)
            </button>
          </div>
        )}

        {/* Desktop Flip Instruction */}
        <div className="no-print mb-3 text-center">
          <p className="text-[11px] font-semibold text-muted flex items-center justify-center gap-1.5">
            <RotateCw className="h-3.5 w-3.5 text-brand animate-spin-slow" />
            Click or tap card to flip between Front and Back sides
          </p>
        </div>

        {/* Physical ID Card Preview Box */}
        <div
          id="printable-id-card-section"
          className="relative max-w-full"
          style={{ perspective: "1000px" }}
        >
          {/* Card Outer Container */}
          <div
            ref={cardRef}
            tabIndex={0}
            role="button"
            aria-label={`Student ID Card for ${student.fullName}. Click to flip to ${isFlipped ? "Front" : "Back"}.`}
            onClick={toggleFlip}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                toggleFlip();
              }
            }}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="group relative w-[380px] sm:w-[410px] h-[260px] sm:h-[275px] cursor-pointer outline-none focus-visible:ring-4 focus-visible:ring-brand/40 rounded-2xl select-none"
            style={{
              transformStyle: "preserve-3d",
              transform: reducedMotion
                ? undefined
                : `rotateX(${tilt.x}deg) rotateY(${tilt.y + (isFlipped ? 180 : 0)}deg)`,
              transition: reducedMotion
                ? "none"
                : "transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.3s border-color 0.3s",
            }}
          >
            {/* Lanyard Hole Clip Graphic */}
            <div className="no-print absolute -top-3.5 left-1/2 -translate-x-1/2 z-30 w-12 h-3.5 rounded-full bg-slate-300 border-2 border-slate-400 shadow-inner flex items-center justify-center">
              <div className="w-8 h-1.5 rounded-full bg-slate-700/80" />
            </div>

            {/* ==================== FRONT SIDE ==================== */}
            <div
              className={cn(
                "absolute inset-0 w-full h-full rounded-2xl bg-white border-2 border-slate-300 shadow-2xl overflow-hidden flex flex-col justify-between transition-opacity duration-300",
                isFlipped && reducedMotion ? "opacity-0 pointer-events-none" : "opacity-100"
              )}
              style={{ backfaceVisibility: "hidden" }}
            >
              {/* Top College Header */}
              <div className="bg-white px-3 pt-2.5 pb-1 flex items-center justify-between border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <img
                    src="/brand/shc-logo.png"
                    alt="Study Hall College Logo"
                    className="h-9 sm:h-10 w-auto object-contain"
                    onError={(e) => {
                      // Fallback text logo if image fails
                      (e.target as HTMLElement).style.display = "none";
                    }}
                  />
                  <div>
                    <h2 className="text-xs sm:text-sm font-black tracking-tight text-[#0f284e] uppercase leading-none font-serif">
                      STUDY HALL COLLEGE
                    </h2>
                    <p className="text-[8.5px] sm:text-[9.5px] text-[#0f284e]/80 font-bold leading-tight mt-0.5">
                      LUCKNOW • <span className="font-medium text-slate-600">Affiliated to University of Lucknow</span>
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="rounded bg-blue-50 border border-blue-200 px-1.5 py-0.5 text-[9px] font-black text-[#0f284e] uppercase tracking-wider">
                    STUDENT
                  </span>
                </div>
              </div>

              {/* Identity Title Bar */}
              <div className="bg-[#0f284e] text-white py-1 px-3 flex items-center justify-between text-[10px] sm:text-[11px] font-black tracking-widest uppercase shadow-sm">
                <span>STUDENT IDENTITY CARD</span>
                <span className="text-[9px] font-normal text-amber-300 tracking-normal">
                  SESS: {student.admissionSession}
                </span>
              </div>

              {/* Main Content Area */}
              <div className="flex-1 p-2.5 sm:p-3 flex items-start gap-3 bg-gradient-to-b from-white via-slate-50/50 to-white">
                {/* Student Photo */}
                <div className="shrink-0 flex flex-col items-center">
                  <div className="w-[88px] sm:w-[98px] h-[105px] sm:h-[118px] rounded-md border-2 border-[#0f284e] bg-slate-100 overflow-hidden shadow-sm relative">
                    {student.profilePhoto ? (
                      <img
                        src={student.profilePhoto}
                        alt={student.fullName}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-slate-200 text-[#0f284e]">
                        <div className="w-12 h-12 rounded-full bg-[#0f284e]/10 border border-[#0f284e]/20 flex items-center justify-center font-extrabold text-base mb-1">
                          {student.fullName.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </div>
                        <span className="text-[8px] font-bold text-[#0f284e]/70 uppercase tracking-tighter">STUDENT PHOTO</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Student Details Grid */}
                <div className="min-w-0 flex-1 space-y-1 sm:space-y-1.5 text-[10.5px] sm:text-xs">
                  <div className="leading-tight">
                    <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">NAME OF STUDENT</span>
                    <span className="font-extrabold text-[#0f284e] text-xs sm:text-sm uppercase tracking-wide truncate block">
                      {student.fullName}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-x-2 gap-y-1">
                    <div>
                      <span className="text-[8.5px] text-slate-500 font-bold uppercase block">ID NO.</span>
                      <span className="font-black text-[#0f284e] font-mono tracking-wider text-[11px]">
                        {student.studentId}
                      </span>
                    </div>

                    <div>
                      <span className="text-[8.5px] text-slate-500 font-bold uppercase block">COURSE</span>
                      <span className="font-extrabold text-slate-900 truncate block">
                        {student.courseCode} ({student.courseName.split(" ")[0]})
                      </span>
                    </div>

                    <div>
                      <span className="text-[8.5px] text-slate-500 font-bold uppercase block">YEAR / SEM</span>
                      <span className="font-bold text-slate-800">
                        {student.academicYear} (Sem {student.semester})
                      </span>
                    </div>

                    <div>
                      <span className="text-[8.5px] text-slate-500 font-bold uppercase block">D.O.B.</span>
                      <span className="font-bold text-slate-800">
                        {student.dob || "Not Available"}
                      </span>
                    </div>

                    <div>
                      <span className="text-[8.5px] text-slate-500 font-bold uppercase block">ROLL NO.</span>
                      <span className="font-bold text-slate-800 font-mono">
                        {student.rollNumber}
                      </span>
                    </div>

                    <div>
                      <span className="text-[8.5px] text-slate-500 font-bold uppercase block">SEC / DEPT</span>
                      <span className="font-bold text-slate-800 truncate block">
                        Sec {student.section}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Address & Authority Footer Bar */}
              <div className="bg-[#0f284e] text-white px-3 py-1.5 flex items-center justify-between text-[8px] sm:text-[9px] leading-tight border-t border-amber-400/60">
                <div>
                  <p className="font-semibold text-amber-200">CAMPUS: Pipraghat Road, Opposite Sultanpur Road, Lucknow - 226010</p>
                  <p className="text-white/80">Ph: 0522-2300541 • www.studyhallcollege.org</p>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-serif italic text-amber-300 font-bold text-[10px] leading-none mb-0.5">
                    Authorized
                  </div>
                  <span className="text-[7.5px] uppercase font-bold tracking-widest text-white/90 border-t border-white/30 pt-0.5 block">
                    PRINCIPAL
                  </span>
                </div>
              </div>
            </div>

            {/* ==================== BACK SIDE ==================== */}
            <div
              className={cn(
                "absolute inset-0 w-full h-full rounded-2xl bg-white border-2 border-slate-300 shadow-2xl overflow-hidden flex flex-col justify-between transition-opacity duration-300",
                !isFlipped && reducedMotion ? "opacity-0 pointer-events-none" : "opacity-100"
              )}
              style={{
                backfaceVisibility: "hidden",
                transform: "rotateY(180deg)",
              }}
            >
              {/* Back Top Header */}
              <div className="bg-[#0f284e] text-white py-2 px-3 flex items-center justify-between border-b border-amber-400">
                <div className="flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5 text-amber-300" />
                  <span className="text-xs font-black tracking-wider uppercase font-serif">
                    STUDY HALL COLLEGE
                  </span>
                </div>
                <span className="text-[9.5px] font-bold text-amber-300 uppercase tracking-widest">
                  EMERGENCY & FAMILY DETAILS
                </span>
              </div>

              {/* Back Content Body */}
              <div className="flex-1 p-3 bg-gradient-to-b from-slate-50 to-white flex flex-col justify-between space-y-2 text-[10px] sm:text-[11px]">
                {/* Family & Contact Details List */}
                <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 border-b border-slate-200 pb-2">
                  <div>
                    <span className="text-[8.5px] font-bold text-slate-500 uppercase block">FATHER'S NAME</span>
                    <span className="font-extrabold text-[#0f284e] uppercase truncate block">
                      {student.fatherName || "Not Available"}
                    </span>
                  </div>

                  <div>
                    <span className="text-[8.5px] font-bold text-slate-500 uppercase block">MOTHER'S NAME</span>
                    <span className="font-extrabold text-[#0f284e] uppercase truncate block">
                      {student.motherName || "Not Available"}
                    </span>
                  </div>

                  <div>
                    <span className="text-[8.5px] font-bold text-slate-500 uppercase block">STUDENT MOBILE</span>
                    <span className="font-bold text-slate-900 font-mono">
                      {student.registeredMobile || "Not Available"}
                    </span>
                  </div>

                  <div>
                    <span className="text-[8.5px] font-bold text-slate-500 uppercase block">PARENT CONTACT</span>
                    <span className="font-bold text-slate-900 font-mono">
                      {student.parentContact || "Not Available"}
                    </span>
                  </div>

                  <div className="col-span-2">
                    <span className="text-[8.5px] font-bold text-slate-500 uppercase block">RESIDENTIAL ADDRESS</span>
                    <span className="font-semibold text-slate-800 line-clamp-1">
                      {student.localAddress || "Not Available"}
                    </span>
                  </div>
                </div>

                {/* Physical Card Loss Notice Box */}
                <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-2 text-[9px] leading-tight text-[#0f284e]">
                  <p className="font-black uppercase tracking-wider text-[8.5px] text-amber-900 mb-0.5">
                    NOTICE / IMPORTANT INSTRUCTIONS:
                  </p>
                  <p className="font-medium text-slate-800">
                    • In case of loss of this card, report immediately to the College Administration.
                  </p>
                  <p className="font-medium text-slate-800 mt-0.5">
                    • If found, please return to the address mentioned on front of this card.
                  </p>
                </div>

                {/* Signatures Footer */}
                <div className="flex items-end justify-between pt-1">
                  <div className="text-center w-28">
                    <div className="h-4 border-b border-slate-400" />
                    <span className="text-[8px] font-bold text-slate-500 uppercase tracking-wider block mt-0.5">
                      STUDENT SIGNATURE
                    </span>
                  </div>

                  <div className="text-center w-32">
                    <div className="h-4 border-b border-slate-400 flex items-center justify-center font-serif italic text-[#0f284e] font-bold text-[9px]">
                      Study Hall Seal
                    </div>
                    <span className="text-[8px] font-bold text-[#0f284e] uppercase tracking-wider block mt-0.5">
                      ISSUING AUTHORITY
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Digital Security & QR Verification Container */}
      <div className="no-print max-w-xl mx-auto rounded-card glass hairline p-5 shadow-sm space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-brand/10 border border-brand/20 flex items-center justify-center text-brand">
              <QrCode className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-ink flex items-center gap-2">
                Digital ID Security & Verification <ShieldCheck className="h-4 w-4 text-emerald-500" />
              </h3>
              <p className="text-xs text-muted">
                Official CampusX verification token. Scannable by campus security or college staff.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowVerifyModal(true)}
            className="rounded-ctl bg-surface hairline px-3 py-1.5 text-xs font-bold text-brand hover:bg-raised transition-all flex items-center gap-1"
          >
            <UserCheck className="h-3.5 w-3.5" /> Verify Status
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 rounded-xl bg-surface-raised p-4 hairline">
          {/* QR Code Container */}
          <div className="shrink-0 bg-white p-2 rounded-xl border border-slate-200 shadow-sm">
            <img
              src={qrSvgUrl}
              alt={`Verification QR Code for ${student.studentId}`}
              className="h-24 w-24 object-contain"
            />
          </div>

          <div className="space-y-1.5 text-center sm:text-left text-xs">
            <div className="flex items-center justify-center sm:justify-start gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-extrabold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider text-[10px]">
                AUTHENTICATED STUDENT IDENTITY
              </span>
            </div>
            <p className="font-mono text-xs font-bold text-ink">
              STUDENT ID: {student.studentId}
            </p>
            <p className="text-[11px] text-muted leading-relaxed">
              This QR code resolves to a secure CampusX verification endpoint containing non-sensitive academic credentials only.
            </p>
          </div>
        </div>
      </div>

      {/* Security Verification Status Modal */}
      {showVerifyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-surface p-6 shadow-2xl hairline space-y-4 animate-scale-in">
            <div className="flex items-center justify-between border-b hairline pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-emerald-500" />
                <h3 className="text-base font-extrabold text-ink">Official Verification Record</h3>
              </div>
              <button
                onClick={() => setShowVerifyModal(false)}
                className="rounded-lg p-1 text-muted hover:text-ink"
              >
                ✕
              </button>
            </div>

            <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/20 p-4 text-center space-y-1">
              <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto" />
              <h4 className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300 uppercase tracking-wider">
                VALID ENROLLED STUDENT
              </h4>
              <p className="text-xs text-muted">Study Hall College Official Portal Verification</p>
            </div>

            <div className="space-y-2 text-xs divide-y hairline">
              <div className="flex justify-between py-1.5">
                <span className="text-muted">Student Name</span>
                <span className="font-bold text-ink">{student.fullName}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-muted">Student ID</span>
                <span className="font-mono font-bold text-brand">{student.studentId}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-muted">Course</span>
                <span className="font-bold text-ink">{student.courseName} ({student.courseCode})</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-muted">Academic Year</span>
                <span className="font-bold text-ink">{student.academicYear} (Semester {student.semester})</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-muted">Session</span>
                <span className="font-bold text-ink">{student.admissionSession}</span>
              </div>
            </div>

            <button
              onClick={() => setShowVerifyModal(false)}
              className="w-full rounded-ctl bg-brand py-2.5 text-xs font-bold text-white shadow-md hover:bg-brand-dark transition-all"
            >
              Close Verification Status
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
