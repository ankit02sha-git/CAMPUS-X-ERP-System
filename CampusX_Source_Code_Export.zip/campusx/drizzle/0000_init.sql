CREATE TABLE `announcement_reads` (
	`announcement_id` text NOT NULL,
	`user_id` text NOT NULL,
	`read_at` integer NOT NULL,
	PRIMARY KEY(`announcement_id`, `user_id`),
	FOREIGN KEY (`announcement_id`) REFERENCES `announcements`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `announcements` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`content` text NOT NULL,
	`category` text DEFAULT 'General' NOT NULL,
	`priority` text DEFAULT 'NORMAL' NOT NULL,
	`published` integer DEFAULT false NOT NULL,
	`published_at` integer,
	`created_by_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`created_by_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `ann_pub_idx` ON `announcements` (`published`,`published_at`);--> statement-breakpoint
CREATE TABLE `assignment_submissions` (
	`id` text PRIMARY KEY NOT NULL,
	`assignment_id` text NOT NULL,
	`user_id` text NOT NULL,
	`status` text DEFAULT 'PENDING' NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`assignment_id`) REFERENCES `assignments`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `asub_unique` ON `assignment_submissions` (`assignment_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `assignments` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`subject` text NOT NULL,
	`due_date` integer NOT NULL,
	`attachment_url` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `asg_lookup_idx` ON `assignments` (`course_id`,`semester`,`due_date`);--> statement-breakpoint
CREATE TABLE `canteen_items` (
	`id` text PRIMARY KEY NOT NULL,
	`date` text NOT NULL,
	`meal` text NOT NULL,
	`name` text NOT NULL,
	`price` integer NOT NULL,
	`available` integer DEFAULT true NOT NULL,
	`image_url` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `canteen_date_idx` ON `canteen_items` (`date`,`meal`);--> statement-breakpoint
CREATE TABLE `courses` (
	`id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`description` text,
	`semesters` integer DEFAULT 6 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `courses_code_unique` ON `courses` (`code`);--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`date` text NOT NULL,
	`start_time` text,
	`end_time` text,
	`location` text,
	`category` text DEFAULT 'General' NOT NULL,
	`image_url` text,
	`status` text DEFAULT 'PUBLISHED' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `events_date_idx` ON `events` (`date`,`status`);--> statement-breakpoint
CREATE TABLE `lost_categories` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`slug` text NOT NULL,
	`order` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `lost_categories_name_unique` ON `lost_categories` (`name`);--> statement-breakpoint
CREATE UNIQUE INDEX `lost_categories_slug_unique` ON `lost_categories` (`slug`);--> statement-breakpoint
CREATE TABLE `lost_images` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`url` text NOT NULL,
	`order` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `li_post_idx` ON `lost_images` (`post_id`);--> statement-breakpoint
CREATE TABLE `lost_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`thread_id` text NOT NULL,
	`sender_id` text NOT NULL,
	`body` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`thread_id`) REFERENCES `lost_threads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lm_thread_idx` ON `lost_messages` (`thread_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_posts` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text DEFAULT 'LOST' NOT NULL,
	`status` text DEFAULT 'LOST' NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`details` text,
	`category_id` text NOT NULL,
	`location` text NOT NULL,
	`occurred_on` text NOT NULL,
	`approx_time` text,
	`contact_pref` text DEFAULT 'IN_APP' NOT NULL,
	`hidden` integer DEFAULT false NOT NULL,
	`author_id` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`category_id`) REFERENCES `lost_categories`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lp_feed_idx` ON `lost_posts` (`kind`,`status`,`hidden`,`created_at`);--> statement-breakpoint
CREATE INDEX `lp_cat_idx` ON `lost_posts` (`category_id`);--> statement-breakpoint
CREATE INDEX `lp_loc_idx` ON `lost_posts` (`location`);--> statement-breakpoint
CREATE INDEX `lp_author_idx` ON `lost_posts` (`author_id`);--> statement-breakpoint
CREATE TABLE `lost_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`reporter_id` text NOT NULL,
	`reason` text NOT NULL,
	`status` text DEFAULT 'OPEN' NOT NULL,
	`resolution` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lrep_status_idx` ON `lost_reports` (`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_responses` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`user_id` text NOT NULL,
	`message` text NOT NULL,
	`found_at` text NOT NULL,
	`found_on` text NOT NULL,
	`image_url` text,
	`contact_info` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lr_post_idx` ON `lost_responses` (`post_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_threads` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`owner_id` text NOT NULL,
	`other_id` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`other_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `lt_unique` ON `lost_threads` (`post_id`,`owner_id`,`other_id`);--> statement-breakpoint
CREATE INDEX `lt_owner_idx` ON `lost_threads` (`owner_id`);--> statement-breakpoint
CREATE INDEX `lt_other_idx` ON `lost_threads` (`other_id`);--> statement-breakpoint
CREATE TABLE `notes` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`subject` text NOT NULL,
	`file_url` text NOT NULL,
	`file_name` text,
	`file_type` text,
	`uploaded_by_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`uploaded_by_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `notes_lookup_idx` ON `notes` (`course_id`,`semester`,`subject`);--> statement-breakpoint
CREATE INDEX `notes_title_idx` ON `notes` (`title`);--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`type` text NOT NULL,
	`title` text NOT NULL,
	`body` text,
	`link` text,
	`read` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `notif_user_idx` ON `notifications` (`user_id`,`read`,`created_at`);--> statement-breakpoint
CREATE TABLE `student_stats` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`attendance_pct` integer DEFAULT 0 NOT NULL,
	`study_streak` integer DEFAULT 0 NOT NULL,
	`progress_pct` integer DEFAULT 0 NOT NULL,
	`is_demo` integer DEFAULT true NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `student_stats_user_id_unique` ON `student_stats` (`user_id`);--> statement-breakpoint
CREATE TABLE `timetable_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`day` text NOT NULL,
	`start_time` text NOT NULL,
	`end_time` text NOT NULL,
	`subject` text NOT NULL,
	`faculty` text,
	`room` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `tt_lookup_idx` ON `timetable_entries` (`course_id`,`semester`,`day`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`role` text DEFAULT 'STUDENT' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`course_id` text,
	`semester` integer,
	`student_id` text,
	`show_student_id` integer DEFAULT false NOT NULL,
	`image` text,
	`is_demo` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_email_unique` ON `users` (`email`);--> statement-breakpoint
CREATE UNIQUE INDEX `users_student_id_unique` ON `users` (`student_id`);--> statement-breakpoint
CREATE INDEX `users_role_idx` ON `users` (`role`);--> statement-breakpoint
CREATE INDEX `users_course_sem_idx` ON `users` (`course_id`,`semester`);--> statement-breakpoint
CREATE INDEX `users_name_idx` ON `users` (`name`);