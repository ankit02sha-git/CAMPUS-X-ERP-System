import { ClipboardList, Paperclip } from "lucide-react";
import { AssignmentStatus } from "@/components/AssignmentStatus";
import { Badge, EmptyState, PageHeader } from "@/components/ui";
import { pageUser } from "@/server/guards";
import { myAssignments } from "@/server/queries";

export const metadata = { title: "Assignments" };
export const dynamic = "force-dynamic";
const tone = { PENDING: "warn", SUBMITTED: "brass", COMPLETED: "ok", OVERDUE: "danger" } as const;

export default async function Page() {
  const u = await pageUser();
  const list = await myAssignments(u);
  return (
    <div>
      <PageHeader eyebrow="Academics" title="Assignments" subtitle="Everything due for your course and semester." />
      {!u.courseId ? <EmptyState icon={<ClipboardList className="h-6 w-6" />} title="Choose your course" body="Assignments are shown for your course and semester. Update your profile to see them." />
        : list.length === 0 ? <EmptyState icon={<ClipboardList className="h-6 w-6" />} title="No assignments yet" body="When your faculty publishes an assignment for your course, it will appear here." /> : (
        <ul className="space-y-3">{list.map((a) => (
          <li key={a.id} className="rounded-card hairline bg-surface p-5 shadow-card">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0"><div className="mb-1 flex flex-wrap items-center gap-2"><Badge tone={tone[a.status]}>{a.status[0] + a.status.slice(1).toLowerCase()}</Badge><Badge>{a.subject}</Badge></div>
                <h2 className="text-lg font-semibold">{a.title}</h2>{a.description && <p className="mt-1 whitespace-pre-wrap text-sm text-muted">{a.description}</p>}
                {a.attachmentUrl && <a href={a.attachmentUrl} target="_blank" rel="noreferrer noopener" className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-brass hover:underline"><Paperclip className="h-3.5 w-3.5" />Attachment</a>}</div>
              <div className="text-right text-sm"><div className="eyebrow">Due</div><div className="font-medium">{a.dueDate.toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}</div></div>
            </div>
            <div className="mt-4 border-t border-line pt-3"><AssignmentStatus id={a.id} status={a.status === "OVERDUE" ? "PENDING" : a.status} /></div>
          </li>))}</ul>)}
    </div>
  );
}
