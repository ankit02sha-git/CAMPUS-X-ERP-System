import { pageUser } from "@/server/guards";
import { db } from "@/server/db";
import { facultyDirectory } from "@/server/db/schema";
import { asc, eq } from "drizzle-orm";
import { FacultyDirectoryView } from "@/components/faculty/FacultyDirectoryView";

export default async function FacultyPage() {
  await pageUser();
  const list = await db
    .select()
    .from(facultyDirectory)
    .where(eq(facultyDirectory.active, true))
    .orderBy(asc(facultyDirectory.order));

  return <FacultyDirectoryView facultyList={list} />;
}
