import { asc, eq } from "drizzle-orm";
import { Soup } from "lucide-react";
import { Badge, EmptyState, PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { canteenItems } from "@/server/db/schema";
import { pageUser } from "@/server/guards";
import { todayKey } from "@/lib/utils";

export const metadata = { title: "Canteen" };
export const dynamic = "force-dynamic";
const MEALS = [["BREAKFAST", "Breakfast"], ["LUNCH", "Lunch"], ["SNACKS", "Snacks"], ["BEVERAGES", "Beverages"]] as const;

export default async function Page() {
  await pageUser();
  const items = await db.select().from(canteenItems).where(eq(canteenItems.date, todayKey())).orderBy(asc(canteenItems.name));
  return (
    <div>
      <PageHeader eyebrow="Campus" title="Canteen" subtitle={`Today's menu · ${new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", timeZone: "Asia/Kolkata" })}`} />
      {items.length === 0 ? <EmptyState icon={<Soup className="h-6 w-6" />} title="Today's menu hasn't been published yet." body="Check back later — the canteen menu and prices will appear here once they're added." /> : (
        <div className="grid gap-4 md:grid-cols-2">{MEALS.map(([k, label]) => { const list = items.filter((i) => i.meal === k); if (!list.length) return null; return (
          <section key={k} className="rounded-card hairline bg-surface p-5 shadow-card"><h2 className="mb-3 font-display text-xl font-semibold">{label}</h2>
            <ul className="divide-y divide-line">{list.map((i) => <li key={i.id} className="flex items-center justify-between py-2.5 text-sm"><span className={i.available ? "" : "text-muted line-through"}>{i.name}{!i.available && <Badge className="ml-2">Sold out</Badge>}</span><span className="font-medium tabular-nums">₹{i.price}</span></li>)}</ul></section>); })}</div>)}
    </div>
  );
}
