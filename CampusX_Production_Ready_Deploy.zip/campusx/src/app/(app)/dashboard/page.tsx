import Link from "next/link";
import {
  BookOpen,
  CalendarDays,
  ClipboardList,
  Clock,
  GraduationCap,
  Megaphone,
  MapPin,
  Search,
  Soup,
  Flame,
  CheckCircle2,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import { Badge, Card, EmptyState } from "@/components/ui";
import { GlassCard } from "@/components/ui/GlassCard";
import { Counter, ProgressBar, Reveal } from "@/components/ui/motion";
import { greeting, istNow, timeAgo, to12h } from "@/lib/utils";
import { pageUser } from "@/server/guards";
import {
  myAssignments,
  myStats,
  recentAnnouncements,
  recentLost,
  todaysClasses,
  upcomingEvents,
} from "@/server/queries";

export const metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

const ACTIONS = [
  { href: "/timetable", label: "Timetable", icon: Clock, note: "Class Schedule" },
  { href: "/notes", label: "Notes", icon: BookOpen, note: "Study Material" },
  { href: "/assignments", label: "Assignments", icon: ClipboardList, note: "Coursework" },
  { href: "/lost-found", label: "Lost & Found", icon: Search, note: "Campus Board" },
  { href: "/events", label: "Events", icon: CalendarDays, note: "College Life" },
  { href: "/canteen", label: "Canteen", icon: Soup, note: "Today's Menu" },
];

export default async function Dashboard() {
  const u = await pageUser();
  const [classes, events, anns, lost, asg, stats] = await Promise.all([
    todaysClasses(u),
    upcomingEvents(3),
    recentAnnouncements(3),
    recentLost(4),
    myAssignments(u),
    myStats(u),
  ]);

  const pending = asg.filter((a) => a.status === "PENDING" || a.status === "OVERDUE").length;
  const exams = events.filter((e) => e.category.toLowerCase() === "exam").length;
  const now = istNow().time;
  const current = classes.find((c) => c.startTime <= now && now < c.endTime);
  const next = classes.find((c) => c.startTime > now);
  const first = u.name.split(" ")[0];
  const demo = stats?.isDemo;

  return (
    <div className="space-y-8">
      {/* ─── Hero Section with Atmospheric Depth ─── */}
      <Reveal>
        <div className="relative overflow-hidden rounded-2xl glass-panel p-6 sm:p-8 shadow-lift border border-white/60 dark:border-white/10">
          {/* Subtle soft blue radial glow layer */}
          <div
            className="pointer-events-none absolute -right-12 -top-12 h-64 w-64 rounded-full opacity-60 blur-3xl"
            style={{ background: "radial-gradient(circle, rgba(32,98,172,0.3) 0%, transparent 70%)" }}
          />
          <div
            className="pointer-events-none absolute -left-12 -bottom-12 h-64 w-64 rounded-full opacity-40 blur-3xl"
            style={{ background: "radial-gradient(circle, rgba(14,165,233,0.2) 0%, transparent 70%)" }}
          />

          <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 rounded-full bg-brand/10 border border-brand/20 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-brand dark:text-brass">
                <Sparkles className="h-3.5 w-3.5 text-brass" />
                {u.role === "ADMIN" ? "ADMINISTRATOR DASHBOARD" : "STUDENT OVERVIEW"}
              </div>
              <h1 className="mt-3 font-display text-3xl font-extrabold text-navy dark:text-white md:text-4xl tracking-tight">
                {greeting()}, <span className="bg-gradient-to-r from-brand to-brand-dark bg-clip-text text-transparent dark:from-brass dark:to-white">{first}</span>.
              </h1>
              <p className="mt-2 text-sm font-medium text-muted max-w-xl">
                {current ? (
                  <>
                    Now in session: <b className="text-navy dark:text-brass font-bold">{current.subject}</b>
                    {current.room && ` · ${current.room}`}
                  </>
                ) : next ? (
                  <>
                    Next class: <b className="text-navy dark:text-brass font-bold">{next.subject}</b> at {to12h(next.startTime)}
                  </>
                ) : (
                  "No more classes scheduled today."
                )}
              </p>
            </div>

            {u.role === "ADMIN" && (
              <Link href="/admin" className="shrink-0">
                <button className="inline-flex items-center gap-2 rounded-ctl bg-brand text-white px-4 py-2.5 text-xs font-bold shadow-md hover:bg-brand-dark transition-all hover:scale-102">
                  Admin Control Panel <ArrowRight className="h-4 w-4" />
                </button>
              </Link>
            )}
          </div>
        </div>
      </Reveal>

      {/* ─── Stat Cards with Distinct Glass Hierarchy & Color Tints ─── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Attendance - Emerald Tinted Glass */}
        <Reveal delay={0.04}>
          <GlassCard variant="emerald" tilt interactive maxTilt={3} className="p-5 h-full">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
                Attendance
              </span>
              <div className="grid h-8 w-8 place-items-center rounded-xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">
                <GraduationCap className="h-4.5 w-4.5" />
              </div>
            </div>
            <div className="mt-3 font-display text-4xl font-extrabold tabular-nums text-emerald-950 dark:text-emerald-100">
              <Counter value={stats?.attendancePct ?? 0} suffix="%" />
            </div>
            <div className="mt-3">
              <ProgressBar value={stats?.attendancePct ?? 0} />
            </div>
            <div className="mt-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
              {demo ? "Demo value" : "Good standing"}
            </div>
          </GlassCard>
        </Reveal>

        {/* Pending Assignments - Cyan Tinted Glass */}
        <Reveal delay={0.08}>
          <GlassCard variant="cyan" tilt interactive maxTilt={3} className="p-5 h-full">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-800 dark:text-sky-300">
                Pending Assignments
              </span>
              <div className="grid h-8 w-8 place-items-center rounded-xl bg-sky-500/15 text-sky-700 dark:text-sky-400 border border-sky-500/30">
                <ClipboardList className="h-4.5 w-4.5" />
              </div>
            </div>
            <div className="mt-3 font-display text-4xl font-extrabold tabular-nums text-navy dark:text-white">
              <Counter value={pending} />
            </div>
            <div className="mt-4 text-xs font-semibold text-sky-700 dark:text-sky-400">
              {pending ? "Requires attention" : "All clear"}
            </div>
          </GlassCard>
        </Reveal>

        {/* Study Streak - Amber Tinted Glass */}
        <Reveal delay={0.12}>
          <GlassCard variant="amber" tilt interactive maxTilt={3} className="p-5 h-full">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300">
                Study Streak
              </span>
              <div className="grid h-8 w-8 place-items-center rounded-xl bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30">
                <Flame className="h-4.5 w-4.5" />
              </div>
            </div>
            <div className="mt-3 font-display text-4xl font-extrabold tabular-nums text-amber-950 dark:text-amber-100">
              <Counter value={stats?.studyStreak ?? 0} suffix=" days" />
            </div>
            <div className="mt-4 text-xs font-semibold text-amber-700 dark:text-amber-400">
              {demo ? "Demo value" : "Active learner"}
            </div>
          </GlassCard>
        </Reveal>

        {/* Upcoming Exams - Primary Blue Tinted Glass */}
        <Reveal delay={0.16}>
          <GlassCard variant="primary" tilt interactive maxTilt={3} className="p-5 h-full">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-brand dark:text-brass">
                Upcoming Exams
              </span>
              <div className="grid h-8 w-8 place-items-center rounded-xl bg-brand/15 text-brand dark:text-brass border border-brand/30">
                <CheckCircle2 className="h-4.5 w-4.5" />
              </div>
            </div>
            <div className="mt-3 font-display text-4xl font-extrabold tabular-nums text-navy dark:text-white">
              <Counter value={exams} />
            </div>
            <div className="mt-4 text-xs font-semibold text-brand dark:text-brass">
              {exams ? "Check schedule" : "None published"}
            </div>
          </GlassCard>
        </Reveal>
      </div>

      {/* ─── Today's Classes & Quick Actions ─── */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Today's Classes Panel */}
        <Reveal className="lg:col-span-2">
          <Card className="p-6">
            <div className="mb-5 flex items-center justify-between border-b border-line pb-3">
              <div>
                <h2 className="text-xl font-bold text-navy dark:text-white">Today&apos;s Classes</h2>
                <p className="text-xs text-muted">Your scheduled academic periods for today.</p>
              </div>
              <Link href="/timetable" className="text-xs font-bold text-brand hover:underline flex items-center gap-1">
                Full timetable <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {classes.length === 0 ? (
              <EmptyState
                icon={<Clock className="h-6 w-6" />}
                title="Your timetable will appear here once published."
                body="When the college publishes your course timetable, today's classes will show up here automatically."
              />
            ) : (
              <ol className="space-y-2.5">
                {classes.map((c) => {
                  const live = c === current;
                  return (
                    <li
                      key={c.id}
                      className={`flex min-w-0 items-center gap-3.5 rounded-ctl border px-4 py-3.5 transition-all ${
                        live
                          ? "bg-brand/10 border-brand/40 shadow-sm"
                          : "bg-surface/80 border-line hover:border-brand/30"
                      }`}
                    >
                      <div className="w-20 shrink-0 text-xs font-bold tabular-nums text-brand dark:text-brass">
                        {to12h(c.startTime)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="truncate font-bold text-sm text-navy dark:text-white">{c.subject}</div>
                        <div className="truncate text-xs font-medium text-muted">
                          {[c.faculty, c.room].filter(Boolean).join(" · ")}
                        </div>
                      </div>
                      {live && <Badge tone="brass">Now</Badge>}
                      {c === next && <Badge>Next</Badge>}
                    </li>
                  );
                })}
              </ol>
            )}
          </Card>
        </Reveal>

        {/* Quick Actions 6 Mini Glass Cards */}
        <Reveal delay={0.08}>
          <Card className="p-6">
            <h2 className="mb-1 text-xl font-bold text-navy dark:text-white">Quick Actions</h2>
            <p className="mb-4 text-xs text-muted">Instant access to student modules.</p>

            <div className="grid grid-cols-2 gap-3">
              {ACTIONS.map(({ href, label, icon: Icon, note }) => (
                <Link key={href} href={href}>
                  <GlassCard
                    variant="subtle"
                    interactive
                    reflection
                    className="group flex flex-col gap-2 p-3.5 border border-line hover:border-brand/40"
                  >
                    <div className="grid h-9 w-9 place-items-center rounded-xl bg-brand/10 text-brand dark:text-brass group-hover:scale-110 group-hover:bg-brand group-hover:text-white transition-all">
                      <Icon className="h-4.5 w-4.5" aria-hidden />
                    </div>
                    <div>
                      <div className="text-[13px] font-bold text-navy dark:text-white group-hover:text-brand dark:group-hover:text-brass transition-colors">
                        {label}
                      </div>
                      <div className="text-[10.5px] font-medium text-muted">{note}</div>
                    </div>
                  </GlassCard>
                </Link>
              ))}
            </div>
          </Card>
        </Reveal>
      </div>

      {/* ─── Announcements & Upcoming Events ─── */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Reveal>
          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between border-b border-line pb-3">
              <h2 className="text-xl font-bold text-navy dark:text-white">Announcements</h2>
              <Link href="/announcements" className="text-xs font-bold text-brand hover:underline">
                View all
              </Link>
            </div>
            {anns.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted">No announcements have been published yet.</p>
            ) : (
              <ul className="divide-y divide-line">
                {anns.map((a) => (
                  <li key={a.id} className="py-3">
                    <div className="flex items-center gap-2">
                      <Megaphone className="h-4 w-4 text-brand shrink-0" />
                      <span className="font-bold text-sm text-navy dark:text-white">{a.title}</span>
                      {a.priority === "URGENT" && <Badge tone="danger">Urgent</Badge>}
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs font-medium text-muted">{a.content}</p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </Reveal>

        <Reveal delay={0.06}>
          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between border-b border-line pb-3">
              <h2 className="text-xl font-bold text-navy dark:text-white">Upcoming Events</h2>
              <Link href="/events" className="text-xs font-bold text-brand hover:underline">
                Calendar
              </Link>
            </div>
            {events.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted">No upcoming events have been published.</p>
            ) : (
              <ul className="divide-y divide-line">
                {events.map((e) => (
                  <li key={e.id} className="flex gap-3.5 py-3">
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand/10 text-center text-[11px] font-bold leading-tight text-brand border border-brand/20">
                      {new Date(e.date + "T00:00").toLocaleDateString("en-IN", { day: "2-digit" })}
                      <br />
                      {new Date(e.date + "T00:00").toLocaleDateString("en-IN", { month: "short" })}
                    </div>
                    <div>
                      <div className="font-bold text-sm text-navy dark:text-white">{e.title}</div>
                      <div className="text-xs font-medium text-muted">
                        {[e.location, e.category].filter(Boolean).join(" · ")}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </Reveal>
      </div>

      {/* ─── Recent Lost & Found Board ─── */}
      <Reveal>
        <Card className="p-6">
          <div className="mb-4 flex items-center justify-between border-b border-line pb-3">
            <h2 className="text-xl font-bold text-navy dark:text-white">Recent Lost &amp; Found</h2>
            <Link href="/lost-found" className="text-xs font-bold text-brand hover:underline">
              Open board
            </Link>
          </div>
          {lost.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted">Nothing reported lately. That&apos;s good news.</p>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {lost.map(({ p, image }) => (
                <Link key={p.id} href={`/lost-found/${p.id}`}>
                  <GlassCard
                    variant="subtle"
                    interactive
                    reflection
                    className="group h-full overflow-hidden border border-line"
                  >
                    <div className="grid h-28 place-items-center bg-line/40 text-muted">
                      {image ? (
                        /* eslint-disable-next-line @next/next/no-img-element */
                        <img src={image} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <Search className="h-7 w-7 text-brand" />
                      )}
                    </div>
                    <div className="p-3.5 space-y-1.5">
                      <Badge tone={p.kind === "LOST" ? "warn" : "ok"}>{p.kind}</Badge>
                      <div className="truncate text-sm font-bold text-navy dark:text-white">{p.title}</div>
                      <div className="flex items-center gap-1 truncate text-xs font-medium text-muted">
                        <MapPin className="h-3 w-3 text-brand shrink-0" />
                        {p.location} · {timeAgo(p.createdAt)}
                      </div>
                    </div>
                  </GlassCard>
                </Link>
              ))}
            </div>
          )}
        </Card>
      </Reveal>
    </div>
  );
}
