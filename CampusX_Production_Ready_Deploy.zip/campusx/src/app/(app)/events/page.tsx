import { PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { eventRegistrations, events } from "@/server/db/schema";
import { pageUser } from "@/server/guards";
import { and, asc, eq } from "drizzle-orm";
import { EventMainView } from "@/components/events/EventMainView";

export const metadata = { title: "Events & Campus Calendar | Study Hall College" };
export const dynamic = "force-dynamic";

export default async function EventsPage() {
  const user = await pageUser();

  // Fetch all published events ordered by date
  const allEvents = await db
    .select()
    .from(events)
    .where(eq(events.published, true))
    .orderBy(asc(events.date));

  // Fetch student's confirmed registrations
  const registrations = await db
    .select({ eventId: eventRegistrations.eventId })
    .from(eventRegistrations)
    .where(and(eq(eventRegistrations.userId, user.id), eq(eventRegistrations.status, "CONFIRMED")));

  const userRegistrations = registrations.map((r) => r.eventId);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Study Hall College"
        title="Events & Campus Calendar"
        subtitle="Explore upcoming cultural fests, academic workshops, sports competitions, and campus celebrations."
      />

      <EventMainView initialEvents={allEvents} userRegistrations={userRegistrations} />
    </div>
  );
}
