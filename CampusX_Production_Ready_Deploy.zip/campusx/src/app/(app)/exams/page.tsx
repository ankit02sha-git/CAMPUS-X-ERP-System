import { pageUser } from "@/server/guards";
import { getStudentExamsList, getStudentResultsList } from "@/server/exams";
import { StudentExamsView } from "@/components/exams/StudentExamsView";

export default async function ExamsPage() {
  const user = await pageUser();
  const currentSem = user.semester || 3;

  const [examsList, resultsList] = await Promise.all([
    getStudentExamsList(user.courseId, user.semester, currentSem),
    getStudentResultsList(user.id, user.courseId, user.semester, currentSem),
  ]);

  return (
    <StudentExamsView
      initialExams={examsList}
      initialResults={resultsList}
      currentSemester={currentSem}
    />
  );
}
