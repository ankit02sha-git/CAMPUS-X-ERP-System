import { BookOpen, Cpu, Mail, MapPin, Phone, Trophy, Video } from "lucide-react";
import { asc, eq } from "drizzle-orm";
import { Badge, Card, PageHeader } from "@/components/ui";
import { Reveal } from "@/components/ui/motion";
import { CLUBS, COLLEGE, COURSE_INFO, FACILITIES } from "@/data/campus";
import { db } from "@/server/db";
import { courses } from "@/server/db/schema";
import { pageUser } from "@/server/guards";

export const metadata = { title: "Campus" };
export const dynamic = "force-dynamic";
const icons = { library: BookOpen, labs: Cpu, media: Video, sports: Trophy } as const;

export default async function Page() {
  await pageUser();
  const cs = await db.select().from(courses).where(eq(courses.active, true)).orderBy(asc(courses.code));
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Campus" title={COLLEGE.name} subtitle={`Established ${COLLEGE.established} · ${COLLEGE.city} · Affiliated to ${COLLEGE.affiliation}`} />
      <section aria-label="Facilities"><h2 className="mb-3 text-xl font-semibold">Facilities</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{FACILITIES.map((f, i) => { const I = icons[f.key]; return <Reveal key={f.key} delay={i * 0.05}><Card className="h-full p-5"><I className="mb-3 h-6 w-6 text-brass" /><h3 className="font-semibold">{f.title}</h3><p className="mt-1 text-sm text-muted">{f.body}</p></Card></Reveal>; })}</div>
        <p className="mt-2 text-xs text-muted">Source: official Study Hall College website. More facilities will be added as they are verified.</p></section>
      <section aria-label="Courses"><h2 className="mb-3 text-xl font-semibold">Courses</h2>
        <div className="grid gap-4 sm:grid-cols-2">{cs.map((c) => <Card key={c.id} className="p-5"><Badge tone="brass">{c.code === "BCOM" ? "B.Com" : c.code}</Badge><h3 className="mt-2 font-semibold">{c.name}</h3><p className="mt-1 text-sm text-muted">{COURSE_INFO[c.code] ?? c.description}</p></Card>)}</div></section>
      <section aria-label="Clubs"><h2 className="mb-3 text-xl font-semibold">Clubs &amp; activities</h2><div className="flex flex-wrap gap-2">{CLUBS.map((c) => <Badge key={c} tone="neutral" className="px-3 py-1 text-xs">{c}</Badge>)}</div></section>
      <Card className="p-5"><h2 className="mb-3 text-xl font-semibold">Contact</h2>
        <ul className="space-y-2 text-sm"><li className="flex gap-2"><MapPin className="h-4 w-4 text-brass" />{COLLEGE.address}</li><li className="flex gap-2"><Phone className="h-4 w-4 text-brass" />{COLLEGE.phone}</li><li className="flex gap-2"><Mail className="h-4 w-4 text-brass" />{COLLEGE.email}</li></ul></Card>
    </div>
  );
}
