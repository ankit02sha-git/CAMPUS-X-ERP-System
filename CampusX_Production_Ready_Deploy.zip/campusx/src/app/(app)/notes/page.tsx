import { and, asc, desc, eq, or, type SQL } from "drizzle-orm";
import { ilike } from "@/server/db/like";
import { BookOpen, Download, Eye } from "lucide-react";
import { Badge, Button, EmptyState, Input, PageHeader, Select } from "@/components/ui";
import { COURSE_LABEL, timeAgo } from "@/lib/utils";
import { db } from "@/server/db";
import { courses, notes } from "@/server/db/schema";
import { pageUser } from "@/server/guards";

export const metadata = { title: "Notes & Resources" };
export const dynamic = "force-dynamic";
const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; course?: string; sem?: string; subject?: string }> }) {
  const u = await pageUser();
  const sp = await searchParams;
  const all = await db.select().from(courses).where(eq(courses.active, true)).orderBy(asc(courses.code));
  const w: SQL[] = [];
  const course = sp.course ?? u.courseId ?? "";
  if (course) w.push(eq(notes.courseId, course));
  if (sp.sem && Number(sp.sem)) w.push(eq(notes.semester, Number(sp.sem)));
  if (sp.subject) w.push(ilike(notes.subject, `%${esc(sp.subject.slice(0, 80))}%`));
  if (sp.q) { const l = `%${esc(sp.q.slice(0, 80))}%`; w.push(or(ilike(notes.title, l), ilike(notes.subject, l))!); }
  const rows = await db.select().from(notes).where(w.length ? and(...w) : undefined).orderBy(desc(notes.createdAt)).limit(60);

  return (
    <div>
      <PageHeader eyebrow="Academics" title="Notes & Resources" subtitle="Study material published by your college, by course, semester and subject." />
      <form className="mb-6 grid gap-2.5 rounded-card hairline bg-surface p-3 sm:grid-cols-2 lg:grid-cols-5">
        <Input name="q" defaultValue={sp.q} placeholder="Search notes…" aria-label="Search" className="lg:col-span-2" />
        <Select name="course" defaultValue={course} aria-label="Course"><option value="">All courses</option>{all.map((c) => <option key={c.id} value={c.id}>{COURSE_LABEL[c.code] ?? c.code}</option>)}</Select>
        <Select name="sem" defaultValue={sp.sem ?? ""} aria-label="Semester"><option value="">All semesters</option>{[1, 2, 3, 4, 5, 6].map((s) => <option key={s} value={s}>Semester {s}</option>)}</Select>
        <div className="flex gap-2"><Input name="subject" defaultValue={sp.subject} placeholder="Subject" aria-label="Subject" /><Button type="submit" variant="outline">Go</Button></div>
      </form>
      {rows.length === 0 ? <EmptyState icon={<BookOpen className="h-6 w-6" />} title="No study materials have been published yet." body="Notes and resources will appear here as soon as the college uploads them." /> : (
        <ul className="grid gap-3 md:grid-cols-2">{rows.map((n) => (
          <li key={n.id} className="flex items-start gap-4 rounded-card hairline bg-surface p-4 shadow-card">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-ctl bg-brass/12 text-brass"><BookOpen className="h-5 w-5" /></div>
            <div className="min-w-0 flex-1"><div className="font-semibold">{n.title}</div>{n.description && <p className="line-clamp-2 text-sm text-muted">{n.description}</p>}
              <div className="mt-2 flex flex-wrap items-center gap-1.5"><Badge>{n.subject}</Badge><Badge tone="brass">Sem {n.semester}</Badge><span className="text-xs text-muted">{timeAgo(n.createdAt)}</span></div></div>
            <div className="flex flex-col gap-1.5">
              <a href={n.fileUrl} target="_blank" rel="noreferrer noopener" aria-label={`Preview ${n.title}`}><Button size="sm" variant="outline"><Eye className="h-3.5 w-3.5" />Preview</Button></a>
              <a href={n.fileUrl} download={n.fileName ?? true} aria-label={`Download ${n.title}`}><Button size="sm" variant="outline"><Download className="h-3.5 w-3.5" />Get</Button></a>
            </div>
          </li>))}</ul>)}
    </div>
  );
}
