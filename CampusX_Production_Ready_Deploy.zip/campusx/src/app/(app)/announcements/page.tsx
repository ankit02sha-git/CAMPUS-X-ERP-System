import { and, desc, eq, or, type SQL } from "drizzle-orm";
import { ilike } from "@/server/db/like";
import { Megaphone } from "lucide-react";
import { MarkRead } from "@/components/MarkRead";
import { Badge, Button, EmptyState, Input, PageHeader, Select } from "@/components/ui";
import { timeAgo } from "@/lib/utils";
import { db } from "@/server/db";
import { announcementReads, announcements } from "@/server/db/schema";
import { pageUser } from "@/server/guards";

export const metadata = { title: "Announcements" };
export const dynamic = "force-dynamic";
const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");
const tone = { LOW: "neutral", NORMAL: "neutral", HIGH: "warn", URGENT: "danger" } as const;

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; cat?: string; id?: string }> }) {
  const u = await pageUser();
  const sp = await searchParams;
  const w: SQL[] = [eq(announcements.published, true)];
  if (sp.q) { const l = `%${esc(sp.q.slice(0, 80))}%`; w.push(or(ilike(announcements.title, l), ilike(announcements.content, l))!); }
  if (sp.cat) w.push(eq(announcements.category, sp.cat));
  const [rows, reads, cats] = await Promise.all([
    db.select().from(announcements).where(and(...w)).orderBy(desc(announcements.publishedAt)).limit(50),
    db.select({ id: announcementReads.announcementId }).from(announcementReads).where(eq(announcementReads.userId, u.id)),
    db.selectDistinct({ c: announcements.category }).from(announcements).where(eq(announcements.published, true)),
  ]);
  const read = new Set(reads.map((r) => r.id));
  return (
    <div>
      <PageHeader eyebrow="Campus" title="Announcements" subtitle="Official notices from the college." />
      <form className="mb-6 flex flex-wrap gap-2"><Input name="q" defaultValue={sp.q} placeholder="Search announcements…" className="max-w-xs" aria-label="Search" />
        <Select name="cat" defaultValue={sp.cat ?? ""} className="w-44" aria-label="Category"><option value="">All categories</option>{cats.map((c) => <option key={c.c}>{c.c}</option>)}</Select><Button type="submit" variant="outline">Filter</Button></form>
      {rows.length === 0 ? <EmptyState icon={<Megaphone className="h-6 w-6" />} title="No announcements yet" body="Important notices from the college will be posted here." /> : (
        <ul className="space-y-3">{rows.map((a) => (
          <li key={a.id} id={a.id} className={`rounded-card hairline bg-surface p-5 shadow-card ${read.has(a.id) ? "" : "border-l-[3px] border-l-brass"}`}>
            <div className="mb-1.5 flex flex-wrap items-center gap-2"><Badge tone={tone[a.priority]}>{a.priority === "NORMAL" ? a.category : `${a.priority[0]}${a.priority.slice(1).toLowerCase()} · ${a.category}`}</Badge>{!read.has(a.id) && <Badge tone="brass">New</Badge>}<span className="text-xs text-muted">{a.publishedAt && timeAgo(a.publishedAt)}</span></div>
            <h2 className="text-lg font-semibold">{a.title}</h2><p className="mt-1 whitespace-pre-wrap text-sm text-muted">{a.content}</p>
            {!read.has(a.id) && <div className="mt-3"><MarkRead id={a.id} /></div>}
          </li>))}</ul>)}
    </div>
  );
}
