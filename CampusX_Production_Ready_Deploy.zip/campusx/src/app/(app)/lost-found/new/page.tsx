import { LostPostForm } from "@/components/lost/LostPostForm";
import { PageHeader } from "@/components/ui";
import { pageUser } from "@/server/guards";
import { activeCategories } from "@/server/lost";
export const metadata = { title: "Report item" };
export const dynamic = "force-dynamic";
export default async function Page({ searchParams }: { searchParams: Promise<{ kind?: string }> }) {
  await pageUser();
  const { kind } = await searchParams;
  const k = kind === "FOUND" ? "FOUND" : "LOST";
  return (<><PageHeader eyebrow="Lost & Found" title={k === "LOST" ? "Report a lost item" : "Report a found item"} subtitle={k === "LOST" ? "Tell the campus what you're looking for." : "Help an owner get their item back."} /><LostPostForm categories={await activeCategories()} defaultKind={k} /></>);
}
