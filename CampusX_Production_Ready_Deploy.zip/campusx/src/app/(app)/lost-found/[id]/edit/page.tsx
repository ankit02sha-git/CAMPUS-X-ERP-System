import { notFound } from "next/navigation";
import { LostPostForm } from "@/components/lost/LostPostForm";
import { PageHeader } from "@/components/ui";
import { pageUser } from "@/server/guards";
import { activeCategories, getPost } from "@/server/lost";
export const metadata = { title: "Edit notice" };
export const dynamic = "force-dynamic";
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const u = await pageUser();
  const data = await getPost((await params).id, u);
  if (!data || (!data.isOwner && !data.isAdmin)) notFound();
  const p = data.post;
  return (<><PageHeader eyebrow="Lost & Found" title="Edit notice" /><LostPostForm categories={await activeCategories()} initial={{ id: p.id, kind: p.kind, title: p.title, categoryId: p.categoryId, description: p.description, location: p.location, occurredOn: p.occurredOn, approxTime: p.approxTime, details: p.details, contactPref: p.contactPref, image: data.images[0]?.url ?? null }} /></>);
}
