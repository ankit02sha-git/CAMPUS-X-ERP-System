import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarDays, Clock, EyeOff, Lock, MapPin, Tag } from "lucide-react";
import { Chat } from "@/components/lost/Chat";
import { PostActions } from "@/components/lost/Actions";
import { StatusBadge } from "@/components/lost/StatusBadge";
import { Badge, Card } from "@/components/ui";
import { timeAgo } from "@/lib/utils";
import { pageUser } from "@/server/guards";
import { getMessages, getPost, getResponses, getThreads } from "@/server/lost";

export const dynamic = "force-dynamic";
export async function generateMetadata() { return { title: "Notice" }; }

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ thread?: string }> }) {
  const u = await pageUser();
  const { id } = await params; const { thread } = await searchParams;
  const data = await getPost(id, u);
  if (!data) notFound();
  const { post, category, author, studentId, images, isOwner, isAdmin } = data;
  const [responses, threads] = await Promise.all([getResponses(id, u, isOwner || isAdmin), getThreads(id, u)]);
  const active = thread ? threads.find((t) => t.t.id === thread) ?? null : threads.length === 1 ? threads[0] : null;
  const convo = active ? await getMessages(active.t.id, u.id) : null;
  const img = images[0]?.url;

  return (
    <div>
      <Link href={`/lost-found?tab=${post.kind.toLowerCase()}`} className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink"><ArrowLeft className="h-4 w-4" />Back to board</Link>
      {post.hidden && <div className="mb-4 flex items-center gap-2 rounded-ctl bg-warn/10 px-4 py-2.5 text-sm text-warn"><EyeOff className="h-4 w-4" />This notice is hidden from students.</div>}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="overflow-hidden">
            {img && /* eslint-disable-next-line @next/next/no-img-element */ <img src={img} alt={post.title} className="max-h-[420px] w-full bg-line/30 object-contain" />}
            <div className="space-y-4 p-6">
              <div className="flex flex-wrap items-center gap-2"><Badge tone={post.kind === "LOST" ? "warn" : "ok"}>{post.kind}</Badge><StatusBadge kind={post.kind} status={post.status} /><Badge>{category}</Badge></div>
              <h1 className="text-3xl font-semibold">{post.title}</h1>
              <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{post.description}</p>
              <dl className="grid gap-3 rounded-ctl bg-raised p-4 text-sm sm:grid-cols-2">
                <div className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 text-brass" /><div><dt className="text-xs text-muted">{post.kind === "LOST" ? "Lost at" : "Found at"}</dt><dd className="font-medium">{post.location}</dd></div></div>
                <div className="flex gap-2"><CalendarDays className="mt-0.5 h-4 w-4 text-brass" /><div><dt className="text-xs text-muted">Date</dt><dd className="font-medium">{new Date(post.occurredOn + "T00:00").toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}{post.approxTime && ` · ${post.approxTime}`}</dd></div></div>
                <div className="flex gap-2"><Clock className="mt-0.5 h-4 w-4 text-brass" /><div><dt className="text-xs text-muted">Posted</dt><dd className="font-medium">{timeAgo(post.createdAt)}</dd></div></div>
                <div className="flex gap-2"><Tag className="mt-0.5 h-4 w-4 text-brass" /><div><dt className="text-xs text-muted">Posted by</dt><dd className="font-medium">{author}{studentId && ` · ${studentId}`}</dd></div></div>
              </dl>
              {post.contactPref === "PICKUP_AT_OFFICE" && <p className="text-sm text-muted">The poster prefers hand-over at the college office.</p>}
              {post.details && <div className="rounded-ctl border border-dashed border-line p-3 text-sm"><div className="eyebrow mb-1 flex items-center gap-1"><Lock className="h-3 w-3" />Private details (only you &amp; admins)</div>{post.details}</div>}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="mb-4 text-xl font-semibold">{isOwner || isAdmin ? `Responses (${responses.length})` : "Your response"}</h2>
            {responses.length === 0 ? <p className="text-sm text-muted">{isOwner ? "No one has responded yet. You'll be notified when someone does." : "You haven't responded to this notice."}</p> : (
              <ul className="space-y-3">{responses.map(({ r, name }) => (
                <li key={r.id} className="rounded-ctl hairline bg-raised p-4 text-sm">
                  <div className="mb-1 flex items-center justify-between"><span className="font-medium">{name}</span><span className="text-xs text-muted">{timeAgo(r.createdAt)}</span></div>
                  <p>{r.message}</p>
                  <p className="mt-1.5 text-xs text-muted">{r.foundAt} · {new Date(r.foundOn + "T00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</p>
                  {r.contactInfo && <p className="mt-1.5 text-xs">Contact shared: <b>{r.contactInfo}</b></p>}
                  {r.imageUrl && /* eslint-disable-next-line @next/next/no-img-element */ <img src={r.imageUrl} alt="Response attachment" className="mt-2 h-28 rounded-ctl object-cover" />}
                </li>))}</ul>)}
          </Card>

          {threads.length > 0 && (
            <Card className="p-6">
              <h2 className="mb-1 text-xl font-semibold">Private messages</h2><p className="mb-4 text-xs text-muted">Only you and the other student can see this conversation.</p>
              {threads.length > 1 && <div className="mb-3 flex flex-wrap gap-2">{threads.map((t) => <Link key={t.t.id} href={`?thread=${t.t.id}`} className={`rounded-full px-3 py-1 text-xs font-medium hairline ${active?.t.id === t.t.id ? "bg-brand text-brand-fg" : "bg-surface"}`}>{t.t.ownerId === u.id ? t.otherName : t.ownerName}</Link>)}</div>}
              {convo && active ? <Chat key={active.t.id} threadId={active.t.id} viewerId={u.id} initial={convo.messages.map((m) => ({ ...m, createdAt: m.createdAt.toISOString() }))} /> : <p className="text-sm text-muted">Select a conversation above.</p>}
            </Card>
          )}
        </div>
        <aside className="lg:sticky lg:top-20 lg:self-start"><Card className="p-5"><PostActions post={{ id: post.id, kind: post.kind, status: post.status, hidden: post.hidden }} isOwner={isOwner} isAdmin={isAdmin} /></Card></aside>
      </div>
    </div>
  );
}
