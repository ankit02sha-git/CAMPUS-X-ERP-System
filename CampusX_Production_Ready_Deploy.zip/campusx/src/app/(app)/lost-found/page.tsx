import Link from "next/link";
import Image from "next/image";
import { CalendarDays, MapPin, Plus, Search, SearchX } from "lucide-react";
import { StatusBadge } from "@/components/lost/StatusBadge";
import { Badge, Button, EmptyState, Input, PageHeader, Select } from "@/components/ui";
import { Reveal, Tilt } from "@/components/ui/motion";
import { timeAgo } from "@/lib/utils";
import { pageUser } from "@/server/guards";
import { activeCategories, listPosts } from "@/server/lost";

export const metadata = { title: "Lost & Found" };
export const dynamic = "force-dynamic";
type SP = { tab?: string; q?: string; category?: string; location?: string; since?: string; status?: string; page?: string };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  await pageUser();
  const sp = await searchParams;
  const kind = sp.tab === "found" ? "FOUND" : "LOST";
  const [cats, { rows, total, pages, page }] = await Promise.all([activeCategories(), listPosts({ kind, q: sp.q?.slice(0, 80), category: sp.category, location: sp.location?.slice(0, 80), since: sp.since, status: sp.status, page: Number(sp.page) || 1 })]);
  const qs = (o: Record<string, string | undefined>) => { const p = new URLSearchParams(); for (const [k, v] of Object.entries({ ...sp, ...o })) if (v) p.set(k, v); return `?${p}`; };
  const hasFilter = !!(sp.q || sp.category || sp.location || sp.since || sp.status);

  return (
    <div>
      <PageHeader eyebrow="Community" title="Lost & Found" subtitle="Help fellow students recover what they've lost on campus."
        actions={<div className="flex gap-2"><Link href="/lost-found/new?kind=FOUND"><Button variant="outline">I found something</Button></Link><Link href="/lost-found/new"><Button><Plus className="h-4 w-4" />Report lost item</Button></Link></div>} />

      <div role="tablist" aria-label="Notice type" className="mb-5 inline-flex rounded-ctl hairline bg-surface p-1">
        {(["LOST", "FOUND"] as const).map((k) => (
          <Link key={k} role="tab" aria-selected={kind === k} href={qs({ tab: k.toLowerCase(), page: undefined, status: undefined })}
            className={`rounded-lg px-5 py-1.5 text-sm font-medium transition-colors ${kind === k ? "bg-brand text-brand-fg shadow-card" : "text-muted hover:text-ink"}`}>{k === "LOST" ? "Lost" : "Found"}</Link>
        ))}
      </div>

      <form className="mb-6 grid gap-2.5 rounded-card hairline bg-surface p-3 sm:grid-cols-2 lg:grid-cols-6" role="search">
        <input type="hidden" name="tab" value={kind.toLowerCase()} />
        <div className="relative lg:col-span-2"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted" /><Input name="q" defaultValue={sp.q} placeholder="Search items…" className="pl-9" aria-label="Search" /></div>
        <Select name="category" defaultValue={sp.category ?? ""} aria-label="Category"><option value="">All categories</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
        <Input name="location" defaultValue={sp.location} placeholder="Location" aria-label="Location" />
        <Input type="date" name="since" defaultValue={sp.since} aria-label="Since date" title="Since date" />
        <div className="flex gap-2"><Select name="status" defaultValue={sp.status ?? ""} aria-label="Status"><option value="">Any status</option><option value="LOST">Open</option><option value="POSSIBLY_FOUND">Possibly found</option><option value="FOUND">Found</option><option value="CLOSED">Closed</option></Select><Button type="submit" variant="outline">Filter</Button></div>
      </form>

      {rows.length === 0 ? (
        <EmptyState icon={<SearchX className="h-6 w-6" />} title={hasFilter ? "No matching notices" : kind === "LOST" ? "No lost items reported" : "No found items reported"} body={hasFilter ? "Try clearing a filter or searching with different words." : "When a student posts a notice, it will appear here."} action={hasFilter ? <Link href={`?tab=${kind.toLowerCase()}`} className="text-sm font-medium text-brass hover:underline">Clear filters</Link> : undefined} />
      ) : (
        <>
          <p className="mb-3 text-xs text-muted">{total} notice{total === 1 ? "" : "s"}</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {rows.map(({ p, category, image, author }, i) => (
              <Reveal key={p.id} delay={(i % 6) * 0.04}>
                <Tilt max={3} className="h-full overflow-hidden rounded-card hairline bg-surface shadow-card">
                  <Link href={`/lost-found/${p.id}`} className="block h-full">
                    <div className="relative h-40 bg-line/40">
                      {image ? (image.startsWith("http") ? <Image src={image} alt={p.title} fill className="object-cover" sizes="(max-width:768px) 100vw, 33vw" /> : /* eslint-disable-next-line @next/next/no-img-element */ <img src={image} alt={p.title} className="h-full w-full object-cover" loading="lazy" />) : <div className="grid h-full place-items-center text-muted"><Search className="h-8 w-8" /></div>}
                      <div className="absolute left-3 top-3 flex gap-1.5"><Badge tone={p.kind === "LOST" ? "warn" : "ok"} className="backdrop-blur">{p.kind}</Badge><StatusBadge kind={p.kind} status={p.status} /></div>
                    </div>
                    <div className="space-y-2 p-4">
                      <div className="flex items-start justify-between gap-2"><h3 className="text-lg font-semibold leading-tight">{p.title}</h3><Badge>{category}</Badge></div>
                      <p className="line-clamp-2 text-sm text-muted">&ldquo;{p.description}&rdquo;</p>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted"><span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{p.location}</span><span className="flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" />{new Date(p.occurredOn + "T00:00").toLocaleDateString("en-IN", { day: "numeric", month: "long" })}</span></div>
                      <div className="flex items-center justify-between border-t border-line pt-2.5 text-xs text-muted"><span>Posted by {author.split(" ")[0]}</span><span>{timeAgo(p.createdAt)}</span></div>
                    </div>
                  </Link>
                </Tilt>
              </Reveal>
            ))}
          </div>
          {pages > 1 && (
            <nav className="mt-8 flex items-center justify-center gap-2" aria-label="Pagination">
              {page > 1 && <Link href={qs({ page: String(page - 1) })}><Button variant="outline" size="sm">Previous</Button></Link>}
              <span className="text-sm text-muted">Page {page} of {pages}</span>
              {page < pages && <Link href={qs({ page: String(page + 1) })}><Button variant="outline" size="sm">Next</Button></Link>}
            </nav>
          )}
        </>
      )}
    </div>
  );
}
