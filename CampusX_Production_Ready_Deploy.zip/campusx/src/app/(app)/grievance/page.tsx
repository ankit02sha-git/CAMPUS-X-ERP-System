import { pageUser } from "@/server/guards";
import { getStudentGrievanceTickets } from "@/server/grievance";
import { StudentGrievanceView } from "@/components/grievance/StudentGrievanceView";

export default async function GrievancePage() {
  const user = await pageUser();
  const tickets = await getStudentGrievanceTickets(user.id);
  return <StudentGrievanceView initialTickets={tickets} />;
}
