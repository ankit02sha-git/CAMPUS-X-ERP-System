import { PageHeader } from "@/components/ui";
import { getStudentFeeSummary } from "@/lib/fees";
import { pageUser } from "@/server/guards";
import { StudentFeesView } from "@/components/fees/StudentFeesView";

export const metadata = { title: "Fees & Payments · CampusX" };
export const dynamic = "force-dynamic";

export default async function Page() {
  const u = await pageUser();
  const summary = await getStudentFeeSummary(u.id);

  if (!summary) {
    return (
      <div className="space-y-6">
        <PageHeader
          eyebrow="Student Account"
          title="Fees & Payments"
          subtitle="Study Hall College official fee structure, payment history, and receipt downloads."
        />
        <div className="rounded-card bg-surface p-8 text-center text-muted text-sm border hairline">
          Student fee account details could not be loaded. Please contact the college administration.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Student Account"
        title="Fees & Payments"
        subtitle={`Study Hall College official fee breakdown for ${summary.course?.code || "Enrolled Course"} (${summary.feeStructure?.academicSession || "2026-27"}).`}
      />

      <StudentFeesView summary={summary} />
    </div>
  );
}
