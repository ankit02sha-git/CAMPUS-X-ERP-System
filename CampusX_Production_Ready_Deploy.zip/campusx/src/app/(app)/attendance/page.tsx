import { pageUser } from "@/server/guards";
import { getStudentAttendanceOverview } from "@/server/attendance";
import { StudentAttendanceView } from "@/components/attendance/StudentAttendanceView";
import { db } from "@/server/db";
import { courses, users } from "@/server/db/schema";
import { eq } from "drizzle-orm";

export default async function AttendancePage() {
  const user = await pageUser();

  // If Admin, fetch a demo student account (Aarav Sharma) or BCA course so Admin can inspect attendance data
  let targetUserId = user.id;
  let targetCourseId = user.courseId;
  let targetSem = user.semester || 5;

  if (user.role === "ADMIN") {
    const [aarav] = await db.select().from(users).where(eq(users.email, "aarav.demo@campusx.local")).limit(1);
    if (aarav) {
      targetUserId = aarav.id;
      targetCourseId = aarav.courseId;
      targetSem = aarav.semester || 5;
    } else {
      const [bca] = await db.select().from(courses).where(eq(courses.code, "BCA")).limit(1);
      if (bca) {
        targetCourseId = bca.id;
        targetSem = 5;
      }
    }
  }

  const overview = await getStudentAttendanceOverview(
    targetUserId,
    targetCourseId,
    targetSem,
    targetSem,
    75
  );

  return <StudentAttendanceView initialOverview={overview} isAdmin={user.role === "ADMIN"} />;
}
