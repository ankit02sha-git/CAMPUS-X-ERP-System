"use client";
import { AlertTriangle } from "lucide-react";
import { Button, EmptyState } from "@/components/ui";
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return <EmptyState icon={<AlertTriangle className="h-6 w-6" />} title="Something went wrong" body="We couldn't load this page. This is on our side — please try again." action={<Button onClick={reset}>Try again</Button>} />;
}
