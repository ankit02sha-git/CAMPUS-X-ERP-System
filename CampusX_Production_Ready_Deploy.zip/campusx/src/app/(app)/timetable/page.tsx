import { and, asc, eq } from "drizzle-orm";
import { Clock } from "lucide-react";
import { OfficialTimetableGrid } from "@/components/timetable/OfficialTimetableGrid";
import { Badge, EmptyState, PageHeader, Select, Button } from "@/components/ui";
import { db } from "@/server/db";
import { courses, timetableSlots, timetablesMaster } from "@/server/db/schema";
import { pageUser } from "@/server/guards";

export const metadata = { title: "Official Timetable · CampusX" };
export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ course?: string; sem?: string }>;
}) {
  const u = await pageUser();
  const sp = await searchParams;

  const allCourses = await db
    .select({ id: courses.id, code: courses.code, name: courses.name })
    .from(courses)
    .where(eq(courses.active, true))
    .orderBy(asc(courses.code));

  // Default to student's enrolled course and semester if available
  const bcaCourse = allCourses.find((c) => c.code === "BCA") || allCourses[0];
  const courseId = sp.course && allCourses.some((c) => c.id === sp.course) ? sp.course : u.courseId ?? bcaCourse?.id ?? "";
  const sem = Math.min(6, Math.max(1, Number(sp.sem) || u.semester || 5));

  let master = null;
  let slots: typeof timetableSlots.$inferSelect[] = [];

  if (courseId) {
    [master] = await db
      .select()
      .from(timetablesMaster)
      .where(and(eq(timetablesMaster.courseId, courseId), eq(timetablesMaster.semester, sem)))
      .limit(1);

    if (master) {
      slots = await db
        .select()
        .from(timetableSlots)
        .where(eq(timetableSlots.timetableId, master.id));
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Academics"
        title="Official College Timetable"
        subtitle="Study Hall College weekly class schedule, period times, and faculty allocations."
      />

      {/* Cohort Switcher */}
      <form className="flex flex-wrap items-center gap-2 rounded-card bg-surface p-3.5 hairline shadow-sm">
        <Select name="course" defaultValue={courseId} className="w-48" aria-label="Course">
          {allCourses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.code} — {c.name}
            </option>
          ))}
        </Select>
        <Select name="sem" defaultValue={String(sem)} className="w-36" aria-label="Semester">
          {[1, 2, 3, 4, 5, 6].map((s) => (
            <option key={s} value={s}>
              Semester {s}
            </option>
          ))}
        </Select>
        <Button variant="outline" type="submit">
          View Timetable
        </Button>
      </form>

      {/* OFFICIAL TIMETABLE GRID OR EMPTY STATE */}
      {master && slots.length > 0 ? (
        <OfficialTimetableGrid master={master} slots={slots} isAdmin={false} />
      ) : (
        <EmptyState
          icon={<Clock className="h-6 w-6" />}
          title="Timetable Pending Publication"
          body="The college administration has not published an official timetable for this course and semester yet."
        />
      )}
    </div>
  );
}
