import { pageUser } from "@/server/guards";
import { getAcademicCalendarEvents } from "@/server/calendar";
import { AcademicCalendarView } from "@/components/calendar/AcademicCalendarView";

export default async function AcademicCalendarPage() {
  await pageUser();
  const events = await getAcademicCalendarEvents();
  return <AcademicCalendarView events={events} />;
}
