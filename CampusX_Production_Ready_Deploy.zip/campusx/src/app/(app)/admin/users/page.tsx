import { and, asc, eq, or, type SQL } from "drizzle-orm";
import { ilike } from "@/server/db/like";
import { UserActions } from "@/components/admin/UserRow";
import { StudentMasterManager } from "@/components/admin/StudentMasterManager";
import { Badge, Button, Input, PageHeader, Select } from "@/components/ui";
import { db } from "@/server/db";
import { courses, studentsMaster, users } from "@/server/db/schema";
import { pageAdmin } from "@/server/guards";

export const metadata = { title: "Admin · Master Student & User Management" };
export const dynamic = "force-dynamic";
const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; course?: string; semester?: string; status?: string; activation?: string; role?: string }>;
}) {
  const me = await pageAdmin();
  const sp = await searchParams;

  // Master Student filters
  const masterW: SQL[] = [];
  if (sp.q) {
    const l = `%${esc(sp.q.slice(0, 80))}%`;
    masterW.push(or(ilike(studentsMaster.fullName, l), ilike(studentsMaster.studentId, l), ilike(studentsMaster.registeredMobile, l))!);
  }
  if (sp.course) masterW.push(eq(studentsMaster.courseId, sp.course));
  if (sp.semester) masterW.push(eq(studentsMaster.semester, Number(sp.semester)));
  if (sp.status === "ACTIVE" || sp.status === "DISABLED") masterW.push(eq(studentsMaster.status, sp.status));
  if (sp.activation === "ACTIVATED" || sp.activation === "NOT_ACTIVATED") masterW.push(eq(studentsMaster.activationStatus, sp.activation));

  // User accounts filters
  const userW: SQL[] = [];
  if (sp.q) {
    const l = `%${esc(sp.q.slice(0, 80))}%`;
    userW.push(or(ilike(users.name, l), ilike(users.email, l), ilike(users.studentId, l))!);
  }
  if (sp.course) userW.push(eq(users.courseId, sp.course));
  if (sp.role === "ADMIN" || sp.role === "STUDENT") userW.push(eq(users.role, sp.role));

  const [masterRows, userRows, cs] = await Promise.all([
    db
      .select({
        sm: studentsMaster,
        code: courses.code,
      })
      .from(studentsMaster)
      .leftJoin(courses, eq(courses.id, studentsMaster.courseId))
      .where(masterW.length ? and(...masterW) : undefined)
      .orderBy(asc(studentsMaster.studentId))
      .limit(200),
    db
      .select({ u: users, code: courses.code })
      .from(users)
      .leftJoin(courses, eq(courses.id, users.courseId))
      .where(userW.length ? and(...userW) : undefined)
      .orderBy(asc(users.name))
      .limit(200),
    db.select({ id: courses.id, code: courses.code, name: courses.name }).from(courses).orderBy(asc(courses.code)),
  ]);

  const formattedMasterStudents = masterRows.map(({ sm, code }) => ({
    id: sm.id,
    studentId: sm.studentId,
    fullName: sm.fullName,
    registeredMobile: sm.registeredMobile,
    courseId: sm.courseId,
    courseCode: code ?? undefined,
    semester: sm.semester,
    section: sm.section,
    department: sm.department,
    academicYear: sm.academicYear,
    rollNumber: sm.rollNumber,
    activationStatus: sm.activationStatus,
    status: sm.status,
  }));

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Administration"
        title="Student Master & User Accounts"
        subtitle="Manage master student records, course enrollments, student activation, and administrative roles."
      />

      {/* Global Filter Bar */}
      <form className="grid gap-2 sm:grid-cols-6 rounded-card bg-surface p-3.5 hairline shadow-sm">
        <Input
          name="q"
          defaultValue={sp.q}
          placeholder="Search ID, Name, Mobile..."
          aria-label="Search"
          className="sm:col-span-2"
        />
        <Select name="course" defaultValue={sp.course ?? ""} aria-label="Course">
          <option value="">All Courses</option>
          {cs.map((c) => (
            <option key={c.id} value={c.id}>
              {c.code}
            </option>
          ))}
        </Select>
        <Select name="semester" defaultValue={sp.semester ?? ""} aria-label="Semester">
          <option value="">All Semesters</option>
          {[1, 2, 3, 4, 5, 6].map((s) => (
            <option key={s} value={s}>
              Sem {s}
            </option>
          ))}
        </Select>
        <Select name="activation" defaultValue={sp.activation ?? ""} aria-label="Activation">
          <option value="">All Activations</option>
          <option value="NOT_ACTIVATED">Not Activated</option>
          <option value="ACTIVATED">Activated</option>
        </Select>
        <Button type="submit" variant="outline" className="w-full">
          Apply Filters
        </Button>
      </form>

      {/* SECTION 1: MASTER STUDENT RECORDS */}
      <StudentMasterManager students={formattedMasterStudents} courses={cs} />

      {/* SECTION 2: ACTIVE USER ACCOUNTS */}
      <div className="space-y-4 pt-4 border-t border-line">
        <div>
          <h2 className="text-lg font-semibold text-ink">Active System Accounts ({userRows.length})</h2>
          <p className="text-xs text-muted">Signed up / active authentication accounts (Students & Administrators).</p>
        </div>

        <div className="overflow-x-auto rounded-card hairline bg-surface shadow-card">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="border-b border-line text-xs uppercase tracking-wider text-muted">
              <tr>
                <th className="px-4 py-3">Account Name / Email</th>
                <th className="px-4 py-3">Student ID</th>
                <th className="px-4 py-3">Course / Sem</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {userRows.map(({ u, code }) => (
                <tr key={u.id}>
                  <td className="px-4 py-2.5">
                    <div className="font-medium">
                      {u.name}
                      {u.isDemo && (
                        <Badge tone="warn" className="ml-2">
                          Demo
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted">{u.email}</div>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs font-semibold text-brass">
                    {u.studentId || "—"}
                  </td>
                  <td className="px-4 py-2.5">{code ? `${code}${u.semester ? ` · Sem ${u.semester}` : ""}` : "—"}</td>
                  <td className="px-4 py-2.5">
                    <Badge tone={u.role === "ADMIN" ? "brass" : "neutral"}>{u.role}</Badge>
                  </td>
                  <td className="px-4 py-2.5">
                    <Badge tone={u.active ? "ok" : "danger"}>{u.active ? "Active" : "Disabled"}</Badge>
                  </td>
                  <td className="px-4 py-2.5">
                    <UserActions id={u.id} active={u.active} role={u.role} isSelf={u.id === me.id} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
