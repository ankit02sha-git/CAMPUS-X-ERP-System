import Link from "next/link";
import { asc, desc, eq } from "drizzle-orm";
import { CategoryManager } from "@/components/admin/CategoryManager";
import { ReportActions } from "@/components/admin/ReportRow";
import { StatusBadge } from "@/components/lost/StatusBadge";
import { Badge, Card, EmptyState, PageHeader } from "@/components/ui";
import { timeAgo } from "@/lib/utils";
import { db } from "@/server/db";
import { lostCategories, lostPosts, users } from "@/server/db/schema";
import { pageAdmin } from "@/server/guards";
import { reportsForAdmin } from "@/server/lost";
import { ShieldCheck } from "lucide-react";

export const metadata = { title: "Admin · Lost & Found" };
export const dynamic = "force-dynamic";

export default async function Page() {
  await pageAdmin();
  const [reports, posts, cats] = await Promise.all([
    reportsForAdmin(),
    db.select({ p: lostPosts, author: users.name }).from(lostPosts).innerJoin(users, eq(users.id, lostPosts.authorId)).orderBy(desc(lostPosts.createdAt)).limit(50),
    db.select().from(lostCategories).orderBy(asc(lostCategories.order)),
  ]);
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Admin" title="Lost & Found moderation" subtitle="Review reports, hide or remove posts, resolve disputes and manage categories." />
      <section><h2 className="mb-3 text-xl font-semibold">Reports</h2>
        {reports.length === 0 ? <EmptyState icon={<ShieldCheck className="h-6 w-6" />} title="No reports" body="Student reports of inappropriate posts will appear here." /> : (
          <ul className="space-y-3">{reports.map(({ r, title, postId, hidden, reporter }) => (
            <li key={r.id}><Card className="p-4"><div className="mb-2 flex flex-wrap items-center gap-2"><Badge tone={r.status === "OPEN" ? "danger" : "neutral"}>{r.status}</Badge><Link className="font-medium hover:underline" href={`/lost-found/${postId}`}>{title}</Link>{hidden && <Badge tone="warn">Hidden</Badge>}<span className="text-xs text-muted">reported by {reporter} · {timeAgo(r.createdAt)}</span></div>
              <p className="mb-3 text-sm">{r.reason}</p>{r.resolution && <p className="mb-3 text-xs text-muted">Resolution: {r.resolution}</p>}<ReportActions id={r.id} postId={postId} hidden={hidden} open={r.status === "OPEN"} /></Card></li>))}</ul>)}</section>
      <section><h2 className="mb-3 text-xl font-semibold">Categories</h2><CategoryManager cats={cats.map((c) => ({ id: c.id, name: c.name, active: c.active }))} /></section>
      <section><h2 className="mb-3 text-xl font-semibold">All posts</h2>
        <div className="overflow-x-auto rounded-card hairline bg-surface shadow-card"><table className="w-full min-w-[560px] text-left text-sm"><tbody className="divide-y divide-line">{posts.map(({ p, author }) => (
          <tr key={p.id}><td className="px-4 py-2.5"><Link href={`/lost-found/${p.id}`} className="font-medium hover:underline">{p.title}</Link><div className="text-xs text-muted">{author} · {timeAgo(p.createdAt)}</div></td><td className="px-4 py-2.5"><Badge tone={p.kind === "LOST" ? "warn" : "ok"}>{p.kind}</Badge></td><td className="px-4 py-2.5"><StatusBadge kind={p.kind} status={p.status} /></td><td className="px-4 py-2.5">{p.hidden && <Badge tone="warn">Hidden</Badge>}</td></tr>))}</tbody></table></div></section>
    </div>
  );
}
