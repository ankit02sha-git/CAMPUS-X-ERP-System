import { pageAdmin } from "@/server/guards";
import { getAdminGrievanceTickets } from "@/server/grievance";
import { AdminGrievanceView } from "@/components/admin/AdminGrievanceView";

export default async function AdminGrievancesPage() {
  await pageAdmin();
  const tickets = await getAdminGrievanceTickets();
  return <AdminGrievanceView initialTickets={tickets} />;
}
