import { asc, desc, getTableColumns } from "drizzle-orm";
import { notFound } from "next/navigation";
import { EntityManager } from "@/components/admin/EntityManager";
import { PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { courses } from "@/server/db/schema";
import { ENTITIES } from "@/server/admin/registry";
import { pageAdmin } from "@/server/guards";

export const dynamic = "force-dynamic";
const IST = (d: Date) => new Date(d.getTime() + 330 * 60_000).toISOString().slice(0, 16);

export default async function Page({ params }: { params: Promise<{ entity: string }> }) {
  await pageAdmin();
  const { entity } = await params;
  const ent = ENTITIES[entity];
  if (!ent) notFound();
  const cols = getTableColumns(ent.table) as unknown as Record<string, never>;
  const order = ["createdAt", "dueDate", "date"].includes(ent.orderBy) ? desc(cols[ent.orderBy]) : asc(cols[ent.orderBy]);
  const [raw, cs] = await Promise.all([db.select().from(ent.table).orderBy(order).limit(300), db.select({ id: courses.id, code: courses.code }).from(courses).orderBy(asc(courses.code))]);
  const rows = (raw as Record<string, unknown>[]).map((r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v instanceof Date ? (k === "dueDate" ? IST(v) : v.toISOString()) : v ?? null])));
  return (<><PageHeader eyebrow="Admin" title={ent.label} subtitle={ent.description} />
    <EntityManager entity={ent.key} singular={ent.singular} fields={ent.fields} columns={ent.columns} rows={rows as never} courses={cs} /></>);
}
