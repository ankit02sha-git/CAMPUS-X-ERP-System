import { desc, isNull } from "drizzle-orm";
import { PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { events } from "@/server/db/schema";
import { pageAdmin } from "@/server/guards";
import { EventManagementView } from "@/components/admin/EventManagementView";

export const metadata = { title: "Admin — Event Management | Study Hall College" };
export const dynamic = "force-dynamic";

export default async function AdminEventsPage() {
  await pageAdmin(); // Strict server-side authorization check

  // Fetch all non-deleted events
  const allEvents = await db
    .select()
    .from(events)
    .where(isNull(events.deletedAt))
    .orderBy(desc(events.date));

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Admin Panel"
        title="Event Management"
        subtitle="Add, edit, publish, feature, or archive campus events for Study Hall College."
      />

      <EventManagementView initialEvents={allEvents} />
    </div>
  );
}
