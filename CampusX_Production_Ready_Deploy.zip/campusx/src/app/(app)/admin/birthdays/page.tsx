import { pageAdmin } from "@/server/guards";
import { getAdminBirthdayRecords } from "@/server/birthday";
import { AdminBirthdayView } from "@/components/admin/AdminBirthdayView";

export const revalidate = 0; // Always fresh server calculation for IST date

export default async function AdminBirthdaysPage() {
  await pageAdmin(); // Server guard checking for admin role

  const { records, todayKeyStr } = await getAdminBirthdayRecords();

  return <AdminBirthdayView initialRecords={records} todayKeyStr={todayKeyStr} />;
}
