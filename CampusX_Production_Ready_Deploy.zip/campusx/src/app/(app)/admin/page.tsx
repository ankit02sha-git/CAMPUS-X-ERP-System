import { count, eq } from "drizzle-orm";
import Link from "next/link";
import { Card, PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { announcements, assignments, events, lostPosts, lostReports, notes, timetable, users } from "@/server/db/schema";
import { pageAdmin } from "@/server/guards";

export const metadata = { title: "Admin" };
export const dynamic = "force-dynamic";
export default async function Page() {
  await pageAdmin();
  const c = async (t: Parameters<typeof db.select>[0] extends never ? never : any, w?: any) => Number((await db.select({ n: count() }).from(t).where(w))[0].n); // eslint-disable-line @typescript-eslint/no-explicit-any
  const [students, tt, nt, asg, ev, an, lp, rep] = await Promise.all([c(users, eq(users.role, "STUDENT")), c(timetable), c(notes), c(assignments), c(events), c(announcements), c(lostPosts), c(lostReports, eq(lostReports.status, "OPEN"))]);
  const tiles: [string, number | string, string][] = [["Students", students, "/admin/users"], ["Fee Collections", "Manage", "/admin/fees"], ["Timetable entries", tt, "/admin/timetable"], ["Notes", nt, "/admin/notes"], ["Assignments", asg, "/admin/assignments"], ["Events", ev, "/admin/events"], ["Announcements", an, "/admin/announcements"], ["Lost & Found posts", lp, "/admin/lost-found"], ["Open reports", rep, "/admin/lost-found"]];
  return (<><PageHeader eyebrow="Administration" title="Admin dashboard" subtitle="Manage every part of CampusX. Changes are visible to students immediately." />
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{tiles.map(([l, n, h]) => <Link key={l} href={h}><Card className="p-5 transition-all duration-base ease-luxe hover:-translate-y-0.5 hover:shadow-lift"><div className="eyebrow">{l}</div><div className="mt-2 font-display text-4xl font-semibold">{n}</div></Card></Link>)}</div></>);
}
