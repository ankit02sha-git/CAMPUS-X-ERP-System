import { pageAdmin } from "@/server/guards";
import { ENTITIES } from "@/server/admin/registry";
import { ShieldCheck } from "lucide-react";
import { AdminNavTabs } from "@/components/admin/AdminNavTabs";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await pageAdmin(); // Server-side strict authorization guard

  const tabs: Array<[string, string]> = [
    ["/admin", "Dashboard"],
    ["/admin/users", "Students & Accounts"],
    ["/admin/fees", "Fee Management"],
    ["/admin/attendance", "Faculty Attendance"],
    ["/admin/birthdays", "Student Birthdays"],
    ["/admin/grievances", "Grievances & Support"],
    ...Object.values(ENTITIES).map((e) => [`/admin/${e.key}`, e.label] as [string, string]),
    ["/admin/lost-found", "Lost & Found Board"],
  ];

  return (
    <div className="space-y-6">
      {/* Admin Top Header Banner */}
      <div className="rounded-card bg-navy-deep text-white p-4 hairline shadow-md flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="h-6 w-6 text-shcyellow shrink-0" />
          <div>
            <h1 className="text-base font-bold tracking-wide uppercase">ADMINISTRATION CONTROL PANEL</h1>
            <p className="text-xs text-white/70">Manage students, courses, timetable, assignments & campus info</p>
          </div>
        </div>
      </div>

      {/* Admin Navigation Bar with Active Highlighting */}
      <AdminNavTabs tabs={tabs} />

      <div>{children}</div>
    </div>
  );
}
