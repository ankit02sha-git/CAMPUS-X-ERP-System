import { and, asc, eq } from "drizzle-orm";
import { TimetableGridEditor } from "@/components/admin/TimetableGridEditor";
import { PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { courses, timetableSlots, timetablesMaster } from "@/server/db/schema";
import { pageAdmin } from "@/server/guards";

export const metadata = { title: "Admin · Official Timetable Grid Editor" };
export const dynamic = "force-dynamic";

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ courseId?: string; semester?: string }>;
}) {
  await pageAdmin();
  const sp = await searchParams;

  const allCourses = await db.select({ id: courses.id, code: courses.code, name: courses.name }).from(courses).orderBy(asc(courses.code));

  // Default to BCA course if present, or first course
  const bcaCourse = allCourses.find((c) => c.code === "BCA") || allCourses[0];
  const selectedCourseId = sp.courseId || bcaCourse?.id || "";
  const selectedSemester = Number(sp.semester || 5);

  let master = null;
  let slots: typeof timetableSlots.$inferSelect[] = [];

  if (selectedCourseId) {
    [master] = await db
      .select()
      .from(timetablesMaster)
      .where(and(eq(timetablesMaster.courseId, selectedCourseId), eq(timetablesMaster.semester, selectedSemester)))
      .limit(1);

    if (master) {
      slots = await db
        .select()
        .from(timetableSlots)
        .where(eq(timetableSlots.timetableId, master.id));
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Administration"
        title="Official Timetable Grid Editor"
        subtitle="Manage official college timetables, merged period cells, and special activity blocks."
      />

      <TimetableGridEditor
        courses={allCourses}
        initialMaster={master || null}
        initialSlots={slots}
        selectedCourseId={selectedCourseId}
        selectedSemester={selectedSemester}
      />
    </div>
  );
}
