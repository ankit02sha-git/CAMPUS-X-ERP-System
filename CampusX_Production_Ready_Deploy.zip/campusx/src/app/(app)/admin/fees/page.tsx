import { asc, eq } from "drizzle-orm";
import { PageHeader } from "@/components/ui";
import { db } from "@/server/db";
import { courses, feeStructures, feeDueRules, users } from "@/server/db/schema";
import { pageAdmin } from "@/server/guards";
import { getStudentFeeSummary, type StudentFeeSummary } from "@/lib/fees";
import { FeeManagementView } from "@/components/admin/FeeManagementView";

export const metadata = { title: "Admin · Fee Management · CampusX" };
export const dynamic = "force-dynamic";

export default async function Page() {
  await pageAdmin();

  const allCourses = await db
    .select()
    .from(courses)
    .orderBy(asc(courses.code));

  const allStructures = await db.select().from(feeStructures);
  const allDueRules = await db.select().from(feeDueRules);

  const students = await db
    .select()
    .from(users)
    .where(eq(users.role, "STUDENT"))
    .orderBy(asc(users.name));

  const studentSummaries: StudentFeeSummary[] = [];
  for (const s of students) {
    const summary = await getStudentFeeSummary(s.id);
    if (summary) {
      studentSummaries.push(summary);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Administration"
        title="Fee Management & Collection"
        subtitle="Manage official college course fee structures, due dates, late fine rules, and student payment collections."
      />

      <FeeManagementView
        courses={allCourses}
        feeStructuresList={allStructures}
        dueRulesList={allDueRules}
        studentSummaries={studentSummaries}
      />
    </div>
  );
}
