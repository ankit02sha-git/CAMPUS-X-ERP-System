import { pageAdmin } from "@/server/guards";
import { db } from "@/server/db";
import { courses, subjects } from "@/server/db/schema";
import { getAdminDepartmentAttendanceOverview } from "@/server/attendance";
import { AdminAttendanceView } from "@/components/admin/AdminAttendanceView";

export default async function AdminAttendancePage() {
  await pageAdmin();

  const coursesList = await db.select().from(courses);
  const initialOverview = await getAdminDepartmentAttendanceOverview(coursesList[0]?.id, 5);

  return (
    <AdminAttendanceView
      coursesList={coursesList}
      initialOverview={initialOverview}
    />
  );
}
