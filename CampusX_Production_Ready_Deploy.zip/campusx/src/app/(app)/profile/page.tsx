import { eq, desc } from "drizzle-orm";
import { Flame, GraduationCap, TrendingUp, ShieldCheck } from "lucide-react";
import { ProfileForm } from "@/components/ProfileForm";
import { Badge, Card, PageHeader } from "@/components/ui";
import { Counter, ProgressBar } from "@/components/ui/motion";
import { timeAgo } from "@/lib/utils";
import { maskMobileNumber } from "@/lib/sms";
import { db } from "@/server/db";
import { courses, lostPosts } from "@/server/db/schema";
import { pageUser } from "@/server/guards";
import { myAssignments, myStats } from "@/server/queries";
import Link from "next/link";

export const metadata = { title: "Profile · CampusX" };
export const dynamic = "force-dynamic";

export default async function Page() {
  const u = await pageUser();
  const [stats, asg, course, mine] = await Promise.all([
    myStats(u),
    myAssignments(u),
    u.courseId ? db.select().from(courses).where(eq(courses.id, u.courseId)).then((r) => r[0]) : null,
    db.select().from(lostPosts).where(eq(lostPosts.authorId, u.id)).orderBy(desc(lostPosts.createdAt)).limit(5),
  ]);

  const done = asg.filter((a) => a.status === "COMPLETED" || a.status === "SUBMITTED").length;
  const initials = u.name.split(" ").map((s) => s[0]).slice(0, 2).join("");

  return (
    <div>
      <PageHeader eyebrow="Account" title="Student Profile" />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-1 space-y-4">
          <div className="flex items-center gap-4 border-b border-line pb-4">
            {u.image ? (
              /* eslint-disable-next-line @next/next/no-img-element */
              <img src={u.image} alt="" className="h-16 w-16 rounded-full object-cover shadow-sm" />
            ) : (
              <div className="grid h-16 w-16 place-items-center rounded-full bg-brand text-xl font-semibold text-brand-fg shadow-sm">
                {initials}
              </div>
            )}
            <div>
              <h2 className="text-xl font-semibold text-ink">{u.name}</h2>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {course && <Badge tone="brass">{course.code}</Badge>}
                {u.semester && <Badge>Semester {u.semester}</Badge>}
                {u.role === "ADMIN" && <Badge tone="brass">Administrator</Badge>}
              </div>
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center py-1 border-b border-line/50">
              <span className="text-muted">Student ID</span>
              <span className="font-mono font-bold text-brass">{u.studentId ?? "Not assigned"}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-line/50">
              <span className="text-muted">Mobile Number</span>
              <span className="font-mono text-ink">{u.registeredMobile ? maskMobileNumber(u.registeredMobile) : "Not registered"}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-line/50">
              <span className="text-muted">Course</span>
              <span className="font-medium text-ink">{course ? course.name : "N/A"}</span>
            </div>
            {u.department && (
              <div className="flex justify-between items-center py-1 border-b border-line/50">
                <span className="text-muted">Department</span>
                <span className="font-medium text-ink">{u.department}</span>
              </div>
            )}
            {u.section && (
              <div className="flex justify-between items-center py-1 border-b border-line/50">
                <span className="text-muted">Section</span>
                <span className="font-medium text-ink">{u.section}</span>
              </div>
            )}
            {u.academicYear && (
              <div className="flex justify-between items-center py-1 border-b border-line/50">
                <span className="text-muted">Academic Year</span>
                <span className="font-medium text-ink">{u.academicYear}</span>
              </div>
            )}
          </div>

          <div className="rounded-ctl bg-surface p-3 text-xs text-muted flex items-start gap-2 hairline">
            <ShieldCheck className="h-4 w-4 text-brass shrink-0 mt-0.5" />
            <p>Official identity and academic information are managed by College Administration.</p>
          </div>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { l: "Attendance", v: stats?.attendancePct ?? 0, s: "%", i: GraduationCap },
              { l: "Study streak", v: stats?.studyStreak ?? 0, s: " days", i: Flame },
              { l: "Academic progress", v: stats?.progressPct ?? 0, s: "%", i: TrendingUp },
            ].map((t) => (
              <Card key={t.l} className="p-4">
                <div className="flex items-center justify-between">
                  <span className="eyebrow">{t.l}</span>
                  <t.i className="h-4 w-4 text-brass" />
                </div>
                <div className="mt-2 font-display text-3xl font-semibold">
                  <Counter value={t.v} suffix={t.s} />
                </div>
                {t.s === "%" && (
                  <div className="mt-2">
                    <ProgressBar value={t.v} />
                  </div>
                )}
              </Card>
            ))}
          </div>

          <Card className="p-5">
            <h2 className="mb-3 text-lg font-semibold">Academic Activity</h2>
            <p className="mb-2 text-sm text-muted">
              {asg.length ? `${done} of ${asg.length} assignments submitted or completed.` : "No assignments assigned yet."}
            </p>
            {mine.length === 0 ? (
              <p className="text-sm text-muted">No Lost &amp; Found posts yet.</p>
            ) : (
              <ul className="divide-y divide-line">
                {mine.map((p) => (
                  <li key={p.id} className="flex justify-between py-2 text-sm">
                    <Link className="font-medium hover:underline" href={`/lost-found/${p.id}`}>
                      {p.title}
                    </Link>
                    <span className="text-xs text-muted">{timeAgo(p.createdAt)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card className="p-5">
            <h2 className="mb-4 text-lg font-semibold">Edit Preferences & Photo</h2>
            <ProfileForm name={u.name} image={u.image} showStudentId={u.showStudentId} />
          </Card>
        </div>
      </div>
    </div>
  );
}
