import { pageUser } from "@/server/guards";
import { db } from "@/server/db";
import { courses, studentsMaster } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { DigitalIdCardView } from "@/components/idcard/DigitalIdCardView";

export default async function IdCardPage() {
  const user = await pageUser();

  // Fetch student master record if linked, or course details
  let masterRecord = null;
  if (user.studentMasterId) {
    [masterRecord] = await db.select().from(studentsMaster).where(eq(studentsMaster.id, user.studentMasterId)).limit(1);
  }

  let courseRecord = null;
  if (user.courseId) {
    [courseRecord] = await db.select().from(courses).where(eq(courses.id, user.courseId)).limit(1);
  }

  const studentData = {
    fullName: user.name,
    studentId: user.studentId || masterRecord?.studentId || "SHC2504023",
    courseCode: courseRecord?.code || "BCA",
    courseName: courseRecord?.name || "Bachelor of Computer Applications",
    academicYear: masterRecord?.academicYear || user.academicYear || "2nd Year",
    semester: user.semester || masterRecord?.semester || 3,
    section: user.section || masterRecord?.section || "A",
    rollNumber: user.rollNumber || masterRecord?.rollNumber || "101",
    department: masterRecord?.department || user.department || "Computer Applications",
    admissionSession: masterRecord?.admissionSession || "2025-2026",
    dob: masterRecord?.dob || user.dob || null,
    profilePhoto: user.image || null,
    registeredMobile: user.registeredMobile || masterRecord?.registeredMobile || null,
    fatherName: masterRecord?.fatherName || user.fatherName || null,
    motherName: masterRecord?.motherName || user.motherName || null,
    parentContact: masterRecord?.parentContact || user.parentContact || null,
    localAddress: masterRecord?.localAddress || user.localAddress || null,
  };

  return <DigitalIdCardView student={studentData} />;
}
