import { AppShell } from "@/components/shell/AppShell";
import { pageUser } from "@/server/guards";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const u = await pageUser();
  return <AppShell user={{ name: u.name, role: u.role, image: u.image }}>{children}</AppShell>;
}
