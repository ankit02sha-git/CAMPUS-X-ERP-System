import Link from "next/link";
import { SearchX } from "lucide-react";
import { EmptyState } from "@/components/ui";
export default function NotFound() {
  return <EmptyState icon={<SearchX className="h-6 w-6" />} title="Page not found" body="The page you're looking for doesn't exist or has been removed." action={<Link href="/dashboard" className="text-sm font-medium text-brass hover:underline">Back to dashboard</Link>} />;
}
