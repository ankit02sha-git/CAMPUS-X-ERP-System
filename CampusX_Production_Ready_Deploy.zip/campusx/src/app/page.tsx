import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, BookOpen, CalendarDays, ClipboardList, Clock, Search, Soup } from "lucide-react";
import { auth } from "@/auth";
import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/shell/ThemeToggle";
import { Reveal } from "@/components/ui/motion";
import { COLLEGE } from "@/data/campus";

const FEATURES = [
  { icon: Clock, t: "Your timetable", d: "Today's classes, current and next — by course and semester." },
  { icon: ClipboardList, t: "Assignments", d: "Deadlines, attachments and your submission status in one place." },
  { icon: BookOpen, t: "Notes & resources", d: "Study material organised by course, semester and subject." },
  { icon: Search, t: "Lost & Found", d: "Report a lost item, respond to a notice, and talk privately in-app." },
  { icon: CalendarDays, t: "Events & notices", d: "Campus events and official announcements, with notifications." },
  { icon: Soup, t: "Canteen", d: "Today's menu and prices once the canteen publishes them." },
];

export default async function Home() {
  if ((await auth())?.user) redirect("/dashboard");
  return (
    <div className="bg-atmosphere min-h-dvh">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        <div className="flex items-center gap-2"><ThemeToggle /><Link href="/login" className="rounded-ctl px-3 py-2 text-sm font-medium hover:bg-line/50">Sign in</Link>
          <Link href="/register" className="rounded-ctl bg-brand px-4 py-2 text-sm font-medium text-white shadow-card hover:bg-brand-dark">Join</Link></div>
      </header>
      <main id="main">
        <section className="mx-auto grid max-w-6xl items-center gap-6 px-5 pb-16 pt-10 md:grid-cols-2 md:pt-16">
          <div>
            <div className="eyebrow mb-4">{COLLEGE.name} · {COLLEGE.city}</div>
            <h1 className="text-[42px] font-semibold leading-[1.05] md:text-6xl">The digital campus for every student.</h1>
            <p className="mt-5 max-w-md text-base text-muted">Classes, assignments, notes, events and a community Lost &amp; Found — organised in one calm, fast portal.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/register" className="inline-flex h-11 items-center gap-2 rounded-ctl bg-brand px-5 text-sm font-medium text-white shadow-lift transition-all hover:-translate-y-0.5 hover:bg-brand-dark">Get started <ArrowRight className="h-4 w-4" /></Link>
              <Link href="/login" className="inline-flex h-11 items-center rounded-ctl hairline bg-surface px-5 text-sm font-medium">Sign in</Link>
            </div>
          </div>
          <div className="relative h-[340px] md:h-[460px]" aria-hidden="true" />
        </section>
        <section className="mx-auto grid max-w-6xl gap-4 px-5 pb-20 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(({ icon: Icon, t, d }, i) => (
            <Reveal key={t} delay={i * 0.05}><div className="h-full rounded-card hairline bg-surface p-6 shadow-card"><span className="mb-4 grid h-10 w-10 place-items-center rounded-ctl bg-brand/10 text-brand dark:text-brass"><Icon className="h-5 w-5" /></span><h3 className="text-lg font-semibold">{t}</h3><p className="mt-1 text-sm text-muted">{d}</p></div></Reveal>
          ))}
        </section>
      </main>
      <footer className="border-t border-line py-6 text-center text-xs text-muted">CampusX is an independent student project and is not the official Study Hall College website. Official site: <a className="underline" href={COLLEGE.website} rel="noreferrer noopener" target="_blank">studyhallcollege.org</a></footer>
    </div>
  );
}
