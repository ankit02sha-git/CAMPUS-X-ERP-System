import { AuthShell } from "@/components/AuthShell";
import { LoginForm } from "@/components/AuthForms";
export const metadata = { title: "Sign in" };
export default function Page() {
  return <AuthShell title="Welcome back" subtitle="Sign in to your CampusX account."><LoginForm /></AuthShell>;
}
