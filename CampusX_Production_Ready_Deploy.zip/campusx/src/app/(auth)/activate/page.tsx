import { AuthShell } from "@/components/AuthShell";
import { ActivationFlow } from "@/components/ActivationFlow";

export const metadata = { title: "Activate Student Account · CampusX" };

export default function ActivatePage() {
  return (
    <AuthShell title="Activate Student Account" subtitle="Enter your official Student ID to verify and set up your password.">
      <ActivationFlow />
    </AuthShell>
  );
}
