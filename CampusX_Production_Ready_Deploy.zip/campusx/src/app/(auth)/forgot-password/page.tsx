import { AuthShell } from "@/components/AuthShell";
import { ForgotPasswordFlow } from "@/components/ForgotPasswordFlow";

export const metadata = { title: "Forgot Password · CampusX" };

export default function ForgotPasswordPage() {
  return (
    <AuthShell title="Reset Password" subtitle="Enter your Student ID to receive a verification OTP on your registered mobile.">
      <ForgotPasswordFlow />
    </AuthShell>
  );
}
