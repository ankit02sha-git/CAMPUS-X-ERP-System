import { NextResponse } from "next/server";
import { getCurrentUser } from "@/server/guards";
import { getMessages } from "@/server/lost";

// Polled by the chat UI. Swap for SSE/WebSocket later without changing the data model.
export async function GET(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id") ?? "";
  const data = await getMessages(id.slice(0, 60), u.id);
  if (!data) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ messages: data.messages });
}
