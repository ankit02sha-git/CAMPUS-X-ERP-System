import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { UPLOAD_DIR } from "@/server/upload";

const TYPES: Record<string, string> = { jpg: "image/jpeg", png: "image/png", webp: "image/webp", pdf: "application/pdf" };

// Local-dev storage fallback. Requires a signed-in user. Strict filename check prevents path traversal.
export async function GET(_: Request, { params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  if (!(await auth())?.user) return new NextResponse("Unauthorized", { status: 401 });
  if (!/^[a-f0-9]{32}\.(jpg|png|webp|pdf)$/.test(name)) return new NextResponse("Not found", { status: 404 });
  try {
    const data = await readFile(path.join(UPLOAD_DIR, name));
    return new NextResponse(data, { headers: { "Content-Type": TYPES[name.split(".")[1]], "Cache-Control": "private, max-age=86400", "X-Content-Type-Options": "nosniff" } });
  } catch { return new NextResponse("Not found", { status: 404 }); }
}
