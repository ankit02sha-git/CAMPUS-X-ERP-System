import { NextResponse } from "next/server";
import { getCurrentUser } from "@/server/guards";
import { rateLimit } from "@/server/ratelimit";
import { storeFile, UploadError } from "@/server/upload";

const KINDS = { lost: "image", response: "image", profile: "image", event: "image", canteen: "image", note: "document", assignment: "document" } as const;
const ADMIN_ONLY = new Set(["event", "canteen", "note", "assignment"]);

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  if (!rateLimit(`upload:${user.id}`, 30, 10 * 60_000)) return NextResponse.json({ error: "Too many uploads. Try again shortly." }, { status: 429 });
  try {
    const form = await req.formData();
    const purpose = String(form.get("purpose") ?? "") as keyof typeof KINDS;
    const file = form.get("file");
    if (!(purpose in KINDS) || !(file instanceof File)) return NextResponse.json({ error: "Invalid upload request." }, { status: 400 });
    if (ADMIN_ONLY.has(purpose) && user.role !== "ADMIN") return NextResponse.json({ error: "Not allowed." }, { status: 403 });
    const res = await storeFile(file, KINDS[purpose], purpose);
    return NextResponse.json(res);
  } catch (e) {
    if (e instanceof UploadError) return NextResponse.json({ error: e.message }, { status: 400 });
    console.error("upload failed", e);
    return NextResponse.json({ error: "Upload failed. Please try again." }, { status: 500 });
  }
}
