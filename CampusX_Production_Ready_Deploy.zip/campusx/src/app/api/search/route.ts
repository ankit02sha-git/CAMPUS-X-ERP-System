import { and, eq, or } from "drizzle-orm";
import { ilike } from "@/server/db/like";
import { NextResponse } from "next/server";
import { db } from "@/server/db";
import { announcements, assignments, courses, events, lostPosts, notes, timetable, facultyDirectory, academicCalendarEvents } from "@/server/db/schema";
import { getCurrentUser } from "@/server/guards";
import { rateLimit } from "@/server/ratelimit";

const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");

export async function GET(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!rateLimit(`search:${u.id}`, 60, 60_000)) return NextResponse.json({ hits: [] }, { status: 429 });
  const q = new URL(req.url).searchParams.get("q")?.trim().slice(0, 80) ?? "";
  if (q.length < 2) return NextResponse.json({ hits: [] });
  const like = `%${esc(q)}%`;
  const [n, e, a, as, t, l, c, fac, cal] = await Promise.all([
    db.select({ id: notes.id, title: notes.title, subject: notes.subject }).from(notes).where(or(ilike(notes.title, like), ilike(notes.subject, like))).limit(4),
    db.select({ id: events.id, title: events.title }).from(events).where(and(eq(events.status, "PUBLISHED"), or(ilike(events.title, like), ilike(events.location, like)))).limit(4),
    db.select({ id: announcements.id, title: announcements.title }).from(announcements).where(and(eq(announcements.published, true), or(ilike(announcements.title, like), ilike(announcements.content, like)))).limit(4),
    db.select({ id: assignments.id, title: assignments.title, subject: assignments.subject }).from(assignments).where(or(ilike(assignments.title, like), ilike(assignments.subject, like))).limit(4),
    db.select({ id: timetable.id, subject: timetable.subject, faculty: timetable.faculty, room: timetable.room }).from(timetable).where(or(ilike(timetable.subject, like), ilike(timetable.faculty, like))).limit(4),
    db.select({ id: lostPosts.id, title: lostPosts.title, location: lostPosts.location, kind: lostPosts.kind }).from(lostPosts).where(and(eq(lostPosts.hidden, false), or(ilike(lostPosts.title, like), ilike(lostPosts.location, like), ilike(lostPosts.description, like)))).limit(4),
    db.select({ code: courses.code, name: courses.name }).from(courses).where(and(eq(courses.active, true), or(ilike(courses.name, like), ilike(courses.code, like)))).limit(4),
    db.select({ id: facultyDirectory.id, name: facultyDirectory.name, department: facultyDirectory.department }).from(facultyDirectory).where(and(eq(facultyDirectory.active, true), or(ilike(facultyDirectory.name, like), ilike(facultyDirectory.subjectsTaught, like)))).limit(4),
    db.select({ id: academicCalendarEvents.id, title: academicCalendarEvents.title, startDate: academicCalendarEvents.startDate }).from(academicCalendarEvents).where(or(ilike(academicCalendarEvents.title, like), ilike(academicCalendarEvents.description, like))).limit(4),
  ]);
  const hits = [
    ...l.map((x) => ({ group: "Lost & Found", title: x.title, sub: `${x.kind} · ${x.location}`, href: `/lost-found/${x.id}` })),
    ...e.map((x) => ({ group: "Events", title: x.title, href: `/events?id=${x.id}` })),
    ...a.map((x) => ({ group: "Announcements", title: x.title, href: `/announcements?id=${x.id}` })),
    ...as.map((x) => ({ group: "Assignments", title: x.title, sub: x.subject, href: "/assignments" })),
    ...n.map((x) => ({ group: "Notes", title: x.title, sub: x.subject, href: `/notes?q=${encodeURIComponent(x.title)}` })),
    ...t.map((x) => ({ group: "Timetable", title: x.subject, sub: [x.faculty, x.room].filter(Boolean).join(" · "), href: "/timetable" })),
    ...fac.map((x) => ({ group: "Faculty", title: x.name, sub: x.department, href: "/faculty" })),
    ...cal.map((x) => ({ group: "Calendar", title: x.title, sub: x.startDate, href: "/academic-calendar" })),
    ...c.map((x) => ({ group: "Courses", title: x.name, sub: x.code, href: "/campus" })),
  ];
  return NextResponse.json({ hits });
}
