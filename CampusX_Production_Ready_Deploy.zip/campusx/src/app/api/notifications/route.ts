import { and, desc, eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/server/db";
import { notifications } from "@/server/db/schema";
import { getCurrentUser } from "@/server/guards";

export async function GET() {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const items = await db.select().from(notifications).where(eq(notifications.userId, u.id)).orderBy(desc(notifications.createdAt)).limit(30);
  return NextResponse.json({ items });
}
export async function POST(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = z.object({ ids: z.array(z.string().max(60)).max(100).optional() }).safeParse(await req.json().catch(() => ({})));
  if (!body.success) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  const own = eq(notifications.userId, u.id);
  await db.update(notifications).set({ read: true }).where(body.data.ids ? and(own, inArray(notifications.id, body.data.ids)) : own);
  return NextResponse.json({ ok: true });
}
