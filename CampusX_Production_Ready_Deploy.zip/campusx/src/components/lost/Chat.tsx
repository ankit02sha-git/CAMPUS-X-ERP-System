"use client";
import { Send } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { sendMessage } from "@/actions/lost";
import { timeAgo } from "@/lib/utils";

type M = { id: string; body: string; senderId: string; createdAt: string | Date };

/** Polling chat (every 6s while visible). Replace the poll with SSE/WebSocket later — same API shape. */
export function Chat({ threadId, viewerId, initial }: { threadId: string; viewerId: string; initial: M[] }) {
  const [msgs, setMsgs] = useState<M[]>(initial);
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const t = setInterval(async () => {
      if (document.hidden) return;
      try { const r = await fetch(`/api/lost/threads?id=${threadId}`, { cache: "no-store" }); if (r.ok) setMsgs((await r.json()).messages); } catch {}
    }, 6000);
    return () => clearInterval(t);
  }, [threadId]);
  useEffect(() => end.current?.scrollIntoView({ block: "nearest" }), [msgs.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim(); if (!body) return;
    setBusy(true); setErr("");
    const res = await sendMessage(threadId, body);
    setBusy(false);
    if (res.error) return setErr(res.error);
    setMsgs((m) => [...m, { id: `tmp-${Date.now()}`, body, senderId: viewerId, createdAt: new Date().toISOString() }]); setText("");
  }
  return (
    <div className="flex h-[380px] flex-col">
      <div className="flex-1 space-y-2 overflow-y-auto rounded-ctl bg-raised p-3" aria-live="polite">
        {msgs.map((m) => { const mine = m.senderId === viewerId; return (
          <div key={m.id} className={`flex ${mine ? "justify-end" : ""}`}><div className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${mine ? "bg-brand text-brand-fg" : "hairline bg-surface"}`}>{m.body}<div className={`mt-0.5 text-[10px] ${mine ? "opacity-70" : "text-muted"}`}>{timeAgo(m.createdAt)}</div></div></div>); })}
        <div ref={end} />
      </div>
      {err && <p role="alert" className="mt-1 text-xs text-danger">{err}</p>}
      <form onSubmit={send} className="mt-2 flex gap-2">
        <input value={text} onChange={(e) => setText(e.target.value)} maxLength={1000} placeholder="Write a message…" aria-label="Message" className="h-10 flex-1 rounded-ctl hairline bg-surface px-3 text-sm focus-visible:shadow-ring" />
        <button disabled={busy || !text.trim()} className="grid h-10 w-10 place-items-center rounded-ctl bg-brand text-brand-fg disabled:opacity-50" aria-label="Send"><Send className="h-4 w-4" /></button>
      </form>
    </div>
  );
}
