"use client";
import { useActionState, useEffect, useState, useTransition } from "react";
import { CheckCircle2, Flag, HandHeart, MessageCircle, Pencil, Trash2, XCircle } from "lucide-react";
import Link from "next/link";
import { contactPoster, deleteLostPost, reportPost, setLostHidden, setLostStatus, submitResponse } from "@/actions/lost";
import type { FormState } from "@/actions/auth";
import { ImageUpload } from "@/components/ImageUpload";
import { Modal } from "@/components/ui/Modal";
import { Button, Field, Input, Textarea } from "@/components/ui";

const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });

function ResponseForm({ postId, kind, onDone }: { postId: string; kind: "LOST" | "FOUND"; onDone: () => void }) {
  const [state, action, pending] = useActionState<FormState, FormData>(submitResponse, undefined);
  const e = state?.fieldErrors ?? {};
  const ok = !!e._ok;
  useEffect(() => { if (ok) { const t = setTimeout(onDone, 1400); return () => clearTimeout(t); } }, [ok, onDone]);
  if (ok) return <div className="py-8 text-center"><CheckCircle2 className="mx-auto mb-3 h-10 w-10 text-ok" /><p className="font-medium">Sent. The poster has been notified.</p><p className="mt-1 text-sm text-muted">You can continue the conversation from this page.</p></div>;
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="postId" value={postId} />
      <Field label="Message" error={e.message}><Textarea name="message" required maxLength={800} placeholder={kind === "LOST" ? "Hi, I think I found your item…" : "Hi, I believe this is mine…"} /></Field>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={kind === "LOST" ? "Where you found it" : "Where you lost it"} error={e.foundAt}><Input name="foundAt" required /></Field>
        <Field label="Date" error={e.foundOn}><Input type="date" name="foundOn" required defaultValue={today()} max={today()} /></Field>
      </div>
      <ImageUpload name="imageUrl" purpose="response" label="Photo (optional)" />
      <Field label="Contact info (optional)" hint="Only the poster will see this. Chat inside CampusX is safer." error={e.contactInfo}><Input name="contactInfo" maxLength={120} /></Field>
      {state?.error && <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger">{state.error}</p>}
      <Button type="submit" loading={pending} className="w-full">Submit response</Button>
    </form>
  );
}

function ContactForm({ postId }: { postId: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(contactPoster.bind(null, postId), undefined);
  return (
    <form action={action} className="space-y-4">
      <Field label="Message" error={state?.fieldErrors?.body}><Textarea name="body" required maxLength={1000} placeholder="Write a short message…" /></Field>
      {state?.error && <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger">{state.error}</p>}
      <Button type="submit" loading={pending} className="w-full">Send privately</Button>
    </form>
  );
}

function ReportForm({ postId, onDone }: { postId: string; onDone: () => void }) {
  const [state, action, pending] = useActionState<FormState, FormData>(reportPost, undefined);
  if (state?.fieldErrors?._ok) return <div className="py-6 text-center"><CheckCircle2 className="mx-auto mb-3 h-9 w-9 text-ok" /><p className="font-medium">Thanks — admins will review this.</p><Button variant="outline" className="mt-4" onClick={onDone}>Close</Button></div>;
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="postId" value={postId} />
      <Field label="What's wrong with this post?" error={state?.fieldErrors?.reason}><Textarea name="reason" required maxLength={500} placeholder="Spam, inappropriate content, misleading…" /></Field>
      {state?.error && <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger">{state.error}</p>}
      <Button type="submit" variant="danger" loading={pending} className="w-full">Submit report</Button>
    </form>
  );
}

export function PostActions({ post, isOwner, isAdmin }: { post: { id: string; kind: "LOST" | "FOUND"; status: string; hidden: boolean }; isOwner: boolean; isAdmin: boolean }) {
  const [modal, setModal] = useState<null | "respond" | "contact" | "report">(null);
  const [pending, start] = useTransition();
  const open = post.status === "LOST" || post.status === "POSSIBLY_FOUND";
  const close = () => setModal(null);
  return (
    <div className="space-y-2">
      {!isOwner && open && (
        <>
          <Button className="w-full" onClick={() => setModal("respond")}><HandHeart className="h-4 w-4" />{post.kind === "LOST" ? "I found this" : "This is mine"}</Button>
          <Button variant="outline" className="w-full" onClick={() => setModal("contact")}><MessageCircle className="h-4 w-4" />Contact poster</Button>
        </>
      )}
      {isOwner && (
        <>
          {open && <Button className="w-full" loading={pending} onClick={() => start(() => setLostStatus(post.id, "FOUND"))}><CheckCircle2 className="h-4 w-4" />Mark as found</Button>}
          {open && <Button variant="outline" className="w-full" loading={pending} onClick={() => start(() => setLostStatus(post.id, "CLOSED"))}><XCircle className="h-4 w-4" />Close notice</Button>}
          {!open && <Button variant="outline" className="w-full" loading={pending} onClick={() => start(() => setLostStatus(post.id, "LOST"))}>Reopen notice</Button>}
        </>
      )}
      {(isOwner || isAdmin) && (
        <div className="grid grid-cols-2 gap-2">
          <Link href={`/lost-found/${post.id}/edit`}><Button variant="outline" size="sm" className="w-full"><Pencil className="h-3.5 w-3.5" />Edit</Button></Link>
          <Button variant="outline" size="sm" loading={pending} onClick={() => { if (confirm("Delete this notice permanently?")) start(() => deleteLostPost(post.id)); }}><Trash2 className="h-3.5 w-3.5" />Delete</Button>
        </div>
      )}
      {isAdmin && (
        <div className="rounded-ctl border border-dashed border-line p-2.5"><div className="eyebrow mb-2">Moderation</div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" loading={pending} onClick={() => start(() => setLostHidden(post.id, !post.hidden))}>{post.hidden ? "Unhide" : "Hide"}</Button>
            {(["LOST", "POSSIBLY_FOUND", "FOUND", "CLOSED"] as const).map((s) => <Button key={s} size="sm" variant={post.status === s ? "primary" : "ghost"} loading={pending} onClick={() => start(() => setLostStatus(post.id, s))}>{s.replace("_", " ")}</Button>)}
          </div></div>
      )}
      {!isOwner && <button onClick={() => setModal("report")} className="mx-auto flex items-center gap-1.5 pt-1 text-xs text-muted hover:text-danger"><Flag className="h-3.5 w-3.5" />Report this post</button>}
      <Modal open={modal === "respond"} onClose={close} title={post.kind === "LOST" ? "I found this" : "This is mine"}><ResponseForm postId={post.id} kind={post.kind} onDone={close} /></Modal>
      <Modal open={modal === "contact"} onClose={close} title="Contact poster"><ContactForm postId={post.id} /></Modal>
      <Modal open={modal === "report"} onClose={close} title="Report post"><ReportForm postId={post.id} onDone={close} /></Modal>
    </div>
  );
}
