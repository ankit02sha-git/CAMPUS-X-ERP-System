"use client";
import { useActionState } from "react";
import { createLostPost, updateLostPost } from "@/actions/lost";
import type { FormState } from "@/actions/auth";
import { ImageUpload } from "@/components/ImageUpload";
import { Button, Field, Input, Select, Textarea } from "@/components/ui";

type Cat = { id: string; name: string };
type Initial = { id: string; kind: "LOST" | "FOUND"; title: string; categoryId: string; description: string; location: string; occurredOn: string; approxTime: string | null; details: string | null; contactPref: string; image: string | null };

export function LostPostForm({ categories, initial, defaultKind = "LOST" }: { categories: Cat[]; initial?: Initial; defaultKind?: "LOST" | "FOUND" }) {
  const action = initial ? updateLostPost.bind(null, initial.id) : createLostPost;
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, undefined);
  const e = state?.fieldErrors ?? {};
  const kind = initial?.kind ?? defaultKind;
  const today = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
  return (
    <form action={formAction} className="grid gap-5 md:grid-cols-5">
      <input type="hidden" name="kind" value={kind} />
      <div className="space-y-4 md:col-span-3">
        <Field label={kind === "LOST" ? "Item name" : "What did you find?"} error={e.title}><Input name="title" defaultValue={initial?.title} required maxLength={80} placeholder="e.g. Black wallet" /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Category" error={e.categoryId}><Select name="categoryId" required defaultValue={initial?.categoryId ?? ""}><option value="" disabled>Select</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
          <Field label={kind === "LOST" ? "Location lost" : "Location found"} error={e.location}><Input name="location" defaultValue={initial?.location} required placeholder="e.g. Library" /></Field>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={kind === "LOST" ? "Date lost" : "Date found"} error={e.occurredOn}><Input type="date" name="occurredOn" max={today} defaultValue={initial?.occurredOn ?? today} required /></Field>
          <Field label="Approximate time" hint="Optional" error={e.approxTime}><Input name="approxTime" defaultValue={initial?.approxTime ?? ""} placeholder="e.g. around 2 PM" /></Field>
        </div>
        <Field label="Description" error={e.description}><Textarea name="description" defaultValue={initial?.description} required maxLength={1000} placeholder="Colour, brand, size, what it looks like…" /></Field>
        <Field label="Identifying details" hint="Optional. Only you and admins can see this — use it to verify a real owner/finder (e.g. what's inside)." error={e.details}><Textarea name="details" defaultValue={initial?.details ?? ""} maxLength={500} className="min-h-[72px]" /></Field>
        <Field label="How should people reach you?" error={e.contactPref}>
          <Select name="contactPref" defaultValue={initial?.contactPref ?? "IN_APP"}><option value="IN_APP">Through CampusX messages (private)</option><option value="PICKUP_AT_OFFICE">Hand over at the college office</option></Select>
        </Field>
      </div>
      <div className="space-y-4 md:col-span-2">
        <ImageUpload name="imageUrl" purpose="lost" initialUrl={initial?.image} label="Photo (optional)" />
        <p className="rounded-ctl bg-brass/10 p-3 text-xs text-muted">Your phone number and email are never shown. People contact you through CampusX only.</p>
        {state?.error && <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger">{state.error}</p>}
        <Button type="submit" loading={pending} className="w-full">{initial ? "Save changes" : kind === "LOST" ? "Post lost notice" : "Post found notice"}</Button>
      </div>
    </form>
  );
}
