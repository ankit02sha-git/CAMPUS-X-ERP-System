import { Badge } from "@/components/ui";
type S = "LOST" | "POSSIBLY_FOUND" | "FOUND" | "CLOSED";
export function statusLabel(kind: "LOST" | "FOUND", s: S) {
  if (kind === "FOUND") return { LOST: "Awaiting owner", POSSIBLY_FOUND: "Claim received", FOUND: "Returned", CLOSED: "Closed" }[s];
  return { LOST: "Still lost", POSSIBLY_FOUND: "Possibly found", FOUND: "Found", CLOSED: "Closed" }[s];
}
export function StatusBadge({ kind, status }: { kind: "LOST" | "FOUND"; status: S }) {
  const tone = status === "FOUND" ? "ok" : status === "POSSIBLY_FOUND" ? "brass" : status === "CLOSED" ? "neutral" : "warn";
  return <Badge tone={tone}>{statusLabel(kind, status)}</Badge>;
}
