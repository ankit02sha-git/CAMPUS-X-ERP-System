/* eslint-disable @next/next/no-img-element */
/** Official Study Hall College logo (public/brand/shc-logo.png) + CampusX sub-brand.
 *  Swap the PNG for the official high-resolution asset at any time; no code change needed. */
export function Logo({ compact = false, onDark = false }: { compact?: boolean; onDark?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <span className={onDark ? "rounded-lg bg-white px-2 py-1 shadow-sm" : ""}>
        <img src="/brand/shc-logo.png" alt="Study Hall College" className={compact ? "h-7 w-auto" : "h-9 w-auto"} />
      </span>
      {!compact && (
        <span className={`border-l pl-3 leading-none ${onDark ? "border-white/25" : "border-line"}`}>
          <span className={`block font-display text-[19px] font-extrabold tracking-tight ${onDark ? "text-white" : "text-navy dark:text-white"}`}>Campus<span className="text-brand dark:text-brass">X</span></span>
          <span className={`mt-1 block text-[9px] font-semibold uppercase tracking-[0.16em] ${onDark ? "text-white/60" : "text-muted"}`}>Student Portal</span>
        </span>
      )}
    </div>
  );
}
