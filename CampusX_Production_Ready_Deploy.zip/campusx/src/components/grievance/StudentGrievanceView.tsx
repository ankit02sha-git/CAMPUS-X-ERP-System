"use client";

import React, { useState } from "react";
import { GrievanceTicket } from "@/server/db/schema";
import { submitGrievanceTicketAction } from "@/actions/grievance";
import { LifeBuoy, PlusCircle, MessageSquare, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface StudentGrievanceViewProps {
  initialTickets: GrievanceTicket[];
}

export function StudentGrievanceView({ initialTickets }: StudentGrievanceViewProps) {
  const [tickets, setTickets] = useState<GrievanceTicket[]>(initialTickets);
  const [isCreating, setIsCreating] = useState(false);
  const [category, setCategory] = useState<"ACADEMIC" | "FEE" | "TIMETABLE" | "INFRASTRUCTURE" | "TECHNICAL">("ACADEMIC");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) return;
    setIsSubmitting(true);
    setMessage(null);

    try {
      const newTicket = await submitGrievanceTicketAction(category, subject, description);
      setTickets([newTicket, ...tickets]);
      setSubject("");
      setDescription("");
      setIsCreating(false);
      setMessage(`Ticket ${newTicket.ticketNumber} successfully submitted.`);
    } catch (err: any) {
      setMessage("Error submitting ticket: " + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-6 hairline shadow-sm">
        <div>
          <h1 className="text-xl font-extrabold text-ink sm:text-2xl flex items-center gap-2">
            <LifeBuoy className="h-6 w-6 text-brand" /> Grievance & Student Help Desk
          </h1>
          <p className="text-xs text-muted">
            Submit queries, report academic or infrastructure issues, and track official administration resolution.
          </p>
        </div>

        <button
          onClick={() => setIsCreating(!isCreating)}
          className="flex items-center gap-2 rounded-ctl bg-brand px-4 py-2.5 text-xs font-bold text-white shadow-md hover:bg-brand-dark transition-all self-start sm:self-auto"
        >
          <PlusCircle className="h-4 w-4" /> {isCreating ? "Cancel Ticket Form" : "Raise Support Ticket"}
        </button>
      </div>

      {message && (
        <div className="rounded-ctl bg-brand/10 border border-brand/30 p-3 text-xs font-semibold text-brand dark:text-sky-300">
          {message}
        </div>
      )}

      {/* New Ticket Form */}
      {isCreating && (
        <form onSubmit={handleSubmit} className="rounded-card glass p-5 hairline shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-ink">New Support Ticket Details</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-muted uppercase mb-1 block">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-semibold text-ink"
              >
                <option value="ACADEMIC">Academic Issue</option>
                <option value="FEE">Fee / Receipt Issue</option>
                <option value="TIMETABLE">Timetable / Slot Query</option>
                <option value="INFRASTRUCTURE">Infrastructure / Facilities</option>
                <option value="TECHNICAL">Technical / Portal Issue</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-muted uppercase mb-1 block">Subject</label>
              <input
                type="text"
                required
                placeholder="Brief summary of the issue..."
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-semibold text-ink"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-muted uppercase mb-1 block">Detailed Description</label>
            <textarea
              required
              rows={4}
              placeholder="Provide clear details to help administration resolve your query quickly..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-ctl glass-input p-3 text-xs text-ink"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="rounded-ctl bg-navy-deep px-5 py-2 text-xs font-bold text-white shadow-md hover:bg-navy-deep/90 transition-all"
            >
              {isSubmitting ? "Submitting..." : "Submit Ticket"}
            </button>
          </div>
        </form>
      )}

      {/* Tickets List */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-ink">My Submitted Support Tickets ({tickets.length})</h2>

        {tickets.length === 0 ? (
          <div className="rounded-card glass p-8 text-center text-muted hairline">
            You have not raised any support tickets yet.
          </div>
        ) : (
          tickets.map((t) => (
            <div key={t.id} className="rounded-card glass p-5 hairline shadow-sm space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-line pb-2 gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-brand dark:text-shcyellow">{t.ticketNumber}</span>
                  <span className="rounded-full bg-surface px-2 py-0.5 text-[10px] font-bold uppercase text-muted border border-line">
                    {t.category}
                  </span>
                </div>

                <span
                  className={cn(
                    "rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase shadow-xs self-start sm:self-auto",
                    t.status === "RESOLVED" || t.status === "CLOSED"
                      ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30"
                      : t.status === "IN_PROGRESS"
                      ? "bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30"
                      : "bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/30"
                  )}
                >
                  {t.status}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-ink">{t.subject}</h3>
                <p className="text-xs text-muted leading-relaxed mt-1">{t.description}</p>
              </div>

              {t.adminResponse && (
                <div className="rounded-ctl bg-brand/5 border border-brand/20 p-3 text-xs text-ink space-y-1">
                  <span className="font-bold text-brand dark:text-sky-300 flex items-center gap-1.5">
                    <MessageSquare className="h-3.5 w-3.5" /> Administration Resolution Response:
                  </span>
                  <p className="text-muted leading-relaxed">{t.adminResponse}</p>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
