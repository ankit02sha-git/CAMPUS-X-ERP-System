"use client";

import React, { useState } from "react";
import { AcademicCalendarEvent } from "@/server/db/schema";
import { Calendar as CalendarIcon, Clock, Filter, Sparkles, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface AcademicCalendarViewProps {
  events: AcademicCalendarEvent[];
}

const CATEGORY_LABELS: Record<string, { label: string; color: string }> = {
  SEMESTER_START: { label: "Semester Start", color: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/30" },
  SEMESTER_END: { label: "Semester End", color: "bg-purple-500/20 text-purple-700 dark:text-purple-300 border-purple-500/30" },
  EXAM: { label: "Exam Date", color: "bg-rose-500/20 text-rose-700 dark:text-rose-300 border-rose-500/30" },
  HOLIDAY: { label: "College Holiday", color: "bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/30" },
  EVENT: { label: "Campus Fest / Event", color: "bg-blue-500/20 text-blue-700 dark:text-blue-300 border-blue-500/30" },
  DEADLINE: { label: "Assignment Deadline", color: "bg-red-500/20 text-red-700 dark:text-red-300 border-red-500/30" },
  COLLEGE_DATE: { label: "Important College Date", color: "bg-brand/20 text-brand dark:text-sky-300 border-brand/30" },
};

export function AcademicCalendarView({ events }: AcademicCalendarViewProps) {
  const [filterCategory, setFilterCategory] = useState<string>("ALL");

  const filteredEvents = events.filter(
    (e) => filterCategory === "ALL" || e.category === filterCategory
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-6 hairline shadow-sm">
        <div>
          <h1 className="text-xl font-extrabold text-ink sm:text-2xl flex items-center gap-2">
            <CalendarIcon className="h-6 w-6 text-brand" /> Academic Calendar 2026-27
          </h1>
          <p className="text-xs text-muted">
            Official key dates for semester commencement, examination weeks, holidays, and campus events.
          </p>
        </div>

        {/* Filter Category */}
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="rounded-ctl glass-input px-3.5 py-2 text-xs font-semibold text-ink"
        >
          <option value="ALL">All Categories</option>
          {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v.label}
            </option>
          ))}
        </select>
      </div>

      {/* Calendar Items Timeline / List */}
      <div className="space-y-3">
        {filteredEvents.length === 0 ? (
          <div className="rounded-card glass p-8 text-center text-muted hairline">
            No academic calendar entries found.
          </div>
        ) : (
          filteredEvents.map((ev) => {
            const meta = CATEGORY_LABELS[ev.category] || CATEGORY_LABELS.COLLEGE_DATE;
            return (
              <div
                key={ev.id}
                className="rounded-card glass p-4 hairline shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:shadow-md transition-all"
              >
                <div className="flex items-start gap-3.5">
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-surface hairline text-brand font-bold text-center">
                    <span className="text-[10px] uppercase text-muted block leading-none">
                      {new Date(ev.startDate).toLocaleString("en-US", { month: "short" })}
                    </span>
                    <span className="text-base font-extrabold text-ink leading-tight">
                      {new Date(ev.startDate).getDate()}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={cn("rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase", meta.color)}>
                        {meta.label}
                      </span>
                      {ev.endDate && (
                        <span className="text-[10px] font-medium text-muted">
                          Thru {ev.endDate}
                        </span>
                      )}
                    </div>

                    <h3 className="font-bold text-sm text-ink">{ev.title}</h3>
                    {ev.description && (
                      <p className="text-xs text-muted mt-0.5">{ev.description}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
