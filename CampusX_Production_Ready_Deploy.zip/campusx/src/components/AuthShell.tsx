import Link from "next/link";
import { Logo } from "@/components/Logo";
export function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <main id="main" className="bg-atmosphere grid min-h-dvh place-items-center px-4 py-10">
      <div className="w-full max-w-[420px]">
        <Link href="/" className="mb-8 block w-fit"><Logo /></Link>
        <div className="rounded-card hairline glass p-7 shadow-lift">
          <h1 className="text-2xl font-semibold">{title}</h1>
          <p className="mb-6 mt-1 text-sm text-muted">{subtitle}</p>
          {children}
        </div>
        <p className="mt-5 text-center text-xs text-muted">Student portal for Study Hall College, Lucknow. Unofficial student project.</p>
      </div>
    </main>
  );
}
