"use client";
import { useTransition } from "react";
import { setUserActive, setUserRole } from "@/actions/admin";
import { Badge, Button } from "@/components/ui";

export function UserActions({ id, active, role, isSelf }: { id: string; active: boolean; role: "STUDENT" | "ADMIN"; isSelf: boolean }) {
  const [p, s] = useTransition();
  if (isSelf) return <Badge>You</Badge>;
  return (
    <div className="flex flex-wrap justify-end gap-1.5">
      <Button size="sm" variant="outline" loading={p} onClick={() => s(() => setUserActive(id, !active))}>{active ? "Deactivate" : "Activate"}</Button>
      <Button size="sm" variant="outline" loading={p} onClick={() => { if (role === "STUDENT" ? confirm("Grant admin access to this user?") : true) s(() => setUserRole(id, role === "ADMIN" ? "STUDENT" : "ADMIN")); }}>{role === "ADMIN" ? "Make student" : "Make admin"}</Button>
    </div>
  );
}
