"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

interface AdminNavTabsProps {
  tabs: Array<[string, string]>;
}

/**
 * Interactive Admin Navigation Tabs
 * Displays top navigation bar for the Admin Control Panel with active state highlighting.
 */
export function AdminNavTabs({ tabs }: AdminNavTabsProps) {
  const pathname = usePathname();

  return (
    <nav aria-label="Admin navigation tabs" className="flex gap-1.5 overflow-x-auto pb-1 border-b border-line">
      {tabs.map(([href, label]) => {
        // Match exact route for /admin, or prefix match for sub-routes like /admin/users
        const isActive = pathname === href || (href !== "/admin" && pathname.startsWith(href));
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "whitespace-nowrap rounded-ctl px-4 py-2 text-xs font-semibold transition-all duration-fast",
              isActive
                ? "bg-navy-deep text-white shadow-sm"
                : "hairline bg-surface text-muted hover:bg-raised hover:text-ink"
            )}
          >
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
