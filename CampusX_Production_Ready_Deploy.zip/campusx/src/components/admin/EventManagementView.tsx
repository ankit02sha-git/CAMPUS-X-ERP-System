"use client";

import React, { useState, useMemo } from "react";
import { Plus, Search, Edit2, Trash2, Eye, Sparkles, CheckCircle2, AlertTriangle, X, Loader2, Calendar, MapPin, Tag, Globe, Phone, UserCheck } from "lucide-react";
import type { Event } from "@/server/db/schema";
import { createEventAction, updateEventAction, deleteEventAction, toggleEventPublishAction, toggleEventFeaturedAction, checkDuplicateEventAction } from "@/actions/events";
import { EventDetailModal } from "@/components/events/EventDetailModal";

interface EventManagementViewProps {
  initialEvents: Event[];
}

export function EventManagementView({ initialEvents }: EventManagementViewProps) {
  const [events, setEvents] = useState<Event[]>(initialEvents);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [viewingEvent, setViewingEvent] = useState<Event | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    title: "",
    date: new Date().toISOString().slice(0, 10),
    startDate: new Date().toISOString().slice(0, 10),
    endDate: "",
    datePrecision: "EXACT_DATE" as "EXACT_DATE" | "DATE_RANGE" | "MONTH_ONLY" | "TBD",
    startTime: "",
    endTime: "",
    venue: "",
    organizer: "",
    category: "Cultural",
    customCategory: "",
    tags: "",
    shortDescription: "",
    description: "",
    imageUrl: "",
    registrationEnabled: false,
    registrationUrl: "",
    contactInfo: "",
    featured: false,
    published: true,
    eventStatus: "UPCOMING" as "UPCOMING" | "ONGOING" | "COMPLETED" | "TBD" | "CANCELLED",
  });

  const [customCatActive, setCustomCatActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dupWarning, setDupWarning] = useState<string | null>(null);
  const [formErr, setFormErr] = useState<string | null>(null);

  const categoriesList = ["Cultural", "Sports", "Academic", "Workshop", "Competition", "Seminar", "Orientation", "Freshers", "Festival", "Club Activity", "Other"];

  // Open modal for Create
  const handleOpenCreate = () => {
    setEditingEvent(null);
    setFormData({
      title: "",
      date: new Date().toISOString().slice(0, 10),
      startDate: new Date().toISOString().slice(0, 10),
      endDate: "",
      datePrecision: "EXACT_DATE",
      startTime: "",
      endTime: "",
      venue: "",
      organizer: "",
      category: "Cultural",
      customCategory: "",
      tags: "",
      shortDescription: "",
      description: "",
      imageUrl: "",
      registrationEnabled: false,
      registrationUrl: "",
      contactInfo: "",
      featured: false,
      published: true,
      eventStatus: "UPCOMING",
    });
    setCustomCatActive(false);
    setDupWarning(null);
    setFormErr(null);
    setIsModalOpen(true);
  };

  // Open modal for Edit
  const handleOpenEdit = (ev: Event) => {
    setEditingEvent(ev);
    const isCustom = !categoriesList.includes(ev.category || "");
    setFormData({
      title: ev.title,
      date: ev.date,
      startDate: ev.startDate || ev.date,
      endDate: ev.endDate || "",
      datePrecision: (ev.datePrecision as any) || "EXACT_DATE",
      startTime: ev.startTime || "",
      endTime: ev.endTime || "",
      venue: ev.venue || ev.location || "",
      organizer: ev.organizer || "",
      category: isCustom ? "Other" : ev.category || "Cultural",
      customCategory: isCustom ? ev.category || "" : "",
      tags: ev.tags || "",
      shortDescription: ev.shortDescription || "",
      description: ev.description || "",
      imageUrl: ev.imageUrl || "",
      registrationEnabled: ev.registrationEnabled || false,
      registrationUrl: ev.registrationUrl || "",
      contactInfo: ev.contactInfo || "",
      featured: ev.featured || false,
      published: ev.published,
      eventStatus: (ev.eventStatus as any) || "UPCOMING",
    });
    setCustomCatActive(isCustom);
    setDupWarning(null);
    setFormErr(null);
    setIsModalOpen(true);
  };

  // Check duplicate title warning on blur
  const handleTitleBlur = async () => {
    if (!formData.title.trim()) return;
    const res = await checkDuplicateEventAction(formData.title, formData.date, editingEvent?.id);
    if (res.duplicate && res.warning) {
      setDupWarning(res.warning);
    } else {
      setDupWarning(null);
    }
  };

  // Save Event Action
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setFormErr(null);

    const finalCategory = customCatActive && formData.customCategory.trim() ? formData.customCategory.trim() : formData.category;

    const payload = {
      title: formData.title,
      date: formData.date,
      startDate: formData.startDate || formData.date,
      endDate: formData.endDate || undefined,
      datePrecision: formData.datePrecision,
      startTime: formData.startTime || undefined,
      endTime: formData.endTime || undefined,
      venue: formData.venue || undefined,
      location: formData.venue || undefined,
      organizer: formData.organizer || undefined,
      category: finalCategory,
      tags: formData.tags || undefined,
      shortDescription: formData.shortDescription || undefined,
      description: formData.description || undefined,
      imageUrl: formData.imageUrl || undefined,
      registrationEnabled: formData.registrationEnabled,
      registrationUrl: formData.registrationUrl || undefined,
      contactInfo: formData.contactInfo || undefined,
      featured: formData.featured,
      published: formData.published,
      eventStatus: formData.eventStatus,
      status: formData.published ? "PUBLISHED" : "DRAFT",
    };

    let res;
    if (editingEvent) {
      res = await updateEventAction(editingEvent.id, payload);
    } else {
      res = await createEventAction(payload);
    }

    if (res.success) {
      setIsModalOpen(false);
      window.location.reload();
    } else {
      setFormErr(res.error || "Failed to save event.");
    }
    setLoading(false);
  };

  // Toggle publish
  const handleTogglePublish = async (id: string) => {
    const res = await toggleEventPublishAction(id);
    if (res.success) {
      setEvents((list) => list.map((e) => (e.id === id ? { ...e, published: !e.published, status: !e.published ? "PUBLISHED" : "DRAFT" } : e)));
    }
  };

  // Toggle featured
  const handleToggleFeatured = async (id: string) => {
    const res = await toggleEventFeaturedAction(id);
    if (res.success) {
      setEvents((list) => list.map((e) => (e.id === id ? { ...e, featured: !e.featured } : e)));
    }
  };

  // Delete event
  const handleConfirmDelete = async () => {
    if (!deletingId) return;
    setLoading(true);
    const res = await deleteEventAction(deletingId);
    if (res.success) {
      setEvents((list) => list.filter((e) => e.id !== deletingId));
      setDeletingId(null);
    }
    setLoading(false);
  };

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return events.filter((ev) => {
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        ev.title.toLowerCase().includes(query) ||
        (ev.category || "").toLowerCase().includes(query) ||
        (ev.tags || "").toLowerCase().includes(query) ||
        (ev.venue || ev.location || "").toLowerCase().includes(query);

      let matchesStatus = true;
      if (statusFilter === "PUBLISHED") matchesStatus = ev.published;
      else if (statusFilter === "DRAFT") matchesStatus = !ev.published;
      else if (statusFilter === "UPCOMING") matchesStatus = ev.eventStatus === "UPCOMING";
      else if (statusFilter === "COMPLETED") matchesStatus = ev.eventStatus === "COMPLETED";

      return matchesSearch && matchesStatus;
    });
  }, [events, searchQuery, statusFilter]);

  return (
    <div className="space-y-6">
      {/* Top Action Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Campus Events Manager</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Publish, feature, edit, and organize Study Hall College events.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-white shadow-md hover:bg-blue-700 transition-all shrink-0"
        >
          <Plus className="h-4 w-4" /> Add New Event
        </button>
      </div>

      {/* Toolbar Search & Status Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Filter by title, category, tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-white pl-10 pr-4 py-2 text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto">
          {["ALL", "PUBLISHED", "DRAFT", "UPCOMING", "COMPLETED"].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition-colors ${
                statusFilter === st
                  ? "bg-blue-600 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Events Data Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-100 bg-slate-50 text-slate-500 dark:border-slate-800 dark:bg-slate-800/50">
              <tr>
                <th className="px-4 py-3 font-semibold">Event</th>
                <th className="px-4 py-3 font-semibold">Date</th>
                <th className="px-4 py-3 font-semibold">Category</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold text-center">Published</th>
                <th className="px-4 py-3 font-semibold text-center">Spotlight</th>
                <th className="px-4 py-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredEvents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No matching events found.
                  </td>
                </tr>
              ) : (
                filteredEvents.map((ev) => (
                  <tr key={ev.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-900 dark:text-white">{ev.title}</div>
                      {ev.venue && <div className="text-[11px] text-slate-400 truncate max-w-[200px]">{ev.venue}</div>}
                    </td>

                    <td className="px-4 py-3 font-medium text-slate-600 dark:text-slate-300 whitespace-nowrap">
                      {ev.startDate || ev.date}
                    </td>

                    <td className="px-4 py-3">
                      <span className="inline-flex rounded-md bg-blue-50 px-2 py-0.5 text-[11px] font-semibold text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                        {ev.category}
                      </span>
                    </td>

                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-md px-2 py-0.5 text-[11px] font-semibold ${
                          ev.eventStatus === "UPCOMING"
                            ? "bg-amber-50 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                            : ev.eventStatus === "COMPLETED"
                            ? "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                            : "bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300"
                        }`}
                      >
                        {ev.eventStatus}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => handleTogglePublish(ev.id)}
                        className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold transition-colors ${
                          ev.published
                            ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-200 dark:bg-emerald-950 dark:text-emerald-300"
                            : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400"
                        }`}
                      >
                        {ev.published ? "Published" : "Draft"}
                      </button>
                    </td>

                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => handleToggleFeatured(ev.id)}
                        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-bold transition-colors ${
                          ev.featured
                            ? "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                            : "bg-slate-100 text-slate-400 dark:bg-slate-800"
                        }`}
                      >
                        <Sparkles className="h-3 w-3" /> {ev.featured ? "Spotlight" : "Off"}
                      </button>
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setViewingEvent(ev)}
                          title="Preview"
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(ev)}
                          title="Edit"
                          className="rounded-lg p-1.5 text-blue-600 hover:bg-blue-50 dark:text-blue-400 dark:hover:bg-blue-950"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setDeletingId(ev.id)}
                          title="Delete"
                          className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 dark:border-slate-800 mb-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {editingEvent ? `Edit Event: ${editingEvent.title}` : "Add New Event"}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="rounded-full p-1 text-slate-400 hover:bg-slate-100">
                <X className="h-5 w-5" />
              </button>
            </div>

            {dupWarning && (
              <div className="mb-4 rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs font-semibold text-amber-800 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-300 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                <span>{dupWarning}</span>
              </div>
            )}

            {formErr && (
              <div className="mb-4 rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs font-semibold text-rose-800 dark:border-rose-700 dark:bg-rose-950/60 dark:text-rose-300">
                {formErr}
              </div>
            )}

            <form onSubmit={handleSubmitForm} className="space-y-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Event Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  onBlur={handleTitleBlur}
                  placeholder="e.g. AAGAT, Dandiya Night 2026..."
                  className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                />
              </div>

              {/* Date & Date Precision */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Primary Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value, startDate: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Date Precision</label>
                  <select
                    value={formData.datePrecision}
                    onChange={(e) => setFormData({ ...formData, datePrecision: e.target.value as any })}
                    className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                  >
                    <option value="EXACT_DATE">Exact Date</option>
                    <option value="DATE_RANGE">Date Range</option>
                    <option value="MONTH_ONLY">Month Only</option>
                    <option value="TBD">TBD / Flexible</option>
                  </select>
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Category</label>
                <div className="flex items-center gap-2">
                  <select
                    value={customCatActive ? "Other" : formData.category}
                    onChange={(e) => {
                      if (e.target.value === "Other") {
                        setCustomCatActive(true);
                      } else {
                        setCustomCatActive(false);
                        setFormData({ ...formData, category: e.target.value });
                      }
                    }}
                    className="flex-1 rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                  >
                    {categoriesList.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>

                  {customCatActive && (
                    <input
                      type="text"
                      placeholder="Type custom category..."
                      value={formData.customCategory}
                      onChange={(e) => setFormData({ ...formData, customCategory: e.target.value })}
                      className="flex-1 rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                    />
                  )}
                </div>
              </div>

              {/* Venue & Organizer */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Venue / Location</label>
                  <input
                    type="text"
                    value={formData.venue}
                    onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                    placeholder="e.g. Study Hall Auditorium"
                    className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Organizer / Department</label>
                  <input
                    type="text"
                    value={formData.organizer}
                    onChange={(e) => setFormData({ ...formData, organizer: e.target.value })}
                    placeholder="e.g. Cultural Committee"
                    className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                  />
                </div>
              </div>

              {/* Short Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Short Summary (Card Overview)</label>
                <input
                  type="text"
                  value={formData.shortDescription}
                  onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
                  placeholder="Brief 1-2 sentence overview"
                  className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                />
              </div>

              {/* Full Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Full Description</label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detailed description of the campus event..."
                  className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs font-semibold text-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:text-white"
                />
              </div>

              {/* Switches: Published, Featured, Registration */}
              <div className="flex flex-wrap items-center gap-6 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={formData.published}
                    onChange={(e) => setFormData({ ...formData, published: e.target.checked })}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  Published on Portal
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={formData.featured}
                    onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                    className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                  />
                  Spotlight Featured
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={formData.registrationEnabled}
                    onChange={(e) => setFormData({ ...formData, registrationEnabled: e.target.checked })}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  Student Registration Enabled
                </label>
              </div>

              {/* Form Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white shadow-md hover:bg-blue-700"
                >
                  {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                  {editingEvent ? "Update Event" : "Create Event"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {deletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Delete Event</h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400">
              Are you sure you want to delete this event? This action will archive the event from student view.
            </p>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => setDeletingId(null)}
                className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-400"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={loading}
                className="inline-flex items-center gap-2 rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-rose-700"
              >
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW EVENT PREVIEW MODAL */}
      <EventDetailModal event={viewingEvent} onClose={() => setViewingEvent(null)} />
    </div>
  );
}
