"use client";

import React, { useEffect, useState } from "react";
import { Course } from "@/server/db/schema";
import {
  fetchAdminAttendanceSheetAction,
  saveAdminAttendanceAction,
  fetchAdminDepartmentOverviewAction,
  fetchAdminTimetableSubjectsAction,
} from "@/actions/attendance";
import { AdminAttendanceStudentRow, AdminDepartmentOverview, AdminTimetableSubjectPair } from "@/server/attendance";
import {
  Check,
  X,
  Clock,
  Save,
  UserCheck,
  ShieldAlert,
  CheckSquare,
  AlertTriangle,
  Building2,
  Layers,
  BookOpen,
  Users,
  CalendarOff,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface AdminAttendanceViewProps {
  coursesList: Course[];
  initialOverview?: AdminDepartmentOverview;
}

export function AdminAttendanceView({
  coursesList,
  initialOverview,
}: AdminAttendanceViewProps) {
  const [activeTab, setActiveTab] = useState<"overview" | "register">("overview");

  // Overview State
  const [overview, setOverview] = useState<AdminDepartmentOverview | undefined>(initialOverview);
  const [deptCourseId, setDeptCourseId] = useState<string>(
    initialOverview?.selectedCourseId || coursesList[0]?.id || ""
  );
  const [deptSem, setDeptSem] = useState<number>(initialOverview?.selectedSemester || 5);

  // Register Marking State
  const [selectedCourseId, setSelectedCourseId] = useState<string>(coursesList[0]?.id || "");
  const [semester, setSemester] = useState<number>(5);
  const [section, setSection] = useState<string>("A");
  const [dateStr, setDateStr] = useState<string>(new Date().toISOString().slice(0, 10));

  const [timetablePairs, setTimetablePairs] = useState<AdminTimetableSubjectPair[]>([]);
  const [isTimetableAvailable, setIsTimetableAvailable] = useState<boolean>(true);
  const [timetableMsg, setTimetableMsg] = useState<string>("");
  const [selectedPairKey, setSelectedPairKey] = useState<string>("");

  const [students, setStudents] = useState<AdminAttendanceStudentRow[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Load timetable subjects whenever Course or Semester changes in Register Tab
  useEffect(() => {
    async function loadTimetableSubjects() {
      if (!selectedCourseId) return;
      setIsLoaded(false);
      try {
        const res = await fetchAdminTimetableSubjectsAction(selectedCourseId, semester);
        setIsTimetableAvailable(res.available);
        setTimetableMsg(res.message || "");
        setTimetablePairs(res.pairs);
        if (res.pairs.length > 0) {
          setSelectedPairKey(`${res.pairs[0].subjectName}::${res.pairs[0].facultyName}`);
        } else {
          setSelectedPairKey("");
        }
      } catch (err) {
        console.error("Failed to fetch timetable subjects", err);
      }
    }

    loadTimetableSubjects();
  }, [selectedCourseId, semester]);

  const handleFetchOverview = async (cId: string, sem: number) => {
    setDeptCourseId(cId);
    setDeptSem(sem);
    try {
      const data = await fetchAdminDepartmentOverviewAction(cId, sem);
      setOverview(data);
    } catch (err) {
      console.error("Failed to load department overview:", err);
    }
  };

  const handleLoadSheet = async () => {
    if (!selectedCourseId || !selectedPairKey || !dateStr) return;
    setMessage(null);
    const [subjName] = selectedPairKey.split("::");
    try {
      const res = await fetchAdminAttendanceSheetAction(
        selectedCourseId,
        semester,
        section,
        subjName || selectedPairKey,
        dateStr
      );
      setStudents(res.students);
      setIsLoaded(true);
    } catch (err: any) {
      setMessage("Error loading attendance sheet: " + err.message);
    }
  };

  const handleMarkAllPresent = () => {
    setStudents((prev) => prev.map((s) => ({ ...s, status: "PRESENT" })));
  };

  const handleStatusToggle = (userId: string, nextStatus: "PRESENT" | "ABSENT" | "LATE") => {
    setStudents((prev) =>
      prev.map((s) => (s.userId === userId ? { ...s, status: nextStatus } : s))
    );
  };

  const handleSave = async () => {
    if (students.length === 0) return;
    setIsSaving(true);
    setMessage(null);
    const [subjName] = selectedPairKey.split("::");
    try {
      await saveAdminAttendanceAction(
        selectedCourseId,
        semester,
        section,
        subjName || selectedPairKey,
        dateStr,
        students.map((s) => ({ userId: s.userId, status: s.status }))
      );
      setMessage("Attendance session successfully saved!");
    } catch (err: any) {
      setMessage("Error saving attendance: " + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="rounded-card glass p-5 hairline shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-ink flex items-center gap-2">
            <UserCheck className="h-5 w-5 text-brand" /> Timetable-Driven Faculty Attendance Portal
          </h2>
          <p className="text-xs text-muted">
            All attendance subjects and faculty members are derived strictly from official timetable records.
          </p>
        </div>

        {/* View Mode Switcher */}
        <div className="flex rounded-ctl bg-surface hairline p-1">
          <button
            onClick={() => setActiveTab("overview")}
            className={cn(
              "rounded-ctl px-3 py-1.5 text-xs font-semibold transition-colors",
              activeTab === "overview"
                ? "bg-navy-deep text-white shadow-xs"
                : "text-muted hover:text-ink"
            )}
          >
            Department Analytics & Low Attendance
          </button>
          <button
            onClick={() => setActiveTab("register")}
            className={cn(
              "rounded-ctl px-3 py-1.5 text-xs font-semibold transition-colors",
              activeTab === "register"
                ? "bg-navy-deep text-white shadow-xs"
                : "text-muted hover:text-ink"
            )}
          >
            Mark Daily Class Register
          </button>
        </div>
      </div>

      {/* TAB 1: Department Analytics & Low Attendance Overview */}
      {activeTab === "overview" && (
        <div className="space-y-6">
          {/* Department & Semester Filter Header */}
          <div className="rounded-card glass p-5 hairline space-y-4">
            <h3 className="text-sm font-bold text-ink flex items-center gap-2">
              <Building2 className="h-4 w-4 text-brand" /> Department & Semester Cohort Filter
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Department (Course) Selector */}
              <div>
                <label className="text-[11px] font-bold text-muted uppercase mb-1 block">
                  Select Department / Course
                </label>
                <select
                  value={deptCourseId}
                  onChange={(e) => handleFetchOverview(e.target.value, deptSem)}
                  className="w-full rounded-ctl glass-input px-3.5 py-2.5 text-xs font-bold text-ink"
                >
                  {coursesList.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code} — {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Semester Selector grouped by Academic Year */}
              <div>
                <label className="text-[11px] font-bold text-muted uppercase mb-1 block">
                  Select Semester (Academic Year Cohort)
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleFetchOverview(deptCourseId, 1)}
                    className={cn(
                      "rounded-ctl py-2 px-2 text-center text-xs font-bold transition-all hairline",
                      deptSem === 1 ? "bg-brand text-white shadow-xs" : "bg-surface text-muted hover:text-ink"
                    )}
                  >
                    1st Yr (Sem 1)
                  </button>

                  <button
                    type="button"
                    onClick={() => handleFetchOverview(deptCourseId, 3)}
                    className={cn(
                      "rounded-ctl py-2 px-2 text-center text-xs font-bold transition-all hairline",
                      deptSem === 3 ? "bg-brand text-white shadow-xs" : "bg-surface text-muted hover:text-ink"
                    )}
                  >
                    2nd Yr (Sem 3)
                  </button>

                  <button
                    type="button"
                    onClick={() => handleFetchOverview(deptCourseId, 5)}
                    className={cn(
                      "rounded-ctl py-2 px-2 text-center text-xs font-bold transition-all hairline",
                      deptSem === 5 ? "bg-brand text-white shadow-xs" : "bg-surface text-muted hover:text-ink"
                    )}
                  >
                    3rd Yr (Sem 5)
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto text-[11px] text-muted border-t border-line/60 pt-3">
              <span className="font-semibold text-ink">All Semesters:</span>
              {[1, 2, 3, 4, 5, 6].map((s) => (
                <button
                  key={s}
                  onClick={() => handleFetchOverview(deptCourseId, s)}
                  className={cn(
                    "px-2.5 py-0.5 rounded-ctl font-bold transition-colors",
                    deptSem === s ? "bg-navy-deep text-white" : "hover:text-ink"
                  )}
                >
                  Sem {s}
                </button>
              ))}
            </div>
          </div>

          {/* Department Overview Analytics Cards */}
          {overview && (
            <>
              {!overview.available ? (
                /* RULE 6: Data Not Available Card */
                <div className="rounded-card glass p-8 text-center text-muted hairline space-y-2">
                  <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-surface text-muted border border-line">
                    <CalendarOff className="h-6 w-6" />
                  </div>
                  <h3 className="font-bold text-sm text-ink">Data Not Available</h3>
                  <p className="text-xs text-muted max-w-md mx-auto">
                    {overview.message || "Timetable data is not available for this class/semester yet."}
                  </p>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="rounded-card glass p-5 hairline shadow-sm">
                      <span className="text-[11px] font-semibold text-muted uppercase">Department & Year</span>
                      <div className="mt-1 font-bold text-base text-ink">
                        {overview.selectedCourseCode} • {overview.academicYearLabel} (Sem {overview.selectedSemester})
                      </div>
                      <p className="text-xs text-muted mt-0.5">{overview.selectedCourseName}</p>
                    </div>

                    <div className="rounded-card glass p-5 hairline shadow-sm">
                      <span className="text-[11px] font-semibold text-muted uppercase">Enrolled Students</span>
                      <div className="mt-1 font-extrabold text-2xl text-ink">
                        {overview.enrolledStudentCount}
                      </div>
                      <p className="text-xs text-muted mt-0.5">Active enrolled students in this semester</p>
                    </div>

                    <div className="rounded-card glass p-5 hairline shadow-sm">
                      <span className="text-[11px] font-semibold text-muted uppercase">Low Attendance Alerts</span>
                      <div
                        className={cn(
                          "mt-1 font-extrabold text-2xl",
                          overview.lowAttendanceStudentCount > 0 ? "text-rose-500" : "text-emerald-500"
                        )}
                      >
                        {overview.lowAttendanceStudentCount}
                      </div>
                      <p className="text-xs text-muted mt-0.5">Students below minimum 75% threshold</p>
                    </div>
                  </div>

                  {/* Department Subject Average Attendance */}
                  {overview.subjectsList.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-bold text-ink flex items-center gap-2">
                        <BookOpen className="h-4 w-4 text-brand" /> Timetable Subject & Faculty Averages
                      </h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {overview.subjectsList.map((sub, idx) => (
                          <div
                            key={idx}
                            className={cn(
                              "rounded-card glass p-4 hairline shadow-xs flex items-center justify-between",
                              sub.isLowAttendance && "border-rose-500/40 bg-rose-500/5"
                            )}
                          >
                            <div>
                              <div className="font-bold text-sm text-ink">{sub.subjectName}</div>
                              <div className="text-xs text-brand dark:text-sky-300 font-semibold">
                                Faculty: {sub.facultyName}
                              </div>
                            </div>

                            <div className="text-right">
                              <span
                                className={cn(
                                  "inline-block rounded-full px-2.5 py-1 text-xs font-extrabold shadow-xs",
                                  sub.isLowAttendance
                                    ? "bg-rose-500 text-white"
                                    : "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30"
                                )}
                              >
                                {sub.avgPercentage.toFixed(2)}% Avg
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Student Roster Low Attendance Table */}
                  {overview.studentsList.length > 0 && (
                    <div className="rounded-card glass overflow-hidden hairline shadow-sm space-y-3 p-4">
                      <h3 className="text-sm font-bold text-ink flex items-center gap-2">
                        <Users className="h-4 w-4 text-brand" /> Enrolled Student Attendance Roster ({overview.studentsList.length})
                      </h3>

                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs text-ink">
                          <thead className="bg-surface/90 text-muted uppercase font-semibold text-[11px] border-b border-line">
                            <tr>
                              <th className="px-4 py-2.5">Roll No</th>
                              <th className="px-4 py-2.5">Student Name</th>
                              <th className="px-4 py-2.5">Student ID</th>
                              <th className="px-4 py-2.5">Sessions Attended</th>
                              <th className="px-4 py-2.5">Attendance %</th>
                              <th className="px-4 py-2.5">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-line">
                            {overview.studentsList.map((st) => (
                              <tr
                                key={st.userId}
                                className={cn(
                                  "hover:bg-raised/50 transition-colors",
                                  st.isLowAttendance && "bg-rose-500/10"
                                )}
                              >
                                <td className="px-4 py-3 font-mono text-muted">{st.rollNumber || "-"}</td>
                                <td className="px-4 py-3 font-bold">{st.fullName}</td>
                                <td className="px-4 py-3 font-mono text-muted">{st.studentId}</td>
                                <td className="px-4 py-3 text-muted">
                                  {st.presentClasses} / {st.totalClasses}
                                </td>
                                <td className="px-4 py-3 font-extrabold">{st.percentage.toFixed(2)}%</td>
                                <td className="px-4 py-3">
                                  <span
                                    className={cn(
                                      "inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase",
                                      st.isLowAttendance
                                        ? "bg-rose-500 text-white"
                                        : "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30"
                                    )}
                                  >
                                    {st.isLowAttendance ? "Low Attendance Warning" : "Good"}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB 2: Mark Daily Class Register */}
      {activeTab === "register" && (
        <div className="space-y-6">
          {/* Filter Selection Panel */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 rounded-card glass p-4 hairline">
            <div>
              <label className="text-[11px] font-bold text-muted uppercase mb-1 block">Course</label>
              <select
                value={selectedCourseId}
                onChange={(e) => setSelectedCourseId(e.target.value)}
                className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-semibold text-ink"
              >
                {coursesList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-muted uppercase mb-1 block">Semester</label>
              <select
                value={semester}
                onChange={(e) => setSemester(Number(e.target.value))}
                className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-semibold text-ink"
              >
                {[1, 2, 3, 4, 5, 6].map((s) => (
                  <option key={s} value={s}>
                    Sem {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-muted uppercase mb-1 block">Section</label>
              <select
                value={section}
                onChange={(e) => setSection(e.target.value)}
                className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-semibold text-ink"
              >
                <option value="A">Section A</option>
                <option value="B">Section B</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="text-[11px] font-bold text-muted uppercase mb-1 block">
                Timetable Subject & Faculty
              </label>
              {!isTimetableAvailable ? (
                <div className="text-xs text-rose-500 font-semibold p-2 rounded-ctl bg-rose-500/10 border border-rose-500/30">
                  Attendance cannot be configured because timetable data is not available for this class/semester.
                </div>
              ) : (
                <select
                  value={selectedPairKey}
                  onChange={(e) => setSelectedPairKey(e.target.value)}
                  className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-bold text-ink"
                >
                  {timetablePairs.map((p, idx) => (
                    <option key={idx} value={`${p.subjectName}::${p.facultyName}`}>
                      {p.subjectName} — {p.facultyName}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          {isTimetableAvailable && timetablePairs.length > 0 && (
            <div className="flex items-center justify-between">
              <button
                onClick={handleLoadSheet}
                className="rounded-ctl bg-brand px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-brand-dark transition-all"
              >
                Load Class Register Sheet
              </button>

              {isLoaded && (
                <button
                  onClick={handleMarkAllPresent}
                  className="flex items-center gap-1.5 rounded-ctl bg-surface hairline px-3 py-2 text-xs font-bold text-ink hover:bg-raised transition-all"
                >
                  <CheckSquare className="h-4 w-4 text-emerald-500" /> Mark All Present
                </button>
              )}
            </div>
          )}

          {message && (
            <div className="rounded-ctl bg-brand/10 border border-brand/30 p-3 text-xs font-semibold text-brand dark:text-sky-300">
              {message}
            </div>
          )}

          {/* Student List Sheet */}
          {isLoaded && (
            <div className="rounded-card glass overflow-hidden hairline shadow-sm space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-ink">
                  <thead className="bg-surface/90 text-muted uppercase font-semibold text-[11px] border-b border-line">
                    <tr>
                      <th className="px-4 py-3">Roll No</th>
                      <th className="px-4 py-3">Student Name</th>
                      <th className="px-4 py-3">Student ID</th>
                      <th className="px-4 py-3 text-right">Attendance Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {students.map((st) => (
                      <tr key={st.userId} className="hover:bg-raised/50 transition-colors">
                        <td className="px-4 py-3 font-mono text-muted">{st.rollNumber || "-"}</td>
                        <td className="px-4 py-3 font-bold">{st.fullName}</td>
                        <td className="px-4 py-3 font-mono text-muted">{st.studentId}</td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex rounded-ctl bg-surface p-1 hairline gap-1">
                            <button
                              type="button"
                              onClick={() => handleStatusToggle(st.userId, "PRESENT")}
                              className={cn(
                                "rounded-ctl px-2.5 py-1 text-[11px] font-bold transition-all flex items-center gap-1",
                                st.status === "PRESENT"
                                  ? "bg-emerald-500 text-white shadow-xs"
                                  : "text-muted hover:text-ink"
                              )}
                            >
                              <Check className="h-3 w-3" /> Present
                            </button>

                            <button
                              type="button"
                              onClick={() => handleStatusToggle(st.userId, "ABSENT")}
                              className={cn(
                                "rounded-ctl px-2.5 py-1 text-[11px] font-bold transition-all flex items-center gap-1",
                                st.status === "ABSENT"
                                  ? "bg-rose-500 text-white shadow-xs"
                                  : "text-muted hover:text-ink"
                              )}
                            >
                              <X className="h-3 w-3" /> Absent
                            </button>

                            <button
                              type="button"
                              onClick={() => handleStatusToggle(st.userId, "LATE")}
                              className={cn(
                                "rounded-ctl px-2.5 py-1 text-[11px] font-bold transition-all flex items-center gap-1",
                                st.status === "LATE"
                                  ? "bg-amber-500 text-white shadow-xs"
                                  : "text-muted hover:text-ink"
                              )}
                            >
                              <Clock className="h-3 w-3" /> Late
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-4 border-t border-line flex justify-end">
                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex items-center gap-2 rounded-ctl bg-navy-deep px-5 py-2.5 text-xs font-bold text-white shadow-md hover:bg-navy-deep/90 transition-all"
                >
                  <Save className="h-4 w-4" /> {isSaving ? "Saving Session..." : "Save Attendance Session"}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
