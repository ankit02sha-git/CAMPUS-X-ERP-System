"use client";
import { useActionState, useState } from "react";
import {
  saveSlotAction,
  deleteSlotAction,
  saveTimetableHeaderAction,
  createTimetableMasterAction,
} from "@/actions/timetable";
import type { FormState } from "@/actions/auth";
import { OfficialTimetableGrid, PERIODS, DAYS } from "@/components/timetable/OfficialTimetableGrid";
import { type TimetableMaster, type TimetableSlot } from "@/server/db/schema";
import { Badge, Button, Field, Input, Select } from "@/components/ui";

type CourseOption = { id: string; code: string; name: string };

export function TimetableGridEditor({
  courses,
  initialMaster,
  initialSlots,
  selectedCourseId,
  selectedSemester,
}: {
  courses: CourseOption[];
  initialMaster: TimetableMaster | null;
  initialSlots: TimetableSlot[];
  selectedCourseId: string;
  selectedSemester: number;
}) {
  const [master, setMaster] = useState<TimetableMaster | null>(initialMaster);
  const [editingSlot, setEditingSlot] = useState<{
    day: string;
    startPeriod: number;
    slot?: TimetableSlot;
  } | null>(null);

  const [headerState, headerAction, headerPending] = useActionState<FormState, FormData>(
    saveTimetableHeaderAction,
    undefined
  );

  const [slotState, slotAction, slotPending] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await saveSlotAction(prev, fd);
      if (res?.fieldErrors?._ok) {
        setEditingSlot(null);
      }
      return res;
    },
    undefined
  );

  const handleCourseChange = (courseId: string, sem: number) => {
    window.location.href = `/admin/timetable?courseId=${courseId}&semester=${sem}`;
  };

  const handleEnsureMaster = async () => {
    if (master) return master.id;
    const newId = await createTimetableMasterAction(
      selectedCourseId,
      selectedSemester,
      `CLASS TIME TABLE`
    );
    window.location.reload();
    return newId;
  };

  return (
    <div className="space-y-6">
      {/* COHORT SELECTOR */}
      <div className="rounded-card bg-surface p-4 hairline shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="w-44">
            <Field label="Course">
              <Select
                value={selectedCourseId}
                onChange={(e) => handleCourseChange(e.target.value, selectedSemester)}
              >
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <div className="w-36">
            <Field label="Semester">
              <Select
                value={String(selectedSemester)}
                onChange={(e) => handleCourseChange(selectedCourseId, Number(e.target.value))}
              >
                {[1, 2, 3, 4, 5, 6].map((s) => (
                  <option key={s} value={s}>
                    Semester {s}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
        </div>

        {!master && (
          <Button onClick={handleEnsureMaster}>+ Create Timetable Grid for this Cohort</Button>
        )}
      </div>

      {master ? (
        <div className="space-y-6">
          {/* HEADER METADATA EDITOR PANEL */}
          <details className="rounded-card bg-surface p-4 hairline shadow-sm">
            <summary className="font-semibold text-sm cursor-pointer text-brass flex items-center justify-between">
              <span>✏️ Edit Timetable Header Info (Title, Effective Date, Advisor)</span>
              <span className="text-xs text-muted font-normal">Click to expand/collapse</span>
            </summary>
            <form action={headerAction} className="mt-4 space-y-3 pt-3 border-t border-line">
              <input type="hidden" name="timetableId" value={master.id} />
              <div className="grid gap-3 sm:grid-cols-3">
                <Field label="Timetable Header Title">
                  <Input name="title" defaultValue={master.title} placeholder="BCA Vth SEMESTER" required />
                </Field>
                <Field label="Effective Date (W.e.f.)">
                  <Input name="effectiveDate" defaultValue={master.effectiveDate} placeholder="20th July, 2026" required />
                </Field>
                <Field label="Class Advisor">
                  <Input name="classAdvisor" defaultValue={master.classAdvisor || ""} placeholder="Mr Izhar Ahmad" />
                </Field>
              </div>

              {headerState?.error && (
                <p className="text-xs text-danger">{headerState.error}</p>
              )}
              {headerState?.fieldErrors?._ok && (
                <p className="text-xs text-ok">Header info saved!</p>
              )}

              <div className="flex justify-end">
                <Button type="submit" size="sm" loading={headerPending}>
                  Save Header Info
                </Button>
              </div>
            </form>
          </details>

          {/* INTERACTIVE TIMETABLE GRID */}
          <OfficialTimetableGrid
            master={master}
            slots={initialSlots}
            isAdmin={true}
            onCellClick={(day, period, slot) => {
              setEditingSlot({ day, startPeriod: period, slot });
            }}
          />

          {/* EDIT CELL / SLOT MODAL */}
          {editingSlot && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
              <div className="w-full max-w-lg rounded-card bg-surface p-6 hairline shadow-lift space-y-4">
                <div className="flex items-center justify-between border-b border-line pb-3">
                  <div>
                    <h3 className="font-bold text-ink text-base">
                      Edit Slot: {editingSlot.day} — Period {editingSlot.startPeriod}
                    </h3>
                    <p className="text-xs text-muted">
                      Faculty Name & Subject Name are stored as separate fields.
                    </p>
                  </div>
                  <button
                    onClick={() => setEditingSlot(null)}
                    className="text-muted hover:text-ink font-bold text-sm"
                  >
                    ✕
                  </button>
                </div>

                <form action={slotAction} className="space-y-4">
                  <input type="hidden" name="timetableId" value={master.id} />
                  <input type="hidden" name="slotId" value={editingSlot.slot?.id || ""} />
                  <input type="hidden" name="day" value={editingSlot.day} />

                  <div className="grid gap-3 sm:grid-cols-3">
                    <Field label="Entry Type">
                      <Select
                        name="entryType"
                        defaultValue={editingSlot.slot?.entryType || "NORMAL_CLASS"}
                        required
                      >
                        <option value="NORMAL_CLASS">Normal Class</option>
                        <option value="FREE_PERIOD">Free Period</option>
                        <option value="LIBRARY_ACTIVITY">Library Activity</option>
                        <option value="SPECIAL_ACTIVITY">Special Activity</option>
                        <option value="MERGED_ACTIVITY">Merged Activity Block</option>
                      </Select>
                    </Field>

                    <Field label="Start Period">
                      <Select name="startPeriod" defaultValue={String(editingSlot.startPeriod)} required>
                        {PERIODS.map((p) => (
                          <option key={p.num} value={p.num}>
                            Period {p.num} ({p.time})
                          </option>
                        ))}
                      </Select>
                    </Field>

                    <Field label="Span Periods (Merged Cell)">
                      <Select
                        name="spanPeriods"
                        defaultValue={String(editingSlot.slot?.spanPeriods || 1)}
                        required
                      >
                        <option value="1">1 Period (Normal)</option>
                        <option value="2">2 Periods (Merged)</option>
                        <option value="3">3 Periods (Merged Block)</option>
                      </Select>
                    </Field>
                  </div>

                  {/* SPECIAL ACTIVITY TOGGLE */}
                  <div className="rounded-ctl bg-raised p-3 border border-line space-y-3">
                    <label className="flex items-center gap-2 text-xs font-semibold text-ink cursor-pointer">
                      <input
                        type="checkbox"
                        name="isSpecialActivity"
                        defaultChecked={Boolean(editingSlot.slot?.isSpecialActivity)}
                        className="h-4 w-4 accent-[rgb(var(--brass))]"
                      />
                      Is Special Activity / Event Block (e.g. Club Activity, Project Phase-I)
                    </label>

                    <div className="space-y-2 pt-1 border-t border-line/60">
                      <Field label="Activity Title (Optional)">
                        <Input
                          name="activityTitle"
                          defaultValue={editingSlot.slot?.activityTitle || ""}
                          placeholder="e.g. Club Activity / Project Phase-I"
                        />
                      </Field>
                      <Field label="Activity Description (Optional)">
                        <Input
                          name="activityDescription"
                          defaultValue={editingSlot.slot?.activityDescription || ""}
                          placeholder="e.g. [students will join their respective clubs]"
                        />
                      </Field>
                    </div>
                  </div>

                  {/* FACULTY AND SUBJECT (SEPARATE FIELDS) */}
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Faculty Name" hint="e.g. Mrs Archana">
                      <Input
                        name="facultyName"
                        defaultValue={editingSlot.slot?.facultyName || ""}
                        placeholder="e.g. Mrs Archana"
                      />
                    </Field>
                    <Field label="Subject Name" hint="e.g. AI / CN / DA">
                      <Input
                        name="subjectName"
                        defaultValue={editingSlot.slot?.subjectName || ""}
                        placeholder="e.g. AI"
                      />
                    </Field>
                  </div>

                  {/* PREDEFINED COLOR THEME PICKER */}
                  <Field label="Cell Highlight Theme">
                    <Select name="colorTheme" defaultValue={editingSlot.slot?.colorTheme || ""}>
                      <option value="">Default Surface</option>
                      <option value="emerald">Emerald Green (e.g. Sports / Labs)</option>
                      <option value="amber">Amber Yellow (e.g. Theatre / Events)</option>
                      <option value="purple">Purple (e.g. Club Activities)</option>
                      <option value="blue">Blue (e.g. Projects / Workshops)</option>
                      <option value="rose">Rose Red (e.g. Exams / Urgent)</option>
                    </Select>
                  </Field>

                  {slotState?.error && (
                    <p className="text-xs text-danger font-medium">{slotState.error}</p>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t border-line">
                    {editingSlot.slot ? (
                      <Button
                        type="button"
                        variant="outline"
                        className="text-danger border-danger/30 hover:bg-danger/10"
                        onClick={async () => {
                          if (confirm("Delete this timetable slot?")) {
                            await deleteSlotAction(editingSlot.slot!.id);
                            setEditingSlot(null);
                          }
                        }}
                      >
                        Delete Slot
                      </Button>
                    ) : (
                      <div />
                    )}

                    <div className="flex gap-2">
                      <Button type="button" variant="outline" onClick={() => setEditingSlot(null)}>
                        Cancel
                      </Button>
                      <Button type="submit" loading={slotPending}>
                        Save Slot
                      </Button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
}
