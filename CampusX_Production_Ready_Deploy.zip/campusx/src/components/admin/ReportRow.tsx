"use client";
import { useState, useTransition } from "react";
import { resolveReport, setLostHidden, deleteLostPost } from "@/actions/lost";
import { Button, Input } from "@/components/ui";

export function ReportActions({ id, postId, hidden, open }: { id: string; postId: string; hidden: boolean; open: boolean }) {
  const [note, setNote] = useState(""); const [p, s] = useTransition();
  return (
    <div className="space-y-2">
      {open && <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Resolution note (optional)" aria-label="Resolution note" />}
      <div className="flex flex-wrap gap-1.5">
        {open && <><Button size="sm" loading={p} onClick={() => s(() => resolveReport(id, "RESOLVED", note))}>Resolve</Button><Button size="sm" variant="outline" loading={p} onClick={() => s(() => resolveReport(id, "DISMISSED", note))}>Dismiss</Button></>}
        <Button size="sm" variant="outline" loading={p} onClick={() => s(() => setLostHidden(postId, !hidden))}>{hidden ? "Unhide post" : "Hide post"}</Button>
        <Button size="sm" variant="danger" loading={p} onClick={() => { if (confirm("Delete this post permanently?")) s(() => deleteLostPost(postId)); }}>Delete post</Button>
      </div>
    </div>
  );
}
