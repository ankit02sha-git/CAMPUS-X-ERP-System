"use client";

import React, { useState } from "react";
import { AdminBirthdayRecord } from "@/server/birthday";
import { Calendar as CalendarIcon, Cake, Search, Filter, Sparkles, UserCheck, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";

interface AdminBirthdayViewProps {
  initialRecords: AdminBirthdayRecord[];
  todayKeyStr: string;
}

const MONTHS = [
  "All Months", "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export function AdminBirthdayView({ initialRecords, todayKeyStr }: AdminBirthdayViewProps) {
  const [search, setSearch] = useState("");
  const [selectedMonth, setSelectedMonth] = useState<number>(0); // 0 = All Months
  const [selectedCourse, setSelectedCourse] = useState<string>("ALL");
  const [showTodayOnly, setShowTodayOnly] = useState(false);
  const [viewMode, setViewMode] = useState<"list" | "calendar">("list");

  // Extract unique course codes
  const courseCodes = Array.from(
    new Set(initialRecords.map((r) => r.courseCode).filter(Boolean))
  ) as string[];

  // Filter records
  const filteredRecords = initialRecords.filter((rec) => {
    if (showTodayOnly && !rec.isToday) return false;
    if (selectedMonth > 0 && rec.birthMonth !== selectedMonth) return false;
    if (selectedCourse !== "ALL" && rec.courseCode !== selectedCourse) return false;

    if (search.trim()) {
      const q = search.toLowerCase();
      const matchName = rec.fullName.toLowerCase().includes(q);
      const matchId = rec.studentId.toLowerCase().includes(q);
      const matchRoll = rec.rollNumber?.toLowerCase().includes(q);
      if (!matchName && !matchId && !matchRoll) return false;
    }

    return true;
  });

  const todayCount = initialRecords.filter((r) => r.isToday).length;

  return (
    <div className="space-y-6">
      {/* Top Banner & Stats */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-5 hairline shadow-sm">
        <div className="flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-md">
            <Cake className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-ink flex items-center gap-2">
              Student Birthday Directory & Calendar
            </h2>
            <p className="text-xs text-muted">
              Server Timezone: Asia/Kolkata (IST) • Current Date: <span className="font-semibold text-brand dark:text-shcyellow">{todayKeyStr}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowTodayOnly(!showTodayOnly)}
            className={cn(
              "flex items-center gap-2 rounded-ctl px-3.5 py-2 text-xs font-bold transition-all shadow-xs",
              showTodayOnly
                ? "bg-amber-500 text-white shadow-md ring-2 ring-amber-400/50"
                : "bg-surface hairline text-ink hover:bg-raised"
            )}
          >
            <Sparkles className="h-4 w-4 text-shcyellow" />
            Today's Birthdays ({todayCount})
          </button>

          <div className="flex rounded-ctl bg-surface hairline p-1">
            <button
              onClick={() => setViewMode("list")}
              className={cn(
                "rounded-ctl px-3 py-1 text-xs font-semibold transition-colors",
                viewMode === "list" ? "bg-navy-deep text-white shadow-xs" : "text-muted hover:text-ink"
              )}
            >
              List View
            </button>
            <button
              onClick={() => setViewMode("calendar")}
              className={cn(
                "rounded-ctl px-3 py-1 text-xs font-semibold transition-colors",
                viewMode === "calendar" ? "bg-navy-deep text-white shadow-xs" : "text-muted hover:text-ink"
              )}
            >
              Calendar View
            </button>
          </div>
        </div>
      </div>

      {/* Filter Controls Bar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
        {/* Search Input */}
        <div className="relative sm:col-span-2">
          <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-muted" />
          <input
            type="text"
            placeholder="Search student name, ID, or roll number..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-ctl glass-input pl-10 pr-4 py-2 text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/40"
          />
        </div>

        {/* Month Dropdown Filter */}
        <div>
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-medium text-ink focus:outline-none focus:ring-2 focus:ring-brand/40"
          >
            {MONTHS.map((m, idx) => (
              <option key={m} value={idx}>
                {m}
              </option>
            ))}
          </select>
        </div>

        {/* Course Dropdown Filter */}
        <div>
          <select
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="w-full rounded-ctl glass-input px-3 py-2 text-xs font-medium text-ink focus:outline-none focus:ring-2 focus:ring-brand/40"
          >
            <option value="ALL">All Courses</option>
            {courseCodes.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Privacy Notice Banner */}
      <div className="flex items-center gap-2.5 rounded-ctl bg-brand/5 border border-brand/20 p-3 text-xs text-brand dark:text-sky-300">
        <ShieldAlert className="h-4 w-4 shrink-0" />
        <span>
          <strong>Admin Privacy Scope:</strong> Full Date of Birth (DOB), calculated age, and student metadata are strictly visible ONLY to authorized Administrators. Normal students can only view friendly birthday greetings.
        </span>
      </div>

      {/* Main View: List Mode */}
      {viewMode === "list" ? (
        <div className="rounded-card glass overflow-hidden hairline shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-ink">
              <thead className="bg-surface/90 text-muted uppercase font-semibold text-[11px] border-b border-line">
                <tr>
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">Student ID</th>
                  <th className="px-4 py-3">Date of Birth</th>
                  <th className="px-4 py-3">Age</th>
                  <th className="px-4 py-3">Course / Sem</th>
                  <th className="px-4 py-3">Section</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-muted">
                      No student birthday records found matching the active filters.
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map((rec) => (
                    <tr
                      key={rec.id}
                      className={cn(
                        "transition-colors hover:bg-raised/60",
                        rec.isToday && "bg-amber-500/10 hover:bg-amber-500/15"
                      )}
                    >
                      <td className="px-4 py-3 font-semibold">
                        <div className="flex items-center gap-2">
                          {rec.isToday && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500 text-white px-2 py-0.5 text-[10px] font-bold shadow-xs">
                              <Cake className="h-3 w-3" /> Birthday Today
                            </span>
                          )}
                          <span>{rec.fullName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-muted">{rec.studentId}</td>
                      <td className="px-4 py-3 font-medium">
                        {rec.dob ? rec.dob : <span className="text-muted italic">Not recorded</span>}
                      </td>
                      <td className="px-4 py-3 font-medium">
                        {rec.age !== null ? `${rec.age} yrs` : <span className="text-muted">-</span>}
                      </td>
                      <td className="px-4 py-3 text-muted">
                        {rec.courseCode || "N/A"} {rec.semester ? `• Sem ${rec.semester}` : ""}
                      </td>
                      <td className="px-4 py-3 text-muted">{rec.section || "A"}</td>
                      <td className="px-4 py-3">
                        <span
                          className={cn(
                            "inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase",
                            rec.status === "ACTIVE"
                              ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30"
                              : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30"
                          )}
                        >
                          {rec.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Calendar Grid View */
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {MONTHS.slice(1).map((mName, mIdx) => {
            const monthNumber = mIdx + 1;
            const monthRecords = filteredRecords.filter((r) => r.birthMonth === monthNumber);

            return (
              <div
                key={mName}
                className={cn(
                  "rounded-card glass p-4 hairline shadow-xs flex flex-col justify-between",
                  selectedMonth === monthNumber && "ring-2 ring-brand"
                )}
              >
                <div>
                  <div className="flex items-center justify-between border-b border-line pb-2 mb-3">
                    <h3 className="font-bold text-sm text-ink flex items-center gap-1.5">
                      <CalendarIcon className="h-4 w-4 text-brand" /> {mName}
                    </h3>
                    <span className="text-xs font-semibold rounded-full bg-surface px-2 py-0.5 text-muted border border-line">
                      {monthRecords.length}
                    </span>
                  </div>

                  {monthRecords.length === 0 ? (
                    <p className="text-xs text-muted italic py-4 text-center">No birthdays</p>
                  ) : (
                    <ul className="space-y-2 max-h-48 overflow-y-auto no-scrollbar">
                      {monthRecords.map((st) => (
                        <li
                          key={st.id}
                          className={cn(
                            "rounded-ctl p-2 text-xs flex items-center justify-between border border-line/60",
                            st.isToday ? "bg-amber-500/15 border-amber-500/40 text-ink font-bold" : "bg-surface/50 text-ink"
                          )}
                        >
                          <div className="min-w-0 pr-2">
                            <div className="truncate font-medium">{st.fullName}</div>
                            <div className="text-[10px] text-muted">{st.courseCode} • {st.dob}</div>
                          </div>
                          {st.isToday && (
                            <span className="text-amber-500 animate-bounce">🎂</span>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
