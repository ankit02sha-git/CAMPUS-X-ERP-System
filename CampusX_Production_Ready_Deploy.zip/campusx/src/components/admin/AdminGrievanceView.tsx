"use client";

import React, { useState } from "react";
import { fetchAdminGrievancesAction, updateAdminGrievanceAction } from "@/actions/grievance";
import { GrievanceTicket } from "@/server/db/schema";
import { LifeBuoy, MessageSquare, CheckCircle, Clock, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";

interface AdminGrievanceRow {
  gt: GrievanceTicket;
  studentName: string;
  studentId: string | null;
}

interface AdminGrievanceViewProps {
  initialTickets: AdminGrievanceRow[];
}

export function AdminGrievanceView({ initialTickets }: AdminGrievanceViewProps) {
  const [tickets, setTickets] = useState<AdminGrievanceRow[]>(initialTickets);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [responseMsg, setResponseMsg] = useState("");
  const [nextStatus, setNextStatus] = useState<"OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED">("RESOLVED");
  const [isUpdating, setIsUpdating] = useState(false);

  const handleUpdate = async (ticketId: string) => {
    setIsUpdating(true);
    try {
      await updateAdminGrievanceAction(ticketId, nextStatus, responseMsg);
      setTickets((prev) =>
        prev.map((t) =>
          t.gt.id === ticketId
            ? { ...t, gt: { ...t.gt, status: nextStatus, adminResponse: responseMsg } }
            : t
        )
      );
      setSelectedTicketId(null);
      setResponseMsg("");
    } catch (err: any) {
      alert("Failed to update ticket: " + err.message);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-card glass p-5 hairline shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-ink flex items-center gap-2">
            <LifeBuoy className="h-5 w-5 text-brand" /> Student Grievance Control Desk
          </h2>
          <p className="text-xs text-muted">
            Manage student support tickets, respond to queries, and update resolution statuses.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {tickets.map(({ gt, studentName, studentId }) => (
          <div key={gt.id} className="rounded-card glass p-5 hairline shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-line pb-2 gap-2">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-brand dark:text-shcyellow">{gt.ticketNumber}</span>
                <span className="font-bold text-xs text-ink">{studentName} ({studentId || "N/A"})</span>
              </div>

              <span
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase shadow-xs self-start sm:self-auto",
                  gt.status === "RESOLVED" || gt.status === "CLOSED"
                    ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30"
                    : gt.status === "IN_PROGRESS"
                    ? "bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30"
                    : "bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/30"
                )}
              >
                {gt.status}
              </span>
            </div>

            <div>
              <h3 className="font-bold text-sm text-ink">{gt.subject}</h3>
              <p className="text-xs text-muted leading-relaxed mt-1">{gt.description}</p>
            </div>

            {gt.adminResponse && (
              <div className="rounded-ctl bg-surface p-3 text-xs text-muted hairline">
                <strong>Current Admin Response:</strong> {gt.adminResponse}
              </div>
            )}

            {selectedTicketId === gt.id ? (
              <div className="rounded-ctl bg-brand/5 border border-brand/20 p-4 space-y-3">
                <h4 className="text-xs font-bold text-ink">Update Ticket Status & Response</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-muted uppercase block mb-1">Status</label>
                    <select
                      value={nextStatus}
                      onChange={(e) => setNextStatus(e.target.value as any)}
                      className="w-full rounded-ctl glass-input px-3 py-1.5 text-xs text-ink"
                    >
                      <option value="OPEN">Open</option>
                      <option value="IN_PROGRESS">In Progress</option>
                      <option value="RESOLVED">Resolved</option>
                      <option value="CLOSED">Closed</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-muted uppercase block mb-1">Admin Response Note</label>
                    <input
                      type="text"
                      placeholder="Type response for student..."
                      value={responseMsg}
                      onChange={(e) => setResponseMsg(e.target.value)}
                      className="w-full rounded-ctl glass-input px-3 py-1.5 text-xs text-ink"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setSelectedTicketId(null)}
                    className="rounded-ctl px-3 py-1.5 text-xs font-semibold text-muted hover:text-ink"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleUpdate(gt.id)}
                    disabled={isUpdating}
                    className="rounded-ctl bg-navy-deep px-4 py-1.5 text-xs font-bold text-white shadow-xs"
                  >
                    {isUpdating ? "Saving..." : "Save Response"}
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => {
                  setSelectedTicketId(gt.id);
                  setResponseMsg(gt.adminResponse || "");
                  setNextStatus(gt.status as any);
                }}
                className="rounded-ctl bg-surface hairline px-3 py-1.5 text-xs font-bold text-brand dark:text-sky-300 hover:bg-raised transition-all"
              >
                Respond / Update Status
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
