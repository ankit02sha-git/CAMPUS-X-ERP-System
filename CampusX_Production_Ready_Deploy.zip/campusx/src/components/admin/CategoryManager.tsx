"use client";
import { useActionState, useTransition } from "react";
import { addCategory, toggleCategory } from "@/actions/lost";
import type { FormState } from "@/actions/auth";
import { Badge, Button, Input } from "@/components/ui";

export function CategoryManager({ cats }: { cats: { id: string; name: string; active: boolean }[] }) {
  const [state, action, pending] = useActionState<FormState, FormData>(addCategory, undefined);
  const [p, s] = useTransition();
  return (
    <div>
      <div className="mb-3 flex flex-wrap gap-2">{cats.map((c) => <button key={c.id} disabled={p} onClick={() => s(() => toggleCategory(c.id, !c.active))} aria-pressed={c.active} title={c.active ? "Click to disable" : "Click to enable"}><Badge tone={c.active ? "ok" : "neutral"} className="px-3 py-1 text-xs">{c.name}{!c.active && " (off)"}</Badge></button>)}</div>
      <form action={action} className="flex max-w-sm gap-2"><Input name="name" placeholder="New category" aria-label="New category" required /><Button type="submit" loading={pending}>Add</Button></form>
      {state?.error && <p role="alert" className="mt-1 text-xs text-danger">{state.error}</p>}
    </div>
  );
}
