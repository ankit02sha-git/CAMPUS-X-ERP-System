"use client";
import { useActionState, useState } from "react";
import {
  saveFeeStructureAction,
  saveFeeDueRuleAction,
  recordPaymentAction,
  deletePaymentAction,
} from "@/actions/fees";
import type { FormState } from "@/actions/auth";
import { ReceiptModal, type FeeReceiptData } from "@/components/fees/ReceiptModal";
import { Badge, Button, Field, Input, Select } from "@/components/ui";
import {
  Users,
  CreditCard,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  ExternalLink,
  Plus,
  Edit2,
  Trash2,
} from "lucide-react";
import type { FeeStructure, FeeDueRule, FeePayment, Course, User } from "@/server/db/schema";
import type { StudentFeeSummary } from "@/lib/fees";

export function FeeManagementView({
  courses,
  feeStructuresList,
  dueRulesList,
  studentSummaries,
}: {
  courses: Course[];
  feeStructuresList: FeeStructure[];
  dueRulesList: FeeDueRule[];
  studentSummaries: StudentFeeSummary[];
}) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCourseFilter, setSelectedCourseFilter] = useState("");
  const [activeTab, setActiveTab] = useState<"students" | "structures" | "rules">("students");

  const [editingStructure, setEditingStructure] = useState<FeeStructure | null>(null);
  const [editingRule, setEditingRule] = useState<FeeDueRule | null>(null);
  const [recordingPaymentFor, setRecordingPaymentFor] = useState<{
    summary: StudentFeeSummary;
    payment?: FeePayment;
  } | null>(null);

  const [selectedReceipt, setSelectedReceipt] = useState<FeeReceiptData | null>(null);

  const [fsState, fsAction, fsPending] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await saveFeeStructureAction(prev, fd);
      if (res?.fieldErrors?._ok) setEditingStructure(null);
      return res;
    },
    undefined
  );

  const [ruleState, ruleAction, rulePending] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await saveFeeDueRuleAction(prev, fd);
      if (res?.fieldErrors?._ok) setEditingRule(null);
      return res;
    },
    undefined
  );

  const [payState, payAction, payPending] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await recordPaymentAction(prev, fd);
      if (res?.fieldErrors?._ok) setRecordingPaymentFor(null);
      return res;
    },
    undefined
  );

  // Compute Overall Metrics
  const totalStudents = studentSummaries.length;
  const fullyPaidCount = studentSummaries.filter((s) => s.paymentStatus === "PAID").length;
  const partiallyPaidCount = studentSummaries.filter((s) => s.paymentStatus === "PARTIALLY_PAID").length;
  const totalExpected = studentSummaries.reduce((sum, s) => sum + s.knownAnnualFee, 0);
  const totalPaid = studentSummaries.reduce((sum, s) => sum + s.amountPaid, 0);
  const totalOutstanding = studentSummaries.reduce((sum, s) => sum + s.remainingAmount, 0);
  const overdueCount = studentSummaries.filter((s) => s.lateDays > 0 && s.remainingAmount > 0).length;

  // Filtered Students Table
  const filteredStudents = studentSummaries.filter((s) => {
    const matchSearch =
      s.student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.student.studentId || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.student.email || "").toLowerCase().includes(searchTerm.toLowerCase());

    const matchCourse =
      !selectedCourseFilter || s.student.courseId === selectedCourseFilter;

    return matchSearch && matchCourse;
  });

  return (
    <div className="space-y-6">
      {/* OVERALL FEE SUMMARY CARDS */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <div className="rounded-card bg-surface p-4 hairline shadow-sm space-y-1">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">Total Students</div>
          <div className="text-2xl font-extrabold text-navy dark:text-white">{totalStudents}</div>
          <div className="text-[11px] text-muted">Enrolled in portal</div>
        </div>
        <div className="rounded-card bg-surface p-4 hairline shadow-sm space-y-1">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">Fully Paid</div>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">{fullyPaidCount}</div>
          <div className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold">100% Cleared</div>
        </div>
        <div className="rounded-card bg-surface p-4 hairline shadow-sm space-y-1">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">Partially Paid</div>
          <div className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">{partiallyPaidCount}</div>
          <div className="text-[11px] text-amber-700 dark:text-amber-400 font-semibold">Partial dues</div>
        </div>
        <div className="rounded-card bg-surface p-4 hairline shadow-sm space-y-1">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">Total Outstanding</div>
          <div className="text-2xl font-extrabold text-rose-600 dark:text-rose-400">
            ₹{totalOutstanding.toLocaleString("en-IN")}
          </div>
          <div className="text-[11px] text-muted">Expected ₹{totalExpected.toLocaleString("en-IN")}</div>
        </div>
        <div className="rounded-card bg-surface p-4 hairline shadow-sm space-y-1">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">Overdue Accounts</div>
          <div className="text-2xl font-extrabold text-red-600 dark:text-red-400">{overdueCount}</div>
          <div className="text-[11px] text-red-600 font-semibold">Past due date</div>
        </div>
      </div>

      {/* COURSE-WISE FEE BREAKDOWN METRICS */}
      <div className="rounded-card bg-surface p-6 hairline shadow-card space-y-4">
        <h3 className="font-bold text-ink text-base">Course-wise Expected & Collected Fees</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {courses.map((c) => {
            const courseStudents = studentSummaries.filter((s) => s.student.courseId === c.id);
            const expected = courseStudents.reduce((sum, s) => sum + s.knownAnnualFee, 0);
            const paid = courseStudents.reduce((sum, s) => sum + s.amountPaid, 0);
            const remaining = courseStudents.reduce((sum, s) => sum + s.remainingAmount, 0);

            return (
              <div key={c.id} className="rounded-ctl bg-raised/50 p-4 border border-line space-y-2">
                <div className="flex items-center justify-between border-b border-line/60 pb-2">
                  <span className="font-extrabold text-navy dark:text-brass text-sm">{c.code}</span>
                  <Badge tone="brass" className="text-[10px]">
                    {courseStudents.length} Student(s)
                  </Badge>
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted">Expected:</span>
                    <span className="font-semibold text-ink">₹{expected.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">Collected:</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">
                      ₹{paid.toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">Outstanding:</span>
                    <span className="font-bold text-amber-600 dark:text-amber-400">
                      ₹{remaining.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* TABS NAVIGATION */}
      <div className="flex border-b border-line gap-4 text-sm font-bold">
        <button
          onClick={() => setActiveTab("students")}
          className={`pb-3 px-1 border-b-2 transition-colors ${
            activeTab === "students"
              ? "border-brass text-brass"
              : "border-transparent text-muted hover:text-ink"
          }`}
        >
          👨‍🎓 Student Payment Records
        </button>
        <button
          onClick={() => setActiveTab("structures")}
          className={`pb-3 px-1 border-b-2 transition-colors ${
            activeTab === "structures"
              ? "border-brass text-brass"
              : "border-transparent text-muted hover:text-ink"
          }`}
        >
          ⚙️ Course Fee Structures
        </button>
        <button
          onClick={() => setActiveTab("rules")}
          className={`pb-3 px-1 border-b-2 transition-colors ${
            activeTab === "rules"
              ? "border-brass text-brass"
              : "border-transparent text-muted hover:text-ink"
          }`}
        >
          ⏰ Due Dates & Fine Rules
        </button>
      </div>

      {/* TAB 1: STUDENT PAYMENT RECORDS */}
      {activeTab === "students" && (
        <div className="space-y-4">
          <div className="rounded-card bg-surface p-4 hairline shadow-sm flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <Input
                placeholder="Search Student Name or Roll ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full sm:w-72"
              />
              <Select
                value={selectedCourseFilter}
                onChange={(e) => setSelectedCourseFilter(e.target.value)}
                className="w-44"
              >
                <option value="">All Courses</option>
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code}
                  </option>
                ))}
              </Select>
            </div>
            <div className="text-xs text-muted font-medium">
              Showing {filteredStudents.length} of {studentSummaries.length} Students
            </div>
          </div>

          <div className="rounded-card bg-surface hairline shadow-card overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-navy-deep text-white uppercase text-[11px] font-bold">
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Roll / ID</th>
                  <th className="p-3">Course</th>
                  <th className="p-3 text-right">Known Annual Fee</th>
                  <th className="p-3 text-right">Paid Amount</th>
                  <th className="p-3 text-right">Remaining</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line font-medium">
                {filteredStudents.map((s) => (
                  <tr key={s.student.id} className="hover:bg-raised/40 transition-colors">
                    <td className="p-3">
                      <div className="font-bold text-ink">{s.student.name}</div>
                      <div className="text-[10px] text-muted">{s.student.email}</div>
                    </td>
                    <td className="p-3 font-mono font-bold text-brass">
                      {s.student.studentId || "SHC-STUDENT"}
                    </td>
                    <td className="p-3 font-semibold text-ink">{s.course?.code || "—"}</td>
                    <td className="p-3 text-right font-semibold">
                      ₹{s.knownAnnualFee.toLocaleString("en-IN")}
                    </td>
                    <td className="p-3 text-right font-extrabold text-emerald-600 dark:text-emerald-400">
                      ₹{s.amountPaid.toLocaleString("en-IN")}
                    </td>
                    <td className="p-3 text-right font-bold text-amber-600 dark:text-amber-400">
                      ₹{s.remainingAmount.toLocaleString("en-IN")}
                    </td>
                    <td className="p-3 text-center">
                      {s.paymentStatus === "PAID" ? (
                        <Badge tone="ok" className="text-[10px]">
                          PAID
                        </Badge>
                      ) : s.paymentStatus === "PARTIALLY_PAID" ? (
                        <Badge tone="warn" className="text-[10px]">
                          PARTIALLY PAID
                        </Badge>
                      ) : (
                        <Badge tone="danger" className="text-[10px]">
                          UNPAID
                        </Badge>
                      )}
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => setRecordingPaymentFor({ summary: s })}
                        >
                          + Record Payment
                        </Button>

                        {s.payments.length > 0 && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const p = s.payments[0];
                              setSelectedReceipt({
                                receiptNumber: p.receiptNumber,
                                transactionId: p.transactionId,
                                paymentDate: p.paymentDate,
                                paymentMethod: p.paymentMethod,
                                amount: p.amount,
                                feeType: p.feeType,
                                studentName: s.student.name,
                                studentId: s.student.studentId || s.student.id,
                                courseCode: s.course?.code || "STUDENT",
                                academicSession: s.feeStructure?.academicSession || "2026-27",
                              });
                            }}
                          >
                            Receipt
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: COURSE FEE STRUCTURES */}
      {activeTab === "structures" && (
        <div className="space-y-6">
          <div className="rounded-card bg-surface p-4 hairline shadow-sm flex justify-between items-center">
            <div>
              <h3 className="font-bold text-ink text-sm">Official College Fee Structures (2026-27)</h3>
              <p className="text-xs text-muted">
                Reference values configured per official Study Hall College website standards.
              </p>
            </div>
            <a
              href="https://www.studyhallcollege.org/fee-structure.php"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-brass hover:underline font-semibold"
            >
              <span>View Source Page</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {feeStructuresList.map((fs) => {
              const course = courses.find((c) => c.id === fs.courseId);
              const knownTotal = fs.admissionFee + fs.tuitionFee + fs.studentDevelopmentFee;

              return (
                <div key={fs.id} className="rounded-card bg-surface p-5 hairline shadow-card space-y-4 border-t-2 border-brass">
                  <div className="flex items-center justify-between border-b border-line pb-2">
                    <span className="font-extrabold text-navy dark:text-brass text-base">
                      {course?.code} — {course?.name}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingStructure(fs)}
                    >
                      <Edit2 className="h-3 w-3 mr-1" /> Edit
                    </Button>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted">Admission Fee:</span>
                      <span className="font-semibold text-ink">₹{fs.admissionFee.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Tuition Fee:</span>
                      <span className="font-semibold text-ink">₹{fs.tuitionFee.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Development Fee:</span>
                      <span className="font-semibold text-ink">₹{fs.studentDevelopmentFee.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted">University Exam Fee:</span>
                      <span className="font-bold text-brass text-[11px]">
                        {fs.universityExamFee === "AS_PER_UNIVERSITY" ? "As per University" : fs.universityExamFee}
                      </span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-line text-sm font-extrabold">
                      <span className="text-navy dark:text-white">Known Annual Total:</span>
                      <span className="text-emerald-600 dark:text-emerald-400">
                        ₹{knownTotal.toLocaleString("en-IN")}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: DUE DATES & FINE RULES */}
      {activeTab === "rules" && (
        <div className="space-y-6">
          <div className="rounded-card bg-surface p-4 hairline shadow-sm">
            <h3 className="font-bold text-ink text-sm">Configured Fee Due Dates & Late Fine Rules</h3>
            <p className="text-xs text-muted">
              Rules determine automatic late fine calculations for overdue student balances.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {dueRulesList.map((r) => {
              const course = courses.find((c) => c.id === r.courseId);

              return (
                <div key={r.id} className="rounded-card bg-surface p-5 hairline shadow-card space-y-4 border-t-2 border-amber-500">
                  <div className="flex items-center justify-between border-b border-line pb-2">
                    <span className="font-extrabold text-navy dark:text-brass text-base">
                      {course?.code} Rule
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingRule(r)}
                    >
                      <Edit2 className="h-3 w-3 mr-1" /> Edit
                    </Button>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted">Official Due Date:</span>
                      <span className="font-bold text-ink">{r.dueDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Fine Type:</span>
                      <span className="font-semibold text-brass">{r.fineType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Fine Amount:</span>
                      <span className="font-semibold text-ink">₹{r.fineValue} / day</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Max Fine Limit:</span>
                      <span className="font-semibold text-ink">₹{r.maxFine}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* RECORD PAYMENT MODAL */}
      {recordingPaymentFor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-card bg-surface p-6 hairline shadow-lift space-y-4">
            <div className="flex items-center justify-between border-b border-line pb-3">
              <div>
                <h3 className="font-bold text-ink text-base">Record Demo Payment</h3>
                <p className="text-xs text-muted">
                  Student: {recordingPaymentFor.summary.student.name} ({recordingPaymentFor.summary.course?.code})
                </p>
              </div>
              <button
                onClick={() => setRecordingPaymentFor(null)}
                className="text-muted hover:text-ink font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form action={payAction} className="space-y-3">
              <input type="hidden" name="studentId" value={recordingPaymentFor.summary.student.id} />
              <input
                type="hidden"
                name="feeStructureId"
                value={recordingPaymentFor.summary.feeStructure?.id || ""}
              />
              <input
                type="hidden"
                name="paymentId"
                value={recordingPaymentFor.payment?.id || ""}
              />

              <Field label="Payment Amount (₹)">
                <Input
                  type="number"
                  name="amount"
                  defaultValue={recordingPaymentFor.payment?.amount || Math.min(10000, recordingPaymentFor.summary.remainingAmount || 10000)}
                  required
                />
              </Field>

              <div className="grid gap-3 grid-cols-2">
                <Field label="Fee Type">
                  <Select name="feeType" defaultValue={recordingPaymentFor.payment?.feeType || "TUITION_FEE"}>
                    <option value="TUITION_FEE">Tuition Fee</option>
                    <option value="ADMISSION_FEE">Admission Fee</option>
                    <option value="DEVELOPMENT_FEE">Development Fee</option>
                    <option value="EXAM_FEE">Exam Fee</option>
                  </Select>
                </Field>

                <Field label="Payment Method">
                  <Select name="paymentMethod" defaultValue={recordingPaymentFor.payment?.paymentMethod || "UPI"}>
                    <option value="UPI">UPI</option>
                    <option value="CASH">Cash</option>
                    <option value="BANK_TRANSFER">Bank Transfer</option>
                    <option value="CARD">Debit / Credit Card</option>
                  </Select>
                </Field>
              </div>

              <Field label="Payment Date">
                <Input
                  type="date"
                  name="paymentDate"
                  defaultValue={recordingPaymentFor.payment?.paymentDate || new Date().toISOString().slice(0, 10)}
                  required
                />
              </Field>

              <Field label="Notes / Reference">
                <Input
                  name="notes"
                  defaultValue={recordingPaymentFor.payment?.notes || "Demo Payment Entry"}
                  placeholder="Optional notes"
                />
              </Field>

              {payState?.error && <p className="text-xs text-danger font-medium">{payState.error}</p>}

              <div className="flex justify-end gap-2 pt-3 border-t border-line">
                <Button type="button" variant="outline" onClick={() => setRecordingPaymentFor(null)}>
                  Cancel
                </Button>
                <Button type="submit" loading={payPending}>
                  Save Payment
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT FEE STRUCTURE MODAL */}
      {editingStructure && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-card bg-surface p-6 hairline shadow-lift space-y-4">
            <div className="flex items-center justify-between border-b border-line pb-3">
              <h3 className="font-bold text-ink text-base">Edit Fee Structure</h3>
              <button
                onClick={() => setEditingStructure(null)}
                className="text-muted hover:text-ink font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form action={fsAction} className="space-y-3">
              <input type="hidden" name="id" value={editingStructure.id} />
              <input type="hidden" name="courseId" value={editingStructure.courseId} />

              <Field label="Admission Fee (₹)">
                <Input type="number" name="admissionFee" defaultValue={editingStructure.admissionFee} required />
              </Field>
              <Field label="Tuition Fee (₹)">
                <Input type="number" name="tuitionFee" defaultValue={editingStructure.tuitionFee} required />
              </Field>
              <Field label="Student Development Fee (₹)">
                <Input type="number" name="studentDevelopmentFee" defaultValue={editingStructure.studentDevelopmentFee} required />
              </Field>
              <Field label="University Exam Fee Text/Amount">
                <Input name="universityExamFee" defaultValue={editingStructure.universityExamFee} required />
              </Field>

              {fsState?.error && <p className="text-xs text-danger font-medium">{fsState.error}</p>}

              <div className="flex justify-end gap-2 pt-3 border-t border-line">
                <Button type="button" variant="outline" onClick={() => setEditingStructure(null)}>
                  Cancel
                </Button>
                <Button type="submit" loading={fsPending}>
                  Save Fee Structure
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT DUE RULE MODAL */}
      {editingRule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-card bg-surface p-6 hairline shadow-lift space-y-4">
            <div className="flex items-center justify-between border-b border-line pb-3">
              <h3 className="font-bold text-ink text-base">Edit Due Date & Fine Rule</h3>
              <button
                onClick={() => setEditingRule(null)}
                className="text-muted hover:text-ink font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form action={ruleAction} className="space-y-3">
              <input type="hidden" name="id" value={editingRule.id} />
              <input type="hidden" name="courseId" value={editingRule.courseId} />

              <Field label="Official Due Date">
                <Input type="date" name="dueDate" defaultValue={editingRule.dueDate} required />
              </Field>
              <Field label="Fine Type">
                <Select name="fineType" defaultValue={editingRule.fineType}>
                  <option value="PER_DAY">Per Day (₹50/day)</option>
                  <option value="FIXED">Fixed Amount</option>
                  <option value="NONE">None (No fine)</option>
                </Select>
              </Field>
              <Field label="Fine Value (₹)">
                <Input type="number" name="fineValue" defaultValue={editingRule.fineValue} required />
              </Field>
              <Field label="Maximum Fine Cap (₹)">
                <Input type="number" name="maxFine" defaultValue={editingRule.maxFine || 2500} required />
              </Field>

              {ruleState?.error && <p className="text-xs text-danger font-medium">{ruleState.error}</p>}

              <div className="flex justify-end gap-2 pt-3 border-t border-line">
                <Button type="button" variant="outline" onClick={() => setEditingRule(null)}>
                  Cancel
                </Button>
                <Button type="submit" loading={rulePending}>
                  Save Rule
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RECEIPT MODAL */}
      <ReceiptModal
        receipt={selectedReceipt}
        onClose={() => setSelectedReceipt(null)}
      />
    </div>
  );
}
