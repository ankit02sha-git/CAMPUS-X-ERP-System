"use client";
import { useActionState, useState } from "react";
import { saveStudentMaster, resetStudentActivation, toggleStudentStatus, deleteStudentMaster } from "@/actions/admin";
import type { FormState } from "@/actions/auth";
import { Badge, Button, Field, Input, Select } from "@/components/ui";
import { maskMobileNumber } from "@/lib/mobile";

type CourseOption = { id: string; code: string; name: string };
type MasterRow = {
  id: string;
  studentId: string;
  fullName: string;
  registeredMobile: string;
  courseId: string | null;
  courseCode?: string;
  semester: number | null;
  section: string | null;
  department: string | null;
  academicYear: string | null;
  rollNumber: string | null;
  dob?: string | null;
  activationStatus: string;
  status: string;
};

export function StudentMasterManager({
  students,
  courses,
}: {
  students: MasterRow[];
  courses: CourseOption[];
}) {
  const [editingRow, setEditingRow] = useState<MasterRow | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  const [saveState, saveAction, savePending] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await saveStudentMaster(editingRow?.id || null, prev, fd);
      if (res?.fieldErrors?._ok) {
        setEditingRow(null);
        setIsAdding(false);
      }
      return res;
    },
    undefined
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
        <div>
          <h2 className="text-lg font-semibold text-ink">Master Student Records ({students.length})</h2>
          <p className="text-xs text-muted">
            Admin maintains official student records before students can activate their accounts.
          </p>
        </div>
        <Button
          onClick={() => {
            setEditingRow(null);
            setIsAdding(true);
          }}
        >
          + Add Student Record
        </Button>
      </div>

      {/* Add / Edit Form Panel */}
      {(isAdding || editingRow) && (
        <div className="rounded-card bg-surface p-5 hairline shadow-lift space-y-4">
          <div className="flex items-center justify-between border-b border-line pb-3">
            <h3 className="font-semibold text-ink">
              {editingRow ? `Edit Student: ${editingRow.studentId}` : "Create Master Student Record"}
            </h3>
            <button
              onClick={() => {
                setIsAdding(false);
                setEditingRow(null);
              }}
              className="text-xs font-medium text-muted hover:text-ink"
            >
              ✕ Close
            </button>
          </div>

          <form action={saveAction} className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Student ID *" hint="e.g. SHC2504023">
                <Input
                  name="studentId"
                  defaultValue={editingRow?.studentId || ""}
                  required
                  placeholder="SHC2504023"
                  className="uppercase font-mono"
                />
              </Field>
              <Field label="Full Name *">
                <Input name="fullName" defaultValue={editingRow?.fullName || ""} required placeholder="Full Name" />
              </Field>
              <Field label="Registered Mobile *" hint="Used for OTP SMS">
                <Input
                  name="registeredMobile"
                  defaultValue={editingRow?.registeredMobile || ""}
                  required
                  placeholder="+919876543210"
                />
              </Field>
            </div>

            <div className="grid gap-3 sm:grid-cols-4">
              <Field label="Course *">
                <Select name="courseId" defaultValue={editingRow?.courseId || ""} required>
                  <option value="" disabled>
                    Select Course
                  </option>
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code} — {c.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Semester *">
                <Select name="semester" defaultValue={String(editingRow?.semester || 1)} required>
                  {[1, 2, 3, 4, 5, 6].map((s) => (
                    <option key={s} value={s}>
                      Semester {s}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Section">
                <Input name="section" defaultValue={editingRow?.section || ""} placeholder="A, B, C" />
              </Field>
              <Field label="Academic Year">
                <Input name="academicYear" defaultValue={editingRow?.academicYear || ""} placeholder="1st Year" />
              </Field>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Department">
                <Input name="department" defaultValue={editingRow?.department || ""} placeholder="Computer Applications" />
              </Field>
              <Field label="Roll Number">
                <Input name="rollNumber" defaultValue={editingRow?.rollNumber || ""} placeholder="Roll No." />
              </Field>
              <Field label="Date of Birth">
                <Input name="dob" type="date" defaultValue={editingRow?.dob || ""} />
              </Field>
            </div>

            {saveState?.error && (
              <p className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger font-medium">
                {saveState.error}
              </p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsAdding(false);
                  setEditingRow(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" loading={savePending}>
                Save Master Record
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* Table of Students */}
      <div className="overflow-x-auto rounded-card hairline bg-surface shadow-card">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-line text-xs uppercase tracking-wider text-muted">
            <tr>
              <th className="px-4 py-3">Student ID / Name</th>
              <th className="px-4 py-3">Course / Sem</th>
              <th className="px-4 py-3">Mobile (OTP)</th>
              <th className="px-4 py-3">Activation</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {students.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted">
                  No student master records found.
                </td>
              </tr>
            ) : (
              students.map((s) => (
                <tr key={s.id} className="hover:bg-line/20">
                  <td className="px-4 py-3">
                    <div className="font-semibold text-ink flex items-center gap-2">
                      <span className="font-mono text-xs text-brass font-bold">{s.studentId}</span>
                      <span>{s.fullName}</span>
                    </div>
                    <div className="text-xs text-muted">
                      {s.department && `${s.department} · `}
                      {s.section && `Sec ${s.section} · `}
                      {s.rollNumber && `Roll: ${s.rollNumber}`}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium">{s.courseCode || "N/A"}</div>
                    <div className="text-xs text-muted">Sem {s.semester}</div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">{maskMobileNumber(s.registeredMobile)}</td>
                  <td className="px-4 py-3">
                    <Badge tone={s.activationStatus === "ACTIVATED" ? "ok" : "warn"}>
                      {s.activationStatus === "ACTIVATED" ? "Activated" : "Not Activated"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone={s.status === "ACTIVE" ? "ok" : "danger"}>
                      {s.status === "ACTIVE" ? "Active" : "Disabled"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setIsAdding(false);
                          setEditingRow(s);
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleStudentStatus(s.id, s.status)}
                      >
                        {s.status === "ACTIVE" ? "Disable" : "Enable"}
                      </Button>
                      {s.activationStatus === "ACTIVATED" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-amber-600 border-amber-300 hover:bg-amber-50"
                          onClick={() => {
                            if (confirm(`Reset activation for ${s.studentId}? Student will have to reactivate via OTP.`)) {
                              resetStudentActivation(s.id);
                            }
                          }}
                        >
                          Reset Act.
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-danger border-danger/30 hover:bg-danger/10"
                        onClick={() => {
                          if (confirm(`Delete master record ${s.studentId}?`)) {
                            deleteStudentMaster(s.id);
                          }
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
