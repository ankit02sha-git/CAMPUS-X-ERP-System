"use client";
import { Pencil, Plus, Trash2, Upload } from "lucide-react";
import { useActionState, useEffect, useRef, useState, useTransition } from "react";
import { deleteEntity, saveEntity } from "@/actions/admin";
import type { FormState } from "@/actions/auth";
import { ImageUpload } from "@/components/ImageUpload";
import { Badge, Button, EmptyState, Field, Input, Select, Textarea } from "@/components/ui";
import { Modal } from "@/components/ui/Modal";
import type { ColumnDef, FieldDef } from "@/server/admin/registry";

type Row = Record<string, string | number | boolean | null>;
type Course = { id: string; code: string };
const courseLabel = (c: string) => (c === "BCOM" ? "B.Com" : c);

function DocUpload({ name, purpose, initial, label }: { name: string; purpose: string; initial?: string | null; label: string }) {
  const [url, setUrl] = useState(initial ?? ""); const [busy, setBusy] = useState(false); const [err, setErr] = useState(""); const ref = useRef<HTMLInputElement>(null);
  async function pick(f?: File) {
    if (!f) return; setErr(""); setBusy(true);
    const fd = new FormData(); fd.append("file", f); fd.append("purpose", purpose);
    try { const r = await fetch("/api/upload", { method: "POST", body: fd }); const j = await r.json(); if (r.ok) setUrl(j.url); else setErr(j.error ?? "Upload failed."); } catch { setErr("Network error."); }
    setBusy(false);
  }
  return (
    <div><span className="mb-1.5 block text-[13px] font-medium">{label}</span><input type="hidden" name={name} value={url} />
      <input ref={ref} type="file" className="sr-only" accept="application/pdf,image/jpeg,image/png,image/webp" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} aria-label={label} />
      <div className="flex items-center gap-2"><Button type="button" variant="outline" loading={busy} onClick={() => ref.current?.click()}><Upload className="h-4 w-4" />{url ? "Replace file" : "Choose file"}</Button>
        {url && <><a href={url} target="_blank" rel="noreferrer noopener" className="text-sm text-brass hover:underline">View</a><button type="button" onClick={() => setUrl("")} className="text-xs text-muted hover:text-danger">Remove</button></>}</div>
      {err && <p role="alert" className="mt-1 text-xs text-danger">{err}</p>}</div>
  );
}

function EntityForm({ entity, fields, courses, row, onDone }: { entity: string; fields: FieldDef[]; courses: Course[]; row: Row | null; onDone: () => void }) {
  const [state, action, pending] = useActionState<FormState, FormData>(saveEntity.bind(null, entity, (row?.id as string) ?? null), undefined);
  const e = state?.fieldErrors ?? {};
  useEffect(() => { if (e._ok) onDone(); }, [e._ok, onDone]);
  const v = (n: string) => row?.[n] ?? undefined;
  return (
    <form action={action} className="space-y-4">
      {fields.map((f) => {
        const err = e[f.name]; const dv = v(f.name);
        if (f.type === "image") return <ImageUpload key={f.name} name={f.name} purpose={f.purpose as "event"} initialUrl={dv as string} label={f.label} />;
        if (f.type === "document") return <DocUpload key={f.name} name={f.name} purpose={f.purpose!} initial={dv as string} label={f.label} />;
        if (f.type === "checkbox") return <label key={f.name} className="flex items-center gap-2 text-sm"><input type="checkbox" name={f.name} defaultChecked={row ? !!dv : f.name === "available" || f.name === "active"} className="h-4 w-4 accent-[rgb(var(--brass))]" />{f.label}</label>;
        return (
          <Field key={f.name} label={f.label} hint={f.hint} error={err}>
            {f.type === "textarea" ? <Textarea name={f.name} defaultValue={dv as string} required={f.required} />
              : f.type === "select" ? <Select name={f.name} defaultValue={(dv as string) ?? f.options?.[0]?.value}>{f.options!.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</Select>
              : f.type === "course" ? <Select name={f.name} defaultValue={(dv as string) ?? ""} required><option value="" disabled>Select</option>{courses.map((c) => <option key={c.id} value={c.id}>{courseLabel(c.code)}</option>)}</Select>
              : f.type === "semester" ? <Select name={f.name} defaultValue={String(dv ?? "")} required><option value="" disabled>Select</option>{[1, 2, 3, 4, 5, 6].map((s) => <option key={s} value={s}>Semester {s}</option>)}</Select>
              : <Input name={f.name} type={f.type === "datetime" ? "datetime-local" : f.type} defaultValue={dv as string} required={f.required} step={f.type === "time" ? 60 : undefined} />}
          </Field>
        );
      })}
      {state?.error && <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger">{state.error}</p>}
      <Button type="submit" loading={pending} className="w-full">{row ? "Save changes" : "Create"}</Button>
    </form>
  );
}

export function EntityManager({ entity, singular, fields, columns, rows, courses }: { entity: string; singular: string; fields: FieldDef[]; columns: ColumnDef[]; rows: Row[]; courses: Course[] }) {
  const [edit, setEdit] = useState<Row | "new" | null>(null);
  const [pending, start] = useTransition();
  const cmap = Object.fromEntries(courses.map((c) => [c.id, courseLabel(c.code)]));
  const close = () => setEdit(null);
  const cell = (r: Row, c: ColumnDef) => {
    const val = r[c.key];
    if (c.kind === "course") return cmap[val as string] ?? "—";
    if (c.kind === "bool") return <Badge tone={val ? "ok" : "neutral"}>{val ? "Yes" : "No"}</Badge>;
    if (c.kind === "money") return `₹${val}`;
    if (c.kind === "datetime") return val ? String(val).replace("T", " ") + " IST" : "—";
    return (val as string) ?? "—";
  };
  return (
    <div>
      <div className="mb-4 flex justify-end"><Button onClick={() => setEdit("new")}><Plus className="h-4 w-4" />Add {singular}</Button></div>
      {rows.length === 0 ? <EmptyState icon={<Plus className="h-6 w-6" />} title={`No ${singular}s yet`} body={`Add the first ${singular} to publish it to students.`} action={<Button onClick={() => setEdit("new")}>Add {singular}</Button>} /> : (
        <div className="overflow-x-auto rounded-card hairline bg-surface shadow-card">
          <table className="w-full min-w-[560px] text-left text-sm"><thead className="border-b border-line text-xs uppercase tracking-wider text-muted"><tr>{columns.map((c) => <th key={c.key} className="px-4 py-3 font-semibold">{c.label}</th>)}<th className="px-4 py-3"><span className="sr-only">Actions</span></th></tr></thead>
            <tbody className="divide-y divide-line">{rows.map((r) => (
              <tr key={r.id as string} className="hover:bg-line/20">{columns.map((c) => <td key={c.key} className="max-w-[240px] truncate px-4 py-2.5">{cell(r, c)}</td>)}
                <td className="whitespace-nowrap px-4 py-2.5 text-right"><button aria-label="Edit" onClick={() => setEdit(r)} className="rounded-ctl p-2 hover:bg-line/50"><Pencil className="h-4 w-4" /></button>
                  <button aria-label="Delete" disabled={pending} onClick={() => { if (confirm(`Delete this ${singular}?`)) start(() => deleteEntity(entity, r.id as string)); }} className="rounded-ctl p-2 text-danger hover:bg-danger/10"><Trash2 className="h-4 w-4" /></button></td></tr>))}</tbody></table>
        </div>)}
      <Modal open={edit !== null} onClose={close} title={edit === "new" ? `Add ${singular}` : `Edit ${singular}`}>
        {edit !== null && <EntityForm key={edit === "new" ? "new" : (edit.id as string)} entity={entity} fields={fields} courses={courses} row={edit === "new" ? null : edit} onDone={close} />}
      </Modal>
    </div>
  );
}
