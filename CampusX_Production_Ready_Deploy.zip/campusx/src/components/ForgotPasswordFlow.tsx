"use client";
import { useActionState, useEffect, useState } from "react";
import Link from "next/link";
import {
  startForgotPasswordAction,
  resetForgotPasswordAction,
  resendForgotPasswordOtpAction,
  type FormState,
} from "@/actions/auth";
import { Button, Field, Input, PasswordInput } from "@/components/ui";

const RESEND_COOLDOWN_FALLBACK = 60;

export function ForgotPasswordFlow() {
  const [step, setStep] = useState<number>(1);
  const [studentId, setStudentId] = useState<string>("");
  const [maskedMobile, setMaskedMobile] = useState<string>("");
  const [cooldown, setCooldown] = useState<number>(0);
  const [resendMessage, setResendMessage] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setInterval(() => {
      setCooldown((c) => (c > 0 ? c - 1 : 0));
    }, 1000);
    return () => clearInterval(id);
  }, [cooldown]);

  const [stateStep1, actionStep1, pendingStep1] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await startForgotPasswordAction(prev, fd);
      if (res?.step === 2 && res.studentId) {
        setStep(2);
        setStudentId(res.studentId);
        setMaskedMobile(res.maskedMobile || "");
        setCooldown(res.resendCooldownSeconds ?? RESEND_COOLDOWN_FALLBACK);
        setResendMessage(null);
      }
      return res;
    },
    undefined
  );

  const [stateStep2, actionStep2, pendingStep2] = useActionState<FormState, FormData>(
    resetForgotPasswordAction,
    undefined
  );

  const [, resendAction, pendingResend] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await resendForgotPasswordOtpAction(prev, fd);
      if (res?.step === 2 && !res.error) {
        setCooldown(res.resendCooldownSeconds ?? RESEND_COOLDOWN_FALLBACK);
        setResendMessage({ kind: "ok", text: res.successMessage || "A new verification code has been sent." });
      } else if (res?.error) {
        setResendMessage({ kind: "err", text: res.error });
      }
      return res;
    },
    undefined
  );

  const resendDisabled = cooldown > 0 || pendingResend || pendingStep2;
  const resendLabel = cooldown > 0 ? `Resend Code in ${cooldown}s` : "Resend Code";

  return (
    <div className="space-y-4">
      {step === 1 && (
        <form action={actionStep1} className="space-y-4">
          <Field label="Official Student ID" hint="Enter your Student ID (e.g. SHC2504023)">
            <Input name="studentId" placeholder="e.g. SHC2504023" required autoFocus autoComplete="username" className="uppercase font-mono" />
          </Field>
          {stateStep1?.error && (
            <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger">
              {stateStep1.error}
            </p>
          )}
          <Button type="submit" loading={pendingStep1} className="w-full">
            Send Reset Code
          </Button>
        </form>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <form action={actionStep2} className="space-y-4">
            <input type="hidden" name="studentId" value={studentId} />

            <div className="rounded-ctl bg-surface p-3.5 text-xs hairline">
              <p className="text-muted leading-relaxed">
                📲 Reset verification code sent via SMS to registered mobile: <strong className="text-ink">{maskedMobile}</strong>
              </p>
            </div>

            <Field label="6-Digit Verification Code">
              <Input
                name="otp"
                type="text"
                maxLength={6}
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="123456"
                required
                autoFocus
                className="font-mono text-center tracking-widest text-lg"
              />
            </Field>

            <Field label="New Password" hint="At least 6 characters" error={stateStep2?.fieldErrors?.newPassword}>
              <PasswordInput name="newPassword" required autoComplete="new-password" placeholder="••••••••" />
            </Field>

            {stateStep2?.error && (
              <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger font-medium">
                {stateStep2.error}
              </p>
            )}
            {stateStep2?.successMessage && (
              <div className="space-y-3">
                <p className="rounded-ctl bg-ok/10 px-3 py-2.5 text-sm text-ok font-medium">
                  {stateStep2.successMessage}
                </p>
                <Link
                  href="/login"
                  className="block w-full py-2.5 bg-brand text-white text-center rounded-ctl text-sm font-medium hover:bg-brand-dark transition-colors"
                >
                  Return to Sign In
                </Link>
              </div>
            )}

            {!stateStep2?.successMessage && (
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={() => setStep(1)} className="w-1/3">
                  Back
                </Button>
                <Button type="submit" loading={pendingStep2} className="w-2/3">
                  Reset Password
                </Button>
              </div>
            )}
          </form>

          {/* Resend Code */}
          {!stateStep2?.successMessage && (
            <form action={resendAction} className="pt-3 border-t border-line/60">
              <input type="hidden" name="studentId" value={studentId} />
              <div className="flex items-center justify-between gap-3">
                <span className="text-xs text-muted">Didn&rsquo;t receive it?</span>
                <Button
                  type="submit"
                  variant="outline"
                  size="sm"
                  loading={pendingResend}
                  disabled={resendDisabled}
                  aria-label={resendLabel}
                  aria-disabled={resendDisabled}
                >
                  {resendLabel}
                </Button>
              </div>
              {resendMessage && (
                <p
                  role={resendMessage.kind === "err" ? "alert" : "status"}
                  aria-live="polite"
                  className={`mt-2 rounded-ctl px-3 py-2 text-xs font-medium ${
                    resendMessage.kind === "ok"
                      ? "bg-ok/10 text-ok"
                      : "bg-danger/10 text-danger"
                  }`}
                >
                  {resendMessage.text}
                </p>
              )}
            </form>
          )}
        </div>
      )}

      <p className="text-center text-sm text-muted pt-2 border-t border-line">
        Remembered your password?{" "}
        <Link href="/login" className="font-medium text-brass hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
