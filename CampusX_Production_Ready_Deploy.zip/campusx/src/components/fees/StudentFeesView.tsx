"use client";

import React, { useState } from "react";
import { ReceiptModal, type FeeReceiptData } from "./ReceiptModal";
import { Badge, Button } from "@/components/ui";
import { CreditCard, CheckCircle2, AlertTriangle, Clock, Download, Info, ExternalLink, ShieldCheck } from "lucide-react";
import type { StudentFeeSummary } from "@/lib/fees";

interface StudentFeesViewProps {
  summary: StudentFeeSummary;
}

/**
 * Student Fees Portal View Component
 * Displays annual fee structure breakdown, payment progress bar, due date & late fine calculation,
 * payment transaction history, and printable official receipt download dialog.
 */
export function StudentFeesView({ summary }: StudentFeesViewProps) {
  const [selectedReceipt, setSelectedReceipt] = useState<FeeReceiptData | null>(null);

  /**
   * Helper function to render color-coded status badges for payment states
   */
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case "PAID":
        return (
          <Badge tone="ok" className="text-xs px-3 py-1 font-bold">
            PAID
          </Badge>
        );
      case "PARTIALLY_PAID":
        return (
          <Badge tone="warn" className="text-xs px-3 py-1 font-bold">
            PARTIALLY PAID
          </Badge>
        );
      default:
        return (
          <Badge tone="danger" className="text-xs px-3 py-1 font-bold">
            UNPAID
          </Badge>
        );
    }
  };

  const feeStructure = summary.feeStructure;
  const courseCode = summary.course?.code || "STUDENT";
  const academicSession = feeStructure?.academicSession || "2026-27";

  return (
    <div className="space-y-6">
      {/* Official Fee Structure Reference Notice */}
      <div className="rounded-card bg-amber-500/10 border border-amber-500/30 p-4 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-3">
        <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold uppercase tracking-wider text-[11px] block">
            Academic Demo Data Notice
          </span>
          <p>
            Fee structures are sourced from Study Hall College official website references. Student payment transaction histories are formatted for academic demonstration purposes.
          </p>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Known Annual Fee */}
        <div className="rounded-card bg-surface p-5 hairline shadow-sm space-y-1 border-t-2 border-brass">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">
            Known Annual Fee
          </div>
          <div className="text-2xl font-extrabold text-navy dark:text-white">
            ₹{summary.knownAnnualFee.toLocaleString("en-IN")}
          </div>
          <div className="text-[11px] text-muted font-medium">
            Session {academicSession} ({courseCode})
          </div>
        </div>

        {/* Amount Paid */}
        <div className="rounded-card bg-surface p-5 hairline shadow-sm space-y-1 border-t-2 border-emerald-500">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">
            Total Paid
          </div>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
            ₹{summary.amountPaid.toLocaleString("en-IN")}
          </div>
          <div className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold">
            {summary.progressPercentage}% Paid
          </div>
        </div>

        {/* Remaining Balance */}
        <div className="rounded-card bg-surface p-5 hairline shadow-sm space-y-1 border-t-2 border-amber-500">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">
            Remaining Balance
          </div>
          <div className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">
            ₹{summary.remainingAmount.toLocaleString("en-IN")}
          </div>
          <div className="text-[11px] text-muted font-medium">
            Excl. exam fee as per Uni
          </div>
        </div>

        {/* Fee Payment Status */}
        <div className="rounded-card bg-surface p-5 hairline shadow-sm space-y-2 border-t-2 border-brass flex flex-col justify-between">
          <div className="text-xs font-semibold text-muted uppercase tracking-wider">
            Fee Status
          </div>
          <div>{renderStatusBadge(summary.paymentStatus)}</div>
          <div className="text-[11px] text-muted font-medium">
            Official Course Standard
          </div>
        </div>
      </div>

      {/* Payment Progress Bar */}
      <div className="rounded-card bg-surface p-5 hairline shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="text-ink">Annual Fee Progress</span>
          <span className="text-brass">{summary.progressPercentage}% Paid</span>
        </div>
        <div className="h-3 w-full rounded-full bg-raised overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-brass to-emerald-500 transition-all duration-500"
            style={{ width: `${summary.progressPercentage}%` }}
          />
        </div>
        <div className="flex justify-between text-[11px] text-muted font-medium">
          <span>₹0</span>
          <span>₹{summary.knownAnnualFee.toLocaleString("en-IN")}</span>
        </div>
      </div>

      {/* Detailed Fee Breakdown & Due Date Card */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Official Fee Structure Itemization */}
        <div className="rounded-card bg-surface p-6 hairline shadow-card space-y-4">
          <div className="flex items-center justify-between border-b border-line pb-3">
            <h3 className="font-bold text-ink text-base">Official Fee Breakdown</h3>
            <span className="text-xs font-semibold text-brass">{courseCode}</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between py-1.5 border-b border-line/60">
              <span className="text-muted font-medium">Admission Fee</span>
              <span className="font-semibold text-ink">
                ₹{(feeStructure?.admissionFee ?? 2000).toLocaleString("en-IN")}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-line/60">
              <span className="text-muted font-medium">Tuition Fee</span>
              <span className="font-semibold text-ink">
                ₹{(feeStructure?.tuitionFee ?? 70000).toLocaleString("en-IN")}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-line/60">
              <span className="text-muted font-medium">Student Development Fee</span>
              <span className="font-semibold text-ink">
                ₹{(feeStructure?.studentDevelopmentFee ?? 1000).toLocaleString("en-IN")}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-line/60 items-center">
              <span className="text-muted font-medium">University Exam Fee</span>
              <span className="rounded-full bg-raised px-2.5 py-0.5 text-[11px] font-bold text-brass border border-line">
                {feeStructure?.universityExamFee === "AS_PER_UNIVERSITY"
                  ? "As per University"
                  : feeStructure?.universityExamFee}
              </span>
            </div>
            <div className="flex justify-between pt-3 text-sm font-bold border-t border-line">
              <span className="text-navy dark:text-white">Total Known Annual Fee</span>
              <span className="text-brass font-extrabold">
                ₹{summary.knownAnnualFee.toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          <div className="pt-2">
            <a
              href="https://www.studyhallcollege.org/fee-structure.php"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-brass hover:underline font-medium"
            >
              <span>Fee structure reference: Study Hall College official website 2026-27</span>
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>

        {/* Next Due & Late Fine Calculation Card */}
        <div className="rounded-card bg-surface p-6 hairline shadow-card space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-line pb-3">
              <h3 className="font-bold text-ink text-base">Next Payment & Due Info</h3>
              {summary.remainingAmount > 0 ? (
                <Badge tone="warn" className="text-xs">
                  DUE
                </Badge>
              ) : (
                <Badge tone="ok" className="text-xs">
                  NO DUE
                </Badge>
              )}
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-line/60">
                <span className="text-muted font-medium">Amount Remaining</span>
                <span className="font-extrabold text-navy dark:text-brass text-sm">
                  ₹{summary.remainingAmount.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-line/60">
                <span className="text-muted font-medium">Official Due Date</span>
                <span className="font-bold text-ink">
                  {summary.dueRule?.dueDate || "15 Oct 2026"}
                </span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-line/60 items-center">
                <div className="space-y-0.5">
                  <span className="text-muted font-medium block">Late Fine</span>
                  {summary.lateDays > 0 && (
                    <span className="text-[10px] text-danger font-semibold">
                      ({summary.lateDays} days overdue @ ₹{summary.dueRule?.fineValue || 50}/day)
                    </span>
                  )}
                </div>
                <span className="font-extrabold text-danger text-sm">
                  ₹{summary.lateFine.toLocaleString("en-IN")}
                </span>
              </div>

              <div className="flex justify-between pt-3 text-sm font-bold border-t border-line">
                <span className="text-navy dark:text-white">Total Payable Amount</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-extrabold text-base">
                  ₹{summary.totalPayable.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-line">
            <p className="text-[11px] text-muted italic">
              Payments can be deposited at the Study Hall College accounts desk or recorded via admin ERP.
            </p>
          </div>
        </div>
      </div>

      {/* Transaction History Table */}
      <div className="rounded-card bg-surface p-6 hairline shadow-card space-y-4">
        <div className="flex items-center justify-between border-b border-line pb-3">
          <div>
            <h3 className="font-bold text-ink text-base">Payment History</h3>
            <p className="text-xs text-muted">
              Record of payments made for the current academic session.
            </p>
          </div>
          <span className="text-xs text-muted font-semibold">
            {summary.payments.length} Transaction(s)
          </span>
        </div>

        {summary.payments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-raised/80 text-muted uppercase text-[11px] font-bold border-b border-line">
                  <th className="p-3">Date</th>
                  <th className="p-3">Receipt No</th>
                  <th className="p-3">Fee Type</th>
                  <th className="p-3">Method</th>
                  <th className="p-3">Transaction ID</th>
                  <th className="p-3 text-right">Amount</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line font-medium">
                {summary.payments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-raised/40 transition-colors">
                    <td className="p-3 font-semibold text-ink">{payment.paymentDate}</td>
                    <td className="p-3 font-mono font-bold text-navy dark:text-brass">
                      {payment.receiptNumber}
                    </td>
                    <td className="p-3 text-muted">{payment.feeType.replace("_", " ")}</td>
                    <td className="p-3 font-semibold text-ink">{payment.paymentMethod}</td>
                    <td className="p-3 font-mono text-[11px] text-muted">{payment.transactionId}</td>
                    <td className="p-3 text-right font-extrabold text-emerald-700 dark:text-emerald-400">
                      ₹{payment.amount.toLocaleString("en-IN")}
                    </td>
                    <td className="p-3 text-center">
                      <Badge tone="ok" className="text-[10px] px-2 py-0.5">
                        {payment.status}
                      </Badge>
                    </td>
                    <td className="p-3 text-center">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          setSelectedReceipt({
                            receiptNumber: payment.receiptNumber,
                            transactionId: payment.transactionId,
                            paymentDate: payment.paymentDate,
                            paymentMethod: payment.paymentMethod,
                            amount: payment.amount,
                            feeType: payment.feeType,
                            studentName: summary.student.name,
                            studentId: summary.student.studentId || summary.student.id,
                            courseCode: courseCode,
                            academicSession: academicSession,
                          })
                        }
                      >
                        Receipt
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-8 text-center text-muted text-xs italic">
            No payment history records found for this student.
          </div>
        )}
      </div>

      {/* Printable Receipt Modal Dialog */}
      <ReceiptModal
        receipt={selectedReceipt}
        onClose={() => setSelectedReceipt(null)}
      />
    </div>
  );
}
