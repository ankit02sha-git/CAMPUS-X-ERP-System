"use client";

import React, { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Button } from "@/components/ui";
import { Printer, X, CheckCircle2 } from "lucide-react";
import { customEaseCurve } from "@/components/ui/motion";

export type FeeReceiptData = {
  receiptNumber: string;
  transactionId: string;
  paymentDate: string;
  paymentMethod: string;
  amount: number;
  feeType: string;
  studentName: string;
  studentId: string;
  courseCode: string;
  academicSession: string;
};

export function ReceiptModal({
  receipt,
  onClose,
}: {
  receipt: FeeReceiptData | null;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!receipt) return;
    const handleKeyDown = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [receipt, onClose]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      {receipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 perspective-1000">
          {/* Backdrop blur overlay */}
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
          />

          {/* Floating 3D receipt container */}
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Fee Payment Receipt"
            className="relative w-full max-w-xl rounded-card bg-surface p-6 hairline shadow-lift space-y-6 max-h-[90vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.94, y: 24, rotateX: 4 }}
            animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 16, rotateX: -2 }}
            transition={{ duration: 0.3, ease: customEaseCurve }}
            style={{ transformStyle: "preserve-3d" }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-line pb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-bold text-ink text-base">Fee Payment Receipt</h3>
              </div>
              <button
                onClick={onClose}
                aria-label="Close modal"
                className="text-muted hover:text-ink font-bold text-sm rounded-ctl p-1 hover:bg-line/50"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* PRINTABLE RECEIPT CONTAINER */}
            <div id="printable-receipt" className="space-y-4 rounded-card hairline bg-raised/40 p-6 border border-line">
              {/* Header Branding */}
              <div className="text-center space-y-1 border-b border-line pb-4">
                <div className="text-xs uppercase font-extrabold tracking-widest text-muted">Study Hall College</div>
                <h2 className="text-xl font-extrabold text-navy dark:text-white tracking-tight">
                  CAMPUSX STUDENT PORTAL
                </h2>
                <div className="text-xs font-semibold text-brass">
                  OFFICIAL PAYMENT RECEIPT — SESSION {receipt.academicSession}
                </div>
                <div className="inline-block mt-1 text-[10px] uppercase tracking-wider font-extrabold text-amber-800 bg-amber-100 dark:bg-amber-950/60 dark:text-amber-300 px-2 py-0.5 rounded-full border border-amber-300">
                  Academic Project / Demo Receipt
                </div>
              </div>

              {/* Receipt Info Grid */}
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-muted font-medium">Receipt No:</span>
                  <div className="font-mono font-bold text-ink">{receipt.receiptNumber}</div>
                </div>
                <div>
                  <span className="text-muted font-medium">Date & Time:</span>
                  <div className="font-semibold text-ink">{receipt.paymentDate}</div>
                </div>
                <div>
                  <span className="text-muted font-medium">Student Name:</span>
                  <div className="font-bold text-navy dark:text-brass">{receipt.studentName}</div>
                </div>
                <div>
                  <span className="text-muted font-medium">Student Roll / ID:</span>
                  <div className="font-mono font-bold text-ink">{receipt.studentId}</div>
                </div>
                <div>
                  <span className="text-muted font-medium">Course:</span>
                  <div className="font-bold text-ink">{receipt.courseCode}</div>
                </div>
                <div>
                  <span className="text-muted font-medium">Payment Method:</span>
                  <div className="font-semibold text-ink">{receipt.paymentMethod}</div>
                </div>
              </div>

              {/* Transaction Summary */}
              <div className="mt-4 pt-4 border-t border-line space-y-2">
                <div className="flex justify-between text-xs py-1">
                  <span className="text-muted font-medium">Fee Description</span>
                  <span className="font-bold text-ink">{receipt.feeType.replace("_", " ")}</span>
                </div>
                <div className="flex justify-between text-xs py-1">
                  <span className="text-muted font-medium">Transaction ID</span>
                  <span className="font-mono text-muted">{receipt.transactionId}</span>
                </div>
                <div className="flex justify-between text-sm py-2 border-t border-line font-bold">
                  <span className="text-navy dark:text-white">Total Amount Paid</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-extrabold text-base">
                    ₹{receipt.amount.toLocaleString("en-IN")}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-2">
              <Button variant="outline" size="sm" onClick={onClose}>
                Close
              </Button>
              <div className="flex gap-2">
                <Button size="sm" onClick={handlePrint} className="flex items-center gap-1.5">
                  <Printer className="h-4 w-4" />
                  Print / Save PDF
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
