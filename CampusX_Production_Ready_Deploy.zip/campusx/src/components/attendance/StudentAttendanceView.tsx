"use client";

import React, { useState } from "react";
import { StudentAttendanceOverview } from "@/server/attendance";
import { fetchMyAttendanceAction } from "@/actions/attendance";
import Link from "next/link";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  BookOpen,
  Layers,
  ShieldCheck,
  Filter,
  RefreshCw,
  UserCheck,
  CalendarOff,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface StudentAttendanceViewProps {
  initialOverview: StudentAttendanceOverview;
  isAdmin?: boolean;
}

export function StudentAttendanceView({ initialOverview, isAdmin }: StudentAttendanceViewProps) {
  const [overview, setOverview] = useState<StudentAttendanceOverview>(initialOverview);
  const [selectedSem, setSelectedSem] = useState<number>(initialOverview.semester);
  const [threshold, setThreshold] = useState<number>(75);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleSemesterChange = async (sem: number) => {
    setSelectedSem(sem);
    setIsRefreshing(true);
    try {
      const data = await fetchMyAttendanceAction(sem, threshold);
      setOverview(data);
    } catch (err) {
      console.error("Failed to load attendance for semester", sem, err);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleThresholdChange = async (val: number) => {
    setThreshold(val);
    setIsRefreshing(true);
    try {
      const data = await fetchMyAttendanceAction(selectedSem, val);
      setOverview(data);
    } catch (err) {
      console.error("Failed to update threshold", val, err);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="space-y-6">
      {isAdmin && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-card bg-navy-deep text-white p-4 hairline shadow-md">
          <div className="flex items-center gap-3">
            <UserCheck className="h-5 w-5 text-shcyellow shrink-0" />
            <div className="text-xs">
              <strong className="font-bold text-white text-sm block">Administrator Mode Notice</strong>
              You are viewing student-side attendance. Attendance subjects & faculty names are derived directly from official timetable records.
            </div>
          </div>
          <Link
            href="/admin/attendance"
            className="rounded-ctl bg-shcyellow px-4 py-2 text-xs font-bold text-navy-deep hover:bg-amber-300 transition-colors shrink-0 text-center"
          >
            Go to Faculty Attendance Desk →
          </Link>
        </div>
      )}

      {/* Top Header Card */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-6 hairline shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1 rounded-full bg-brand/10 px-2.5 py-0.5 text-xs font-bold text-brand dark:text-sky-300">
              <ShieldCheck className="h-3.5 w-3.5" /> Official Timetable-Driven Attendance
            </span>
          </div>
          <h1 className="text-xl font-extrabold text-ink sm:text-2xl">Subject-Wise Attendance</h1>
          <p className="text-xs text-muted">
            Track class participation, attendance percentages, and low attendance alerts derived from your official class timetable.
          </p>
        </div>

        {/* Semester Selector Pill Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <span className="text-xs font-semibold text-muted shrink-0">Semester:</span>
          {overview.availableSemesters.map((s) => (
            <button
              key={s}
              onClick={() => handleSemesterChange(s)}
              disabled={isRefreshing}
              className={cn(
                "rounded-ctl px-3 py-1.5 text-xs font-bold transition-all shadow-xs shrink-0",
                selectedSem === s
                  ? "bg-navy-deep text-white ring-2 ring-brand/40"
                  : "bg-surface hairline text-muted hover:bg-raised hover:text-ink"
              )}
            >
              Sem {s}
            </button>
          ))}
        </div>
      </div>

      {!overview.available ? (
        /* RULE 6: Data Not Available state */
        <div className="rounded-card glass p-10 text-center hairline shadow-sm space-y-3">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-surface text-muted hairline">
            <CalendarOff className="h-7 w-7 text-muted" />
          </div>
          <h2 className="text-lg font-bold text-ink">Data Not Available</h2>
          <p className="text-xs text-muted max-w-md mx-auto">
            {overview.message || "Timetable data is not available for this class/semester yet."}
          </p>
        </div>
      ) : (
        <>
          {/* Overview Analytics Cards */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {/* Overall Percentage Card */}
            <div className="rounded-card glass p-5 hairline shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-muted uppercase">Overall Attendance</span>
                <BookOpen className="h-4 w-4 text-brand" />
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span
                  className={cn(
                    "text-3xl font-extrabold tracking-tight",
                    overview.overallPercentage >= threshold
                      ? "text-emerald-600 dark:text-emerald-400"
                      : "text-amber-600 dark:text-amber-400"
                  )}
                >
                  {overview.overallPercentage.toFixed(2)}%
                </span>
                <span className="text-xs text-muted font-medium">
                  ({overview.overallPresent} / {overview.overallTotal} sessions)
                </span>
              </div>
              <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-line/60">
                <div
                  className={cn(
                    "h-full transition-all duration-500",
                    overview.overallPercentage >= threshold ? "bg-emerald-500" : "bg-amber-500"
                  )}
                  style={{ width: `${Math.min(100, overview.overallPercentage)}%` }}
                />
              </div>
            </div>

            {/* Low Attendance Subjects Card */}
            <div className="rounded-card glass p-5 hairline shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-muted uppercase">Low Attendance Subjects</span>
                <AlertTriangle className="h-4 w-4 text-amber-500" />
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span
                  className={cn(
                    "text-3xl font-extrabold tracking-tight",
                    overview.lowAttendanceCount > 0 ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"
                  )}
                >
                  {overview.lowAttendanceCount}
                </span>
                <span className="text-xs text-muted font-medium">
                  subject{overview.lowAttendanceCount === 1 ? "" : "s"} below {threshold}%
                </span>
              </div>
              <p className="mt-2 text-[11px] text-muted">
                {overview.lowAttendanceCount > 0
                  ? "Immediate attention required to satisfy minimum attendance policy."
                  : "Great job! All subjects meet the minimum requirement."}
              </p>
            </div>

            {/* Configurable Threshold Settings Card */}
            <div className="rounded-card glass p-5 hairline shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-muted uppercase">Attendance Warning Threshold</span>
                <Filter className="h-4 w-4 text-brand" />
              </div>
              <div className="mt-3 flex items-center gap-3">
                <input
                  type="range"
                  min="50"
                  max="90"
                  step="5"
                  value={threshold}
                  onChange={(e) => handleThresholdChange(Number(e.target.value))}
                  className="w-full accent-brand cursor-pointer"
                />
                <span className="rounded-ctl bg-brand/10 px-2.5 py-1 font-mono text-xs font-bold text-brand dark:text-sky-300">
                  {threshold}%
                </span>
              </div>
              <p className="mt-2 text-[11px] text-muted">
                Study Hall College default requirement is 75%.
              </p>
            </div>
          </div>

          {/* Low Attendance Warning Alert */}
          {overview.lowAttendanceCount > 0 && (
            <div className="flex items-start gap-3 rounded-card bg-rose-500/10 border border-rose-500/30 p-4 text-rose-700 dark:text-rose-300 shadow-sm">
              <AlertTriangle className="h-5 w-5 shrink-0 text-rose-500 mt-0.5" />
              <div className="text-xs leading-relaxed">
                <strong className="font-bold text-sm block">Low Attendance Warning Detected</strong>
                You have {overview.lowAttendanceCount} subject(s) falling below the minimum {threshold}% requirement in Semester {selectedSem}. Please consult your subject faculty or class advisor.
              </div>
            </div>
          )}

          {/* Subject-Wise Attendance Breakdown Cards */}
          <div className="space-y-4">
            <h2 className="text-base font-bold text-ink flex items-center justify-between">
              <span>Semester {selectedSem} Timetable Subjects ({overview.subjectSummaries.length})</span>
              {isRefreshing && <RefreshCw className="h-4 w-4 animate-spin text-brand" />}
            </h2>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {overview.subjectSummaries.map((sub, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "rounded-card glass p-5 hairline shadow-sm transition-all hover:shadow-md",
                    sub.isLowAttendance && "border-rose-500/40 bg-rose-500/5"
                  )}
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <h3 className="font-bold text-base text-ink">{sub.subjectName}</h3>
                      <p className="text-xs font-semibold text-brand dark:text-sky-300 mt-0.5">
                        Faculty: {sub.facultyName}
                      </p>
                    </div>

                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-extrabold shadow-xs",
                        sub.isLowAttendance
                          ? "bg-rose-500 text-white"
                          : "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30"
                      )}
                    >
                      {sub.percentage.toFixed(2)}%
                    </span>
                  </div>

                  {/* Calculation breakdown: Present / Absent / Total */}
                  <div className="grid grid-cols-3 gap-2 rounded-ctl bg-surface p-2.5 text-center text-xs hairline mb-3">
                    <div>
                      <span className="text-[10px] text-muted block uppercase">Present</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm">{sub.presentClasses}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-muted block uppercase">Absent</span>
                      <span className="font-bold text-rose-600 dark:text-rose-400 text-sm">{sub.absentClasses}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-muted block uppercase">Total Classes</span>
                      <span className="font-bold text-ink text-sm">{sub.totalClasses}</span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="h-2 w-full overflow-hidden rounded-full bg-line/60">
                      <div
                        className={cn(
                          "h-full transition-all duration-300",
                          sub.isLowAttendance ? "bg-rose-500" : "bg-emerald-500"
                        )}
                        style={{ width: `${Math.min(100, sub.percentage)}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-muted">
                      <span>Formula: ({sub.presentClasses} / {sub.totalClasses}) × 100</span>
                      {sub.isLowAttendance && <span className="font-bold text-rose-500">Low Attendance</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
