"use client";

import React, { useState } from "react";
import { StudentExamCard, StudentResultSummary } from "@/server/exams";
import { fetchMyExamsAction, fetchMyResultsAction } from "@/actions/exams";
import { FileText, Calendar, Award, Info, Layers, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface StudentExamsViewProps {
  initialExams: StudentExamCard[];
  initialResults: StudentResultSummary[];
  currentSemester: number;
}

export function StudentExamsView({ initialExams, initialResults, currentSemester }: StudentExamsViewProps) {
  const [activeTab, setActiveTab] = useState<"schedules" | "results">("schedules");
  const [selectedSem, setSelectedSem] = useState<number>(currentSemester);
  const [examsList, setExamsList] = useState<StudentExamCard[]>(initialExams);
  const [resultsList, setResultsList] = useState<StudentResultSummary[]>(initialResults);
  const [isLoading, setIsLoading] = useState(false);

  const handleSemesterChange = async (sem: number) => {
    setSelectedSem(sem);
    setIsLoading(true);
    try {
      const [eRes, rRes] = await Promise.all([
        fetchMyExamsAction(sem),
        fetchMyResultsAction(sem),
      ]);
      setExamsList(eRes);
      setResultsList(rRes);
    } catch (err) {
      console.error("Failed to load exam data for semester", sem, err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-6 hairline shadow-sm">
        <div>
          <h1 className="text-xl font-extrabold text-ink sm:text-2xl flex items-center gap-2">
            <Award className="h-6 w-6 text-brand" /> Examinations & Marks Directory
          </h1>
          <p className="text-xs text-muted">
            Internal assessments, semester examination schedules, venue details, and academic marksheets.
          </p>
        </div>

        {/* Semester Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <span className="text-xs font-semibold text-muted shrink-0">Semester:</span>
          {[1, 2, 3, 4, 5, 6].map((s) => (
            <button
              key={s}
              onClick={() => handleSemesterChange(s)}
              className={cn(
                "rounded-ctl px-3 py-1.5 text-xs font-bold transition-all shadow-xs shrink-0",
                selectedSem === s
                  ? "bg-navy-deep text-white ring-2 ring-brand/40"
                  : "bg-surface hairline text-muted hover:bg-raised hover:text-ink"
              )}
            >
              Sem {s}
            </button>
          ))}
        </div>
      </div>

      {/* Demo Data Notice */}
      <div className="flex items-center gap-2.5 rounded-ctl bg-amber-500/10 border border-amber-500/30 p-3 text-xs text-amber-700 dark:text-amber-300">
        <Info className="h-4 w-4 shrink-0" />
        <span>
          <strong>Notice:</strong> Financial and academic marks presented herein are clearly flagged as <strong>Demo Academic Data</strong> for Study Hall College portal testing until official University publication.
        </span>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-line gap-2">
        <button
          onClick={() => setActiveTab("schedules")}
          className={cn(
            "flex items-center gap-2 px-4 py-2.5 text-xs font-bold transition-all border-b-2",
            activeTab === "schedules"
              ? "border-brand text-brand font-extrabold"
              : "border-transparent text-muted hover:text-ink"
          )}
        >
          <Calendar className="h-4 w-4" /> Exam Schedules ({examsList.length})
        </button>

        <button
          onClick={() => setActiveTab("results")}
          className={cn(
            "flex items-center gap-2 px-4 py-2.5 text-xs font-bold transition-all border-b-2",
            activeTab === "results"
              ? "border-brand text-brand font-extrabold"
              : "border-transparent text-muted hover:text-ink"
          )}
        >
          <Award className="h-4 w-4" /> Marks & Results ({resultsList.length})
        </button>
      </div>

      {/* TAB 1: Exam Schedules */}
      {activeTab === "schedules" && (
        <div className="space-y-6">
          {examsList.length === 0 ? (
            <div className="rounded-card glass p-8 text-center text-muted hairline">
              No exam schedules published for Semester {selectedSem}.
            </div>
          ) : (
            examsList.map((ex) => (
              <div key={ex.id} className="rounded-card glass p-6 hairline shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-line pb-3 gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="rounded-full bg-brand/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-brand dark:text-sky-300">
                        {ex.examType} EXAM
                      </span>
                      <span className="text-xs text-muted font-medium">
                        {ex.startDate} to {ex.endDate}
                      </span>
                    </div>
                    <h2 className="text-base font-bold text-ink sm:text-lg mt-1">{ex.title}</h2>
                  </div>
                </div>

                {ex.instructions && (
                  <div className="rounded-ctl bg-surface p-3 text-xs text-muted hairline italic">
                    <strong>Instructions:</strong> {ex.instructions}
                  </div>
                )}

                {/* Exam Papers Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-ink">
                    <thead className="bg-surface/90 text-muted uppercase font-semibold text-[11px] border-b border-line">
                      <tr>
                        <th className="px-4 py-2.5">Subject / Paper</th>
                        <th className="px-4 py-2.5">Exam Date</th>
                        <th className="px-4 py-2.5">Time</th>
                        <th className="px-4 py-2.5">Venue</th>
                        <th className="px-4 py-2.5 text-right">Max / Pass Marks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-line">
                      {ex.subjectsList.map((sub, idx) => (
                        <tr key={idx} className="hover:bg-raised/50 transition-colors">
                          <td className="px-4 py-3 font-bold">{sub.subjectName}</td>
                          <td className="px-4 py-3 font-medium">{sub.examDate}</td>
                          <td className="px-4 py-3 text-muted">{sub.startTime} - {sub.endTime}</td>
                          <td className="px-4 py-3 text-muted">{sub.venue || "Main Block"}</td>
                          <td className="px-4 py-3 text-right font-mono">
                            {sub.maxMarks} / <span className="text-muted">{sub.passMarks}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 2: Marks & Results */}
      {activeTab === "results" && (
        <div className="space-y-6">
          {resultsList.length === 0 ? (
            <div className="rounded-card glass p-8 text-center text-muted hairline">
              No examination marksheets published for Semester {selectedSem}.
            </div>
          ) : (
            resultsList.map((res, idx) => (
              <div key={idx} className="rounded-card glass p-6 hairline shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-line pb-3 gap-2">
                  <div>
                    <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold uppercase text-emerald-600 dark:text-emerald-400">
                      OFFICIAL STATEMENT OF MARKS
                    </span>
                    <h2 className="text-base font-bold text-ink sm:text-lg mt-1">{res.examTitle}</h2>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] text-muted block uppercase">Overall Result</span>
                      <span className="text-lg font-extrabold text-brand dark:text-shcyellow">
                        {res.overallPercentage}%
                      </span>
                    </div>

                    <span
                      className={cn(
                        "rounded-full px-3 py-1 text-xs font-extrabold uppercase shadow-xs",
                        res.finalStatus === "PASS"
                          ? "bg-emerald-500 text-white"
                          : "bg-rose-500 text-white"
                      )}
                    >
                      {res.finalStatus}
                    </span>
                  </div>
                </div>

                {/* Marks breakdown table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-ink">
                    <thead className="bg-surface/90 text-muted uppercase font-semibold text-[11px] border-b border-line">
                      <tr>
                        <th className="px-4 py-2.5">Subject</th>
                        <th className="px-4 py-2.5">Internal</th>
                        <th className="px-4 py-2.5">External</th>
                        <th className="px-4 py-2.5">Total / Max</th>
                        <th className="px-4 py-2.5">Grade</th>
                        <th className="px-4 py-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-line">
                      {res.subjectResults.map((sub, sIdx) => (
                        <tr key={sIdx} className="hover:bg-raised/50 transition-colors">
                          <td className="px-4 py-3 font-bold">{sub.subjectName}</td>
                          <td className="px-4 py-3 text-muted">{sub.internalMarks ?? "-"}</td>
                          <td className="px-4 py-3 text-muted">{sub.externalMarks ?? "-"}</td>
                          <td className="px-4 py-3 font-mono font-bold">
                            {sub.totalMarks} / {sub.maxMarks}
                          </td>
                          <td className="px-4 py-3 font-bold text-brand dark:text-sky-300">{sub.grade || "A"}</td>
                          <td className="px-4 py-3">
                            <span
                              className={cn(
                                "inline-block rounded-full px-2 py-0.5 text-[10px] font-bold uppercase",
                                sub.status === "PASS"
                                  ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
                                  : "bg-rose-500/15 text-rose-600 dark:text-rose-400"
                              )}
                            >
                              {sub.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
