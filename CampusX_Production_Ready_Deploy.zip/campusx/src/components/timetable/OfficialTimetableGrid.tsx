"use client";

import React from "react";
import { type TimetableMaster, type TimetableSlot } from "@/server/db/schema";
import { cn } from "@/lib/utils";

// Official Study Hall College Daily Period Timings
export const PERIODS = [
  { num: 1, label: "Period 1", time: "09:15 - 10:05" },
  { num: 2, label: "Period 2", time: "10:05 - 10:55" },
  { num: 3, label: "Period 3", time: "10:55 - 11:45" },
  { num: 4, label: "Period 4", time: "12:30 - 01:20" },
  { num: 5, label: "Period 5", time: "01:20 - 02:10" },
  { num: 6, label: "Period 6", time: "02:10 - 03:00" },
];

export const DAYS = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"] as const;

interface OfficialTimetableGridProps {
  master: TimetableMaster;
  slots: TimetableSlot[];
  onCellClick?: (day: string, period: number, slot?: TimetableSlot) => void;
  isAdmin?: boolean;
}

/**
 * Official Study Hall College Timetable Grid Component
 * Renders the weekly academic timetable matrix (Monday through Saturday, Periods 1 to 6).
 * Handles period merging (colSpan for double periods), subject color coding, and structural lunch break.
 */
export function OfficialTimetableGrid({
  master,
  slots,
  onCellClick,
  isAdmin = false,
}: OfficialTimetableGridProps) {
  // Map timetable slots by Day and Start Period for O(1) lookup
  const slotMap: Record<string, Record<number, TimetableSlot>> = {};
  for (const day of DAYS) {
    slotMap[day] = {};
  }

  for (const slot of slots) {
    if (slotMap[slot.day]) {
      slotMap[slot.day][slot.startPeriod] = slot;
    }
  }

  // Detect B.Com timetable format vs BCA timetable format for subject/faculty display preference
  const isBComFormat =
    master.title?.toUpperCase().includes("B.COM") ||
    master.title?.toUpperCase().includes("BCOM");

  /**
   * Returns background and border color styles for subjects based on their color theme.
   */
  const getColorClass = (theme?: string | null, isSpecial?: boolean, isFree?: boolean) => {
    if (isFree) {
      return "bg-slate-50 dark:bg-slate-900/30 text-muted border-line opacity-90";
    }

    switch (theme) {
      case "emerald":
      case "green":
        return "bg-emerald-100/80 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800";
      case "amber":
      case "yellow":
        return "bg-amber-100/80 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 border-amber-300 dark:border-amber-800";
      case "purple":
        return "bg-purple-100/80 dark:bg-purple-950/40 text-purple-900 dark:text-purple-200 border-purple-300 dark:border-purple-800";
      case "blue":
        return "bg-blue-100/80 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200 border-blue-300 dark:border-blue-800";
      case "rose":
      case "red":
        return "bg-rose-100/80 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200 border-rose-300 dark:border-rose-800";
      default:
        return isSpecial
          ? "bg-slate-100 dark:bg-slate-800/60 text-ink border-line"
          : "bg-surface text-ink border-line hover:bg-raised";
    }
  };

  /**
   * Formats period cell content based on college formatting guidelines:
   * B.Com format: Subject Name on line 1, (Faculty Name) in brackets on line 2.
   * BCA format: Faculty Name on line 1, Subject Name on line 2.
   */
  const renderCellContent = (slot: TimetableSlot | undefined) => {
    if (!slot) {
      return (
        <div className="text-muted text-[11px] italic py-2">
          {isAdmin ? "+ Add Class" : "—"}
        </div>
      );
    }

    const isFree = slot.entryType === "FREE_PERIOD" || slot.subjectName === "FREE PERIOD";

    if (isFree) {
      return (
        <div className="py-2.5 px-1 flex items-center justify-center">
          <span className="text-xs font-bold text-muted uppercase tracking-wider bg-line/40 px-2.5 py-1 rounded-md">
            FREE PERIOD
          </span>
        </div>
      );
    }

    if (isBComFormat) {
      // Special activities (Library, Mentor Session, etc.)
      if (
        slot.entryType === "LIBRARY_ACTIVITY" ||
        slot.activityTitle === "LIBRARY" ||
        slot.entryType === "MERGED_ACTIVITY" ||
        slot.isSpecialActivity
      ) {
        const title = slot.activityTitle || slot.subjectName || "SPECIAL ACTIVITY";
        return (
          <div className="space-y-1 py-1">
            <div className="font-extrabold text-[13px] text-navy dark:text-brass tracking-tight uppercase">
              {title}
            </div>
            {slot.activityDescription && (
              <div className="text-[10px] text-muted font-medium leading-tight whitespace-pre-line">
                {slot.activityDescription}
              </div>
            )}
            {slot.facultyName && (
              <div className="text-xs font-semibold text-ink/80">
                ({slot.facultyName})
              </div>
            )}
          </div>
        );
      }

      // Standard B.Com Class Cell: Subject first, then (Faculty Name)
      return (
        <div className="space-y-1 py-1">
          <div className="font-extrabold text-[13px] text-navy dark:text-brass leading-snug">
            {slot.subjectName || "—"}
          </div>
          {slot.facultyName && (
            <div className="text-xs font-semibold text-ink/80">
              ({slot.facultyName})
            </div>
          )}
        </div>
      );
    }

    // Default BCA Format: Faculty Name first, hyphen (-), then Subject Name
    if (slot.isSpecialActivity) {
      return (
        <div className="space-y-0.5 py-1">
          <div className="font-bold text-sm tracking-wide text-ink">
            {slot.activityTitle || slot.subjectName}
          </div>
          {slot.facultyName && (
            <div className="text-xs font-semibold">{slot.facultyName}</div>
          )}
          {slot.subjectName && slot.facultyName && <div className="text-xs text-muted">-</div>}
          {slot.subjectName && !slot.activityTitle && (
            <div className="text-xs font-bold">{slot.subjectName}</div>
          )}
          {slot.activityDescription && (
            <div className="text-[10px] text-muted italic font-medium">
              {slot.activityDescription}
            </div>
          )}
        </div>
      );
    }

    return (
      <div className="space-y-0.5 py-1">
        <div className="font-semibold text-[12.5px] text-ink">
          {slot.facultyName || "—"}
        </div>
        <div className="text-[10px] text-muted font-bold">-</div>
        <div className="font-extrabold text-[13px] text-navy dark:text-brass">
          {slot.subjectName || "—"}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* College Official Timetable Header */}
      <div className="rounded-card bg-surface p-6 hairline shadow-card text-center space-y-2 border-t-4 border-brass">
        <div className="text-xs uppercase font-extrabold tracking-widest text-muted">Study Hall College</div>
        <h2 className="text-2xl font-extrabold text-navy dark:text-white tracking-tight">
          {master.title || "CLASS TIME TABLE"}
        </h2>
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold text-brass">
          <span>TIME TABLE (W.e.f. {master.effectiveDate || "20th July, 2026"})</span>
          {master.classAdvisor && (
            <span className="rounded-full bg-brass/10 px-3 py-1 border border-brass/20 text-ink dark:text-brass">
              Class Advisor — {master.classAdvisor}
            </span>
          )}
        </div>
      </div>

      {/* Timetable Matrix Grid (Allows horizontal scroll on smaller screens) */}
      <div className="overflow-x-auto rounded-card hairline bg-surface shadow-card p-1">
        <table className="w-full min-w-[960px] border-collapse text-center text-xs">
          <thead>
            <tr className="bg-navy-deep text-white uppercase text-[11px] font-bold">
              <th className="p-3 w-28 border border-white/20">Day / Time</th>
              <th className="p-2.5 border border-white/20">
                <div>Period 1</div>
                <div className="text-[10px] font-normal opacity-80">09:15 - 10:05</div>
              </th>
              <th className="p-2.5 border border-white/20">
                <div>Period 2</div>
                <div className="text-[10px] font-normal opacity-80">10:05 - 10:55</div>
              </th>
              <th className="p-2.5 border border-white/20">
                <div>Period 3</div>
                <div className="text-[10px] font-normal opacity-80">10:55 - 11:45</div>
              </th>

              {/* Structural Lunch Break Column Header */}
              <th className="p-2.5 w-16 bg-amber-500/20 border border-white/20 text-amber-900 dark:text-amber-200">
                <div>Lunch Break</div>
                <div className="text-[9px] font-normal">11:45 - 12:30</div>
              </th>

              <th className="p-2.5 border border-white/20">
                <div>Period 4</div>
                <div className="text-[10px] font-normal opacity-80">12:30 - 01:20</div>
              </th>
              <th className="p-2.5 border border-white/20">
                <div>Period 5</div>
                <div className="text-[10px] font-normal opacity-80">01:20 - 02:10</div>
              </th>
              <th className="p-2.5 border border-white/20">
                <div>Period 6</div>
                <div className="text-[10px] font-normal opacity-80">02:10 - 03:00</div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {DAYS.map((day, rowIndex) => {
              const daySlots = slotMap[day] || {};
              let periodPointer = 1;

              return (
                <tr key={day} className="min-h-[72px]">
                  {/* Day Column Header */}
                  <td className="p-3 font-bold uppercase text-navy dark:text-brass bg-raised/80 border border-line w-28 text-left">
                    {day}
                  </td>

                  {/* Render Morning Periods (1 to 3) */}
                  {[1, 2, 3].map((period) => {
                    if (period < periodPointer) return null; // Skip rendering if covered by a multi-period colSpan

                    const slot = daySlots[period];
                    const span = slot?.spanPeriods || 1;
                    periodPointer = period + span;
                    const isFree = slot?.entryType === "FREE_PERIOD" || slot?.subjectName === "FREE PERIOD";

                    return (
                      <td
                        key={period}
                        colSpan={span}
                        onClick={() => isAdmin && onCellClick && onCellClick(day, period, slot)}
                        className={cn(
                          "p-2.5 border border-line min-h-[72px] transition-all",
                          getColorClass(slot?.colorTheme, slot?.isSpecialActivity, isFree),
                          isAdmin && "cursor-pointer hover:ring-2 hover:ring-brass"
                        )}
                      >
                        {renderCellContent(slot)}
                      </td>
                    );
                  })}

                  {/* Structural Lunch Break Cell: Rendered once on Row 1 spanning all 6 rows */}
                  {rowIndex === 0 ? (
                    <td
                      rowSpan={6}
                      className="bg-amber-50 dark:bg-amber-950/30 border border-line text-amber-900 dark:text-amber-200 font-extrabold text-xs uppercase tracking-wider p-2 select-none"
                    >
                      <div className="writing-mode-vertical py-4 flex flex-col items-center justify-center gap-2">
                        <span>L</span>
                        <span>U</span>
                        <span>N</span>
                        <span>C</span>
                        <span>H</span>
                        <span className="my-2 h-4 w-px bg-amber-400" />
                        <span>B</span>
                        <span>R</span>
                        <span>E</span>
                        <span>A</span>
                        <span>K</span>
                      </div>
                    </td>
                  ) : null}

                  {/* Render Afternoon Periods (4 to 6) */}
                  {[4, 5, 6].map((period) => {
                    if (period < periodPointer) return null; // Skip rendering if covered by a multi-period colSpan

                    const slot = daySlots[period];
                    const span = slot?.spanPeriods || 1;
                    periodPointer = period + span;
                    const isFree = slot?.entryType === "FREE_PERIOD" || slot?.subjectName === "FREE PERIOD";

                    return (
                      <td
                        key={period}
                        colSpan={span}
                        onClick={() => isAdmin && onCellClick && onCellClick(day, period, slot)}
                        className={cn(
                          "p-2.5 border border-line min-h-[72px] transition-all",
                          getColorClass(slot?.colorTheme, slot?.isSpecialActivity, isFree),
                          isAdmin && "cursor-pointer hover:ring-2 hover:ring-brass"
                        )}
                      >
                        {renderCellContent(slot)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
