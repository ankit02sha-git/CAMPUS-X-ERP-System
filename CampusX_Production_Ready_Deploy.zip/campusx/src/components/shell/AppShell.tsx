"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, Search as SearchIcon, X, LogOut } from "lucide-react";
import { Logo } from "@/components/Logo";
import { cn } from "@/lib/utils";
import { logoutAction } from "@/actions/auth";
import { ADMIN_NAV, MOBILE_TABS, NAV } from "./nav";
import { CommandPalette } from "./CommandPalette";
import { NotificationCenter } from "./NotificationCenter";
import { ThemeToggle } from "./ThemeToggle";
import { BirthdayBanner } from "@/components/birthday/BirthdayBanner";

interface UserProfile {
  name: string;
  role: "STUDENT" | "ADMIN";
  image: string | null;
}

interface NavLinksProps {
  role: UserProfile["role"];
  onNavigate?: () => void;
}

/**
 * Sidebar Navigation Links
 * Renders navigation items based on user role (Student vs Admin).
 * Highlights active link using Liquid Glass layout animations and brand blue glow.
 */
function NavLinks({ role, onNavigate }: NavLinksProps) {
  const currentPath = usePathname();
  const navigationItems = role === "ADMIN" ? [ADMIN_NAV, ...NAV] : NAV;

  return (
    <nav aria-label="Primary" className="space-y-1">
      {navigationItems.map(({ href, label, icon: Icon }) => {
        const isActive = currentPath === href || (href !== "/dashboard" && currentPath.startsWith(href));

        return (
          <Link
            key={href}
            href={href}
            onClick={onNavigate}
            aria-current={isActive ? "page" : undefined}
            className={cn(
              "group relative flex items-center gap-3 rounded-ctl px-3.5 py-2.5 text-[13.5px] font-medium transition-all duration-fast select-none",
              isActive ? "text-white font-semibold" : "text-white/75 hover:bg-white/10 hover:text-white"
            )}
          >
            {/* Liquid Glass Pill indicator for active navigation item */}
            {isActive && (
              <motion.span
                layoutId="nav-active"
                className="pointer-events-none absolute inset-0 rounded-ctl bg-gradient-to-r from-brand to-brand-dark shadow-[0_4px_20px_-4px_rgba(32,98,172,0.6)] border border-white/20"
                transition={{ type: "spring", stiffness: 400, damping: 32 }}
              />
            )}
            {/* Left accent marker line with glow */}
            {isActive && (
              <span className="pointer-events-none absolute left-0 top-2.5 bottom-2.5 w-[3.5px] rounded-full bg-shcyellow shadow-[0_0_8px_rgba(245,197,66,0.8)]" />
            )}
            <Icon
              className={cn(
                "relative z-10 h-[17px] w-[17px] transition-transform duration-fast group-hover:scale-110",
                isActive ? "text-shcyellow" : "text-white/70 group-hover:text-white"
              )}
              aria-hidden
            />
            <span className="relative z-10">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

interface AppShellProps {
  user: UserProfile;
  children: React.ReactNode;
}

/**
 * Primary Application Shell Layout
 * Provides desktop liquid glass sidebar, sticky glass header, search command palette (Ctrl+K),
 * dark mode theme toggle, mobile drawer navigation, and animated page transitions.
 */
export function AppShell({ user, children }: AppShellProps) {
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const currentPath = usePathname();

  // Close mobile drawer automatically when navigating to a new route
  useEffect(() => {
    setIsMobileDrawerOpen(false);
  }, [currentPath]);

  // Keyboard shortcut listener for Command Palette (Ctrl + K or Cmd + K)
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Compute 2-letter user initials for avatar display
  const userInitials = user.name
    .split(" ")
    .map((word) => word[0])
    .slice(0, 2)
    .join("");

  return (
    <div className="bg-atmosphere min-h-dvh">
      {/* Desktop Fixed Liquid Glass Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[256px] flex-col glass-sidebar px-4 py-5 text-white lg:flex">
        <Link href="/dashboard" className="mb-7 px-1">
          <Logo onDark />
        </Link>
        <div className="flex-1 overflow-y-auto no-scrollbar">
          <NavLinks role={user.role} />
        </div>

        {/* User Account & Logout Footer */}
        <form action={logoutAction} className="mt-3 border-t border-white/10 pt-3">
          <div className="mb-2 flex items-center gap-2.5 px-2">
            <div className="grid h-8 w-8 place-items-center rounded-full bg-brand text-xs font-semibold text-white shadow-md border border-white/20">
              {userInitials}
            </div>
            <div className="min-w-0 text-[13px] leading-tight">
              <div className="truncate font-semibold">{user.name}</div>
              <div className="text-xs text-white/60">{user.role === "ADMIN" ? "Administrator" : "Student"}</div>
            </div>
          </div>
          <button
            type="submit"
            className="flex w-full items-center gap-2 rounded-ctl px-3 py-2 text-[13px] text-white/75 transition-colors hover:bg-white/10 hover:text-white active:scale-98"
          >
            <LogOut className="h-4 w-4" aria-hidden />
            Sign out
          </button>
        </form>
      </aside>

      {/* Main Content Viewport */}
      <div className="lg:pl-[256px]">
        {/* Sticky Glass Top Header */}
        <header className="glass-header sticky top-0 z-20 flex h-14 items-center gap-2 px-3 md:px-6 shadow-xs">
          <button
            className="rounded-ctl p-2 hover:bg-line/50 lg:hidden"
            onClick={() => setIsMobileDrawerOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="lg:hidden">
            <Logo compact />
          </div>

          {/* Liquid Glass Search Command Trigger Input (Ctrl + K) */}
          <button
            onClick={() => setIsCommandPaletteOpen(true)}
            className="ml-1 flex h-9 flex-1 items-center gap-2.5 rounded-ctl glass-input px-3.5 text-left text-sm text-muted hover:text-ink hover:border-brand/40 shadow-xs md:max-w-md transition-all"
            aria-label="Search CampusX (Ctrl K)"
          >
            <SearchIcon className="h-4 w-4 text-brand" aria-hidden />
            <span className="flex-1 truncate font-medium">Search CampusX…</span>
            <kbd className="hidden rounded border border-line bg-surface/80 px-2 py-0.5 font-mono text-[10px] font-bold text-muted shadow-xs md:block">
              Ctrl K
            </kbd>
          </button>

          <div className="flex-1 md:hidden" />
          <ThemeToggle />
          <NotificationCenter />
        </header>

        {/* Animated Main Route View */}
        <main id="main" className="mx-auto w-full max-w-[1180px] px-4 pb-28 pt-6 md:px-6 lg:pb-12">
          <BirthdayBanner />
          <motion.div
            key={currentPath}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            {children}
          </motion.div>
        </main>
      </div>

      {/* Mobile Bottom Quick Navigation Bar */}
      <nav
        aria-label="Quick"
        className="glass fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line pb-[env(safe-area-inset-bottom)] lg:hidden"
      >
        {NAV.filter((navItem) => (MOBILE_TABS as readonly string[]).includes(navItem.href)).map(
          ({ href, label, icon: Icon }) => {
            const isActive = currentPath.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[10.5px] font-semibold",
                  isActive ? "text-brand font-bold" : "text-muted"
                )}
              >
                <Icon className="h-5 w-5" aria-hidden />
                {label.split(" ")[0]}
              </Link>
            );
          }
        )}
        <button
          onClick={() => setIsMobileDrawerOpen(true)}
          className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[10.5px] font-medium text-muted"
        >
          <Menu className="h-5 w-5" aria-hidden />
          More
        </button>
      </nav>

      {/* Mobile Sidebar Navigation Drawer */}
      <AnimatePresence>
        {isMobileDrawerOpen && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileDrawerOpen(false)}
            />
            <motion.aside
              role="dialog"
              aria-modal="true"
              aria-label="Menu"
              className="fixed inset-y-0 left-0 z-50 w-[280px] overflow-y-auto glass-sidebar p-4 text-white shadow-lift lg:hidden"
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: "spring", stiffness: 360, damping: 36 }}
            >
              <div className="mb-5 flex items-center justify-between px-1">
                <Logo onDark />
                <button
                  onClick={() => setIsMobileDrawerOpen(false)}
                  className="rounded-ctl p-2 hover:bg-white/10"
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <NavLinks role={user.role} onNavigate={() => setIsMobileDrawerOpen(false)} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Command Palette Search Modal */}
      <CommandPalette
        open={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        isAdmin={user.role === "ADMIN"}
      />
    </div>
  );
}
