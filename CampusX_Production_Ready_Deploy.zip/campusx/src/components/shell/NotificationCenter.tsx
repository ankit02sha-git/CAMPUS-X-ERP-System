"use client";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, CheckCheck } from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { timeAgo } from "@/lib/utils";

type N = { id: string; title: string; body: string | null; link: string | null; read: boolean; createdAt: string };

export function NotificationCenter() {
  const [items, setItems] = useState<N[]>([]);
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const unread = items.filter((i) => !i.read).length;

  const load = useCallback(async () => {
    try { const r = await fetch("/api/notifications", { cache: "no-store" }); if (r.ok) setItems((await r.json()).items); } catch {} finally { setLoaded(true); }
  }, []);
  useEffect(() => { load(); const t = setInterval(load, 30_000); return () => clearInterval(t); }, [load]);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (open && !ref.current?.contains(e.target as Node)) setOpen(false); };
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", h); document.addEventListener("keydown", k);
    return () => { document.removeEventListener("mousedown", h); document.removeEventListener("keydown", k); };
  }, [open]);

  async function mark(ids?: string[]) {
    setItems((s) => s.map((n) => (!ids || ids.includes(n.id) ? { ...n, read: true } : n)));
    await fetch("/api/notifications", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) });
  }

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((v) => !v)} className="relative rounded-ctl p-2 text-muted transition-colors hover:bg-line/50 hover:text-ink" aria-label={`Notifications, ${unread} unread`} aria-expanded={open}>
        <Bell className="h-[18px] w-[18px]" />
        <AnimatePresence>{unread > 0 && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-shcred px-1 text-[9px] font-bold text-white">{unread > 9 ? "9+" : unread}</motion.span>}</AnimatePresence>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -6, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.18 }}
            className="fixed inset-x-3 top-16 z-50 overflow-hidden rounded-card hairline bg-surface shadow-lift sm:absolute sm:inset-x-auto sm:right-0 sm:top-11 sm:w-[380px]">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h2 className="font-display text-base font-semibold">Notifications</h2>
              {unread > 0 && <button onClick={() => mark()} className="flex items-center gap-1 text-xs font-medium text-brass hover:underline"><CheckCheck className="h-3.5 w-3.5" />Mark all read</button>}
            </div>
            <ul className="max-h-[60vh] overflow-y-auto">
              {!loaded && <li className="p-4"><div className="skeleton h-10" /></li>}
              {loaded && items.length === 0 && <li className="px-4 py-10 text-center text-sm text-muted">You&apos;re all caught up.</li>}
              {items.map((n) => (
                <motion.li key={n.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                  <Link href={n.link ?? "#"} onClick={() => { mark([n.id]); setOpen(false); }} className={`flex gap-3 border-b border-line/60 px-4 py-3 text-sm transition-colors hover:bg-line/30 ${n.read ? "" : "bg-brass/[0.06]"}`}>
                    <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${n.read ? "bg-transparent" : "bg-brass"}`} />
                    <span className="min-w-0"><span className="block font-medium">{n.title}</span>{n.body && <span className="line-clamp-2 text-muted">{n.body}</span>}<span className="mt-0.5 block text-xs text-muted">{timeAgo(n.createdAt)}</span></span>
                  </Link>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
