"use client";
import { AnimatePresence, motion } from "framer-motion";
import { Search } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { ADMIN_NAV, NAV } from "./nav";

type Hit = { group: string; title: string; sub?: string; href: string };

export function CommandPalette({ open, onClose, isAdmin }: { open: boolean; onClose: () => void; isAdmin: boolean }) {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<Hit[]>([]);
  const [loading, setLoading] = useState(false);
  const [sel, setSel] = useState(0);
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);

  const pages: Hit[] = useMemo(() => (isAdmin ? [...NAV, ADMIN_NAV] : NAV).map((n) => ({ group: "Go to", title: n.label, href: n.href })), [isAdmin]);
  const shown = q.trim().length < 2 ? pages : [...pages.filter((p) => p.title.toLowerCase().includes(q.toLowerCase())), ...hits];

  useEffect(() => { if (open) { setQ(""); setHits([]); setSel(0); setTimeout(() => input.current?.focus(), 30); } }, [open]);
  useEffect(() => {
    if (q.trim().length < 2) return;
    const ctrl = new AbortController(); setLoading(true);
    const t = setTimeout(async () => {
      try { const r = await fetch(`/api/search?q=${encodeURIComponent(q.trim())}`, { signal: ctrl.signal }); if (r.ok) setHits((await r.json()).hits); } catch {} finally { setLoading(false); }
    }, 180);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [q]);
  useEffect(() => setSel(0), [q]);

  function go(h: Hit) { onClose(); router.push(h.href); }
  function key(e: React.KeyboardEvent) {
    if (e.key === "Escape") onClose();
    if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, shown.length - 1)); }
    if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
    if (e.key === "Enter" && shown[sel]) go(shown[sel]);
  }
  let last = "";
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] grid place-items-start justify-items-center px-4 pt-[12vh]" onKeyDown={key}>
          <motion.div className="absolute inset-0 bg-black/45 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
          <motion.div role="dialog" aria-modal="true" aria-label="Search" className="relative w-full max-w-xl overflow-hidden rounded-card hairline bg-surface shadow-lift"
            initial={{ opacity: 0, y: -12, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: 0.98 }} transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}>
            <div className="flex items-center gap-3 border-b border-line px-4">
              <Search className="h-4 w-4 text-muted" aria-hidden />
              <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search notes, events, announcements, lost items…" aria-label="Search" className="h-14 flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted/70" />
              {loading && <span className="text-xs text-muted">Searching…</span>}
            </div>
            <ul className="max-h-[52vh] overflow-y-auto p-2" role="listbox">
              {shown.length === 0 && <li className="px-3 py-8 text-center text-sm text-muted">{loading ? "Searching…" : "No results found."}</li>}
              {shown.map((h, i) => {
                const head = h.group !== last; last = h.group;
                return (
                  <li key={h.href + h.title + i} role="option" aria-selected={i === sel}>
                    {head && <div className="eyebrow px-3 pb-1 pt-2.5">{h.group}</div>}
                    <button onMouseEnter={() => setSel(i)} onClick={() => go(h)} className={`flex w-full items-center justify-between gap-3 rounded-ctl px-3 py-2 text-left text-sm ${i === sel ? "bg-brass/12" : ""}`}>
                      <span className="truncate font-medium">{h.title}</span><span className="truncate text-xs text-muted">{h.sub}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
