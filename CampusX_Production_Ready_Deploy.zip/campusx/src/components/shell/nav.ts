import {
  Bell,
  BookOpen,
  CalendarDays,
  Calendar,
  ClipboardList,
  Clock,
  CreditCard,
  Home,
  Megaphone,
  Search,
  ShieldCheck,
  Soup,
  University,
  User,
  UserCheck,
  Award,
  LifeBuoy,
  Users,
  IdCard,
} from "lucide-react";

export const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: Home },
  { href: "/fees", label: "Fees & Payments", icon: CreditCard },
  { href: "/attendance", label: "Attendance", icon: UserCheck },
  { href: "/timetable", label: "Timetable", icon: Clock },
  { href: "/assignments", label: "Assignments", icon: ClipboardList },
  { href: "/notes", label: "Notes & Resources", icon: BookOpen },
  { href: "/exams", label: "Exams & Results", icon: Award },
  { href: "/academic-calendar", label: "Academic Calendar", icon: Calendar },
  { href: "/events", label: "Events", icon: CalendarDays },
  { href: "/lost-found", label: "Lost & Found", icon: Search },
  { href: "/grievance", label: "Help Desk / Grievances", icon: LifeBuoy },
  { href: "/id-card", label: "Digital ID Card", icon: IdCard },
  { href: "/faculty", label: "Faculty Directory", icon: Users },
  { href: "/campus", label: "Campus Directory", icon: University },
  { href: "/announcements", label: "Announcements", icon: Megaphone },
  { href: "/profile", label: "Profile", icon: User },
] as const;

export const ADMIN_NAV = { href: "/admin", label: "Admin Control", icon: ShieldCheck } as const;
export const MOBILE_TABS = ["/dashboard", "/attendance", "/timetable", "/assignments"] as const;
export { Bell };
