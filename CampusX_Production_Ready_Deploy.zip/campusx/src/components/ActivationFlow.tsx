"use client";
import { useActionState, useEffect, useState } from "react";
import Link from "next/link";
import {
  startActivationAction,
  verifyActivationOtpAction,
  completeActivationAction,
  resendActivationOtpAction,
  type FormState,
} from "@/actions/auth";
import { Button, Field, Input, PasswordInput } from "@/components/ui";

/** Fallback cooldown (server always dictates the real value in its response). */
const RESEND_COOLDOWN_FALLBACK = 60;

export function ActivationFlow() {
  const [step, setStep] = useState<number>(1);
  const [studentId, setStudentId] = useState<string>("");
  const [maskedMobile, setMaskedMobile] = useState<string>("");
  const [verifiedOtp, setVerifiedOtp] = useState<string>("");
  const [cooldown, setCooldown] = useState<number>(0);
  const [resendMessage, setResendMessage] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setInterval(() => {
      setCooldown((c) => (c > 0 ? c - 1 : 0));
    }, 1000);
    return () => clearInterval(id);
  }, [cooldown]);

  const [stateStep1, actionStep1, pendingStep1] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await startActivationAction(prev, fd);
      if (res?.step === 2 && res.studentId) {
        setStep(2);
        setStudentId(res.studentId);
        setMaskedMobile(res.maskedMobile || "");
        setCooldown(res.resendCooldownSeconds ?? RESEND_COOLDOWN_FALLBACK);
        setResendMessage(null);
      }
      return res;
    },
    undefined
  );

  const [stateStep2, actionStep2, pendingStep2] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await verifyActivationOtpAction(prev, fd);
      if (res?.step === 3 && res.studentId) {
        setStep(3);
        const enteredOtp = String(fd.get("otp") || "").trim();
        setVerifiedOtp(enteredOtp);
      }
      return res;
    },
    undefined
  );

  const [stateStep3, actionStep3, pendingStep3] = useActionState<FormState, FormData>(
    completeActivationAction,
    undefined
  );

  const [, resendAction, pendingResend] = useActionState<FormState, FormData>(
    async (prev, fd) => {
      const res = await resendActivationOtpAction(prev, fd);
      if (res?.step === 2 && !res.error) {
        setCooldown(res.resendCooldownSeconds ?? RESEND_COOLDOWN_FALLBACK);
        setResendMessage({ kind: "ok", text: res.successMessage || "A new verification code has been sent." });
      } else if (res?.error) {
        setResendMessage({ kind: "err", text: res.error });
      }
      return res;
    },
    undefined
  );

  const resendDisabled = cooldown > 0 || pendingResend || pendingStep2 || pendingStep3;
  const resendLabel = cooldown > 0 ? `Resend Code in ${cooldown}s` : "Resend Code";

  return (
    <div className="space-y-5">
      {/* Progress Steps Indicator */}
      <div className="flex items-center justify-between text-xs font-semibold text-muted border-b border-line pb-3">
        <div className={`flex items-center gap-1.5 ${step >= 1 ? "text-brass font-bold" : ""}`}>
          <span className="grid h-5 w-5 place-items-center rounded-full bg-brass/10 text-[11px]">1</span> Student ID
        </div>
        <div className="h-px w-6 bg-line" />
        <div className={`flex items-center gap-1.5 ${step >= 2 ? "text-brass font-bold" : ""}`}>
          <span className="grid h-5 w-5 place-items-center rounded-full bg-brass/10 text-[11px]">2</span> Verification
        </div>
        <div className="h-px w-6 bg-line" />
        <div className={`flex items-center gap-1.5 ${step >= 3 ? "text-brass font-bold" : ""}`}>
          <span className="grid h-5 w-5 place-items-center rounded-full bg-brass/10 text-[11px]">3</span> Password
        </div>
      </div>

      {/* STEP 1: Enter Student ID */}
      {step === 1 && (
        <form action={actionStep1} className="space-y-4">
          <Field label="Official Student ID" hint="Issued by Study Hall College (e.g. SHC2504023)">
            <Input name="studentId" placeholder="e.g. SHC2504023" required autoFocus autoComplete="username" className="uppercase font-mono tracking-wide" />
          </Field>
          {stateStep1?.error && (
            <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2.5 text-sm text-danger font-medium">
              {stateStep1.error}
            </p>
          )}
          <Button type="submit" loading={pendingStep1} className="w-full">
            Verify Student ID
          </Button>
        </form>
      )}

      {/* STEP 2: Verify OTP + Resend */}
      {step === 2 && (
        <div className="space-y-4">
          <form action={actionStep2} className="space-y-4">
            <input type="hidden" name="studentId" value={studentId} />
            <div className="rounded-ctl bg-surface p-3.5 text-xs hairline">
              <p className="text-muted leading-relaxed">
                📲 Verification code sent via SMS to registered mobile: <strong className="text-ink">{maskedMobile}</strong>
              </p>
            </div>
            <Field label="6-Digit Verification Code" hint="Code expires in 5 minutes">
              <Input
                name="otp"
                type="text"
                maxLength={6}
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="123456"
                required
                autoFocus
                className="font-mono text-center tracking-widest text-lg"
              />
            </Field>
            {stateStep2?.error && (
              <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2.5 text-sm text-danger font-medium">
                {stateStep2.error}
              </p>
            )}
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => setStep(1)} className="w-1/3">
                Back
              </Button>
              <Button type="submit" loading={pendingStep2} className="w-2/3">
                Verify Code
              </Button>
            </div>
          </form>

          {/* Resend Code */}
          <form action={resendAction} className="pt-3 border-t border-line/60">
            <input type="hidden" name="studentId" value={studentId} />
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs text-muted">Didn&rsquo;t receive it?</span>
              <Button
                type="submit"
                variant="outline"
                size="sm"
                loading={pendingResend}
                disabled={resendDisabled}
                aria-label={resendLabel}
                aria-disabled={resendDisabled}
              >
                {resendLabel}
              </Button>
            </div>
            {resendMessage && (
              <p
                role={resendMessage.kind === "err" ? "alert" : "status"}
                aria-live="polite"
                className={`mt-2 rounded-ctl px-3 py-2 text-xs font-medium ${
                  resendMessage.kind === "ok"
                    ? "bg-ok/10 text-ok"
                    : "bg-danger/10 text-danger"
                }`}
              >
                {resendMessage.text}
              </p>
            )}
          </form>
        </div>
      )}

      {/* STEP 3: Set Password */}
      {step === 3 && (
        <form action={actionStep3} className="space-y-4">
          <input type="hidden" name="studentId" value={studentId} />
          <input type="hidden" name="otp" value={verifiedOtp} />

          <Field label="Create Password" hint="At least 6 characters" error={stateStep3?.fieldErrors?.password}>
            <PasswordInput name="password" required autoFocus autoComplete="new-password" placeholder="••••••••" />
          </Field>

          {stateStep3?.error && (
            <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2.5 text-sm text-danger font-medium">
              {stateStep3.error}
            </p>
          )}
          {stateStep3?.successMessage && (
            <p className="rounded-ctl bg-ok/10 px-3 py-2.5 text-sm text-ok font-medium">
              {stateStep3.successMessage}
            </p>
          )}

          <Button type="submit" loading={pendingStep3} className="w-full">
            Activate & Sign In
          </Button>
        </form>
      )}

      <p className="text-center text-sm text-muted pt-2 border-t border-line">
        Already activated?{" "}
        <Link href="/login" className="font-medium text-brass hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
