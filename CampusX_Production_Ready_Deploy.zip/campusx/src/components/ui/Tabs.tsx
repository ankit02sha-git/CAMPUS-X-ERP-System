"use client";

import React, { type ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface TabItem<T extends string = string> {
  id: T;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  count?: number;
}

interface AnimatedTabsProps<T extends string = string> {
  tabs: readonly TabItem<T>[] | TabItem<T>[];
  activeTab: T;
  onChange: (id: T) => void;
  className?: string;
  layoutId?: string;
}

/**
 * AnimatedTabs Component
 * High-end tab bar with sliding active pill indicator (Framer Motion layoutId)
 * and responsive horizontal scroll.
 */
export function AnimatedTabs<T extends string = string>({
  tabs,
  activeTab,
  onChange,
  className,
  layoutId = "active-tab-pill",
}: AnimatedTabsProps<T>) {
  return (
    <div
      role="tablist"
      className={cn("flex gap-1.5 overflow-x-auto pb-1 border-b border-line no-scrollbar", className)}
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;

        return (
          <button
            key={tab.id}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(tab.id)}
            className={cn(
              "group relative flex items-center gap-2 whitespace-nowrap rounded-ctl px-4 py-2 text-xs font-semibold transition-colors duration-fast select-none",
              isActive ? "text-navy dark:text-white font-bold" : "text-muted hover:text-ink"
            )}
          >
            {/* Sliding Pill Indicator */}
            {isActive && (
              <motion.span
                layoutId={layoutId}
                className="pointer-events-none absolute inset-0 rounded-ctl bg-surface dark:bg-raised shadow-card hairline"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            )}
            
            {/* Bottom active accent line */}
            {isActive && (
              <motion.span
                layoutId={`${layoutId}-line`}
                className="pointer-events-none absolute bottom-0 left-3 right-3 h-[2px] rounded-full bg-brass"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            )}

            {Icon && (
              <Icon
                className={cn(
                  "relative z-10 h-3.5 w-3.5 transition-transform duration-fast group-hover:scale-110",
                  isActive ? "text-brass" : "text-muted"
                )}
              />
            )}

            <span className="relative z-10">{tab.label}</span>

            {tab.count !== undefined && (
              <span
                className={cn(
                  "relative z-10 grid h-4 min-w-[16px] place-items-center rounded-full px-1 text-[10px] font-extrabold tabular-nums",
                  isActive ? "bg-brass text-white" : "bg-line/60 text-muted"
                )}
              >
                {tab.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
