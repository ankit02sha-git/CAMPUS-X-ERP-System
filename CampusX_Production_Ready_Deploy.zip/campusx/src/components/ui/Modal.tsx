"use client";

import React, { useEffect, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { customEaseCurve } from "@/components/ui/motion";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  maxWidthClass?: string;
}

/**
 * Reusable Floating 3D Modal System
 * Provides smooth backdrop blur overlay, 3D scale/depth entrance, escape key handler,
 * and lock body scroll.
 */
export function Modal({ open, onClose, title, children, maxWidthClass = "sm:max-w-lg" }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[70] grid place-items-end sm:place-items-center p-0 sm:p-4 perspective-1000">
          {/* Backdrop Blur Overlay */}
          <motion.div
            className="absolute inset-0 bg-black/50 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
          />

          {/* Floating 3D Modal Dialog */}
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className={`relative max-h-[92dvh] w-full overflow-y-auto rounded-t-2xl glass-modal p-6 shadow-lift sm:rounded-card ${maxWidthClass}`}
            initial={{ opacity: 0, scale: 0.94, y: 24, rotateX: 4 }}
            animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 16, rotateX: -2 }}
            transition={{ duration: 0.3, ease: customEaseCurve }}
            style={{ transformStyle: "preserve-3d" }}
          >
            <div className="mb-4 flex items-start justify-between gap-3 border-b border-line pb-3">
              <h2 className="text-xl font-semibold tracking-tight">{title}</h2>
              <button
                onClick={onClose}
                aria-label="Close dialog"
                className="rounded-ctl p-1.5 text-muted transition-colors hover:bg-line/50 hover:text-ink active:scale-95"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div>{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
