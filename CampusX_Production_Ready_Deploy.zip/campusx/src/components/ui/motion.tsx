"use client";

import React, { useEffect, useRef, useState, type ReactNode } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
  animate,
  AnimatePresence,
} from "framer-motion";

/**
 * Custom Cubic-Bezier easing curve for smooth, natural, luxury motion.
 * Matches Apple & high-end SaaS interaction standards.
 */
export const customEaseCurve = [0.22, 1, 0.36, 1] as const;

interface MotionWrapperProps {
  children: ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
}

/**
 * Reveal Component
 * Smoothly fades and slides elements into view as the user scrolls.
 * Respects user accessibility settings for reduced motion.
 */
export function Reveal({ children, delay = 0, className }: MotionWrapperProps) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.45, ease: customEaseCurve, delay }}
    >
      {children}
    </motion.div>
  );
}

/**
 * FadeIn Component
 * Simple opacity fade-in transition.
 */
export function FadeIn({ children, delay = 0, duration = 0.35, className }: MotionWrapperProps) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration, ease: customEaseCurve, delay }}
    >
      {children}
    </motion.div>
  );
}

/**
 * SlideUp Component
 * Vertical entrance animation with smooth opacity fade.
 */
export function SlideUp({ children, delay = 0, duration = 0.4, className }: MotionWrapperProps) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration, ease: customEaseCurve, delay }}
    >
      {children}
    </motion.div>
  );
}

/**
 * SlideDown Component
 * Top-down entrance animation.
 */
export function SlideDown({ children, delay = 0, duration = 0.4, className }: MotionWrapperProps) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, y: -18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration, ease: customEaseCurve, delay }}
    >
      {children}
    </motion.div>
  );
}

/**
 * ScaleIn Component
 * Subtle 3D depth scale-in transition (0.96 -> 1.00).
 */
export function ScaleIn({ children, delay = 0, duration = 0.35, className }: MotionWrapperProps) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration, ease: customEaseCurve, delay }}
    >
      {children}
    </motion.div>
  );
}

interface StaggerContainerProps {
  children: ReactNode;
  staggerDelay?: number;
  delay?: number;
  className?: string;
}

/**
 * StaggerContainer Component
 * Orchestrates child item entrances sequentially.
 */
export function StaggerContainer({
  children,
  staggerDelay = 0.05,
  delay = 0,
  className,
}: StaggerContainerProps) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : "hidden"}
      animate="show"
      exit="hidden"
      variants={{
        hidden: { opacity: 0 },
        show: {
          opacity: 1,
          transition: {
            staggerChildren: shouldReduceMotion ? 0 : staggerDelay,
            delayChildren: delay,
          },
        },
      }}
    >
      {children}
    </motion.div>
  );
}

/**
 * StaggerItem Component
 * Individual item wrapper inside a StaggerContainer.
 */
export function StaggerItem({ children, className }: { children: ReactNode; className?: string }) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      variants={{
        hidden: shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: 14, scale: 0.98 },
        show: {
          opacity: 1,
          y: 0,
          scale: 1,
          transition: { duration: 0.38, ease: customEaseCurve },
        },
      }}
    >
      {children}
    </motion.div>
  );
}

interface HoverLiftProps {
  children: ReactNode;
  className?: string;
  liftAmount?: number;
}

/**
 * HoverLift Component
 * Applies a refined 3D surface lift effect on desktop hover.
 */
export function HoverLift({ children, className, liftAmount = -4 }: HoverLiftProps) {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      className={className}
      whileHover={{ y: liftAmount, scale: 1.005 }}
      whileTap={{ scale: 0.985 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
    >
      {children}
    </motion.div>
  );
}

/**
 * ButtonPress Component
 * Micro-interaction wrapper providing tactile spring feedback on click/press.
 */
export function ButtonPress({ children, className }: { children: ReactNode; className?: string }) {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      className={className}
      whileHover={{ y: -1.5, scale: 1.015 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 450, damping: 25 }}
    >
      {children}
    </motion.div>
  );
}

/**
 * PageTransition Component
 * Wraps top-level page views with clean, fast route entry motion.
 */
export function PageTransition({ children, className }: { children: ReactNode; className?: string }) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, y: 10, scale: 0.995 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.32, ease: customEaseCurve }}
    >
      {children}
    </motion.div>
  );
}

/**
 * TabTransition Component
 * Animates content switching between tab panels.
 */
export function TabTransition({
  children,
  tabKey,
  className,
}: {
  children: ReactNode;
  tabKey: string;
  className?: string;
}) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={tabKey}
        className={className}
        initial={shouldReduceMotion ? false : { opacity: 0, y: 8, scale: 0.99 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -6, scale: 0.99 }}
        transition={{ duration: 0.24, ease: customEaseCurve }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

interface TiltProps {
  children: ReactNode;
  className?: string;
  max?: number;
}

/**
 * Tilt Component
 * Adds a subtle 3D tilt effect on mouse hover for desktop users.
 * Calculates normalized pointer coordinates (-0.5 to 0.5) to compute rotation angles.
 * Automatically disabled on touch devices and when reduced motion is preferred.
 */
export function Tilt({ children, className, max = 3.5 }: TiltProps) {
  const shouldReduceMotion = useReducedMotion();
  const pointerX = useMotionValue(0);
  const pointerY = useMotionValue(0);

  // Map pointer offsets (-0.5 to 0.5) to tilt angles (-max to max degrees)
  const rotateX = useSpring(useTransform(pointerY, [-0.5, 0.5], [max, -max]), { stiffness: 220, damping: 22 });
  const rotateY = useSpring(useTransform(pointerX, [-0.5, 0.5], [-max, max]), { stiffness: 220, damping: 22 });

  const containerRef = useRef<HTMLDivElement>(null);

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    // Only apply 3D tilt for precise mouse pointers (not mobile touch drag)
    if (e.pointerType !== "mouse" || !containerRef.current) return;

    const bounds = containerRef.current.getBoundingClientRect();
    const normalizedX = (e.clientX - bounds.left) / bounds.width - 0.5;
    const normalizedY = (e.clientY - bounds.top) / bounds.height - 0.5;

    pointerX.set(normalizedX);
    pointerY.set(normalizedY);
  };

  const handlePointerLeave = () => {
    // Reset tilt angles smoothly when the mouse leaves the component area
    pointerX.set(0);
    pointerY.set(0);
  };

  return (
    <div className="perspective-1000">
      <motion.div
        ref={containerRef}
        className={className}
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        whileHover={{ y: -4, scale: 1.008 }}
        whileTap={{ scale: 0.985 }}
        transition={{ duration: 0.25, ease: customEaseCurve }}
      >
        {children}
      </motion.div>
    </div>
  );
}

interface CounterProps {
  value: number;
  suffix?: string;
}

/**
 * Animated Number Counter
 * Smoothly counts up from 0 to the target number when rendered.
 * Renders target number instantly if reduced motion is enabled.
 */
export function Counter({ value, suffix = "" }: CounterProps) {
  const shouldReduceMotion = useReducedMotion();
  const [displayValue, setDisplayValue] = useState(shouldReduceMotion ? value : 0);

  useEffect(() => {
    if (shouldReduceMotion) {
      setDisplayValue(value);
      return;
    }

    const animationControls = animate(0, value, {
      duration: 1.1,
      ease: customEaseCurve,
      onUpdate: (latestValue) => setDisplayValue(Math.round(latestValue)),
    });

    return () => animationControls.stop();
  }, [value, shouldReduceMotion]);

  return (
    <>
      {displayValue}
      {suffix}
    </>
  );
}

interface ProgressBarProps {
  value: number;
}

/**
 * Animated Progress Bar Component
 * Renders an accessible progress bar with smooth width transition animation.
 */
export function ProgressBar({ value }: ProgressBarProps) {
  return (
    <div
      className="h-1.5 w-full overflow-hidden rounded-full bg-line"
      role="progressbar"
      aria-valuenow={value}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <motion.div
        className="h-full rounded-full bg-brass"
        initial={{ width: 0 }}
        animate={{ width: `${value}%` }}
        transition={{ duration: 0.9, ease: customEaseCurve }}
      />
    </div>
  );
}
