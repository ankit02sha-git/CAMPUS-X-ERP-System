"use client";

import React, { useRef, useState, type ReactNode } from "react";
import { motion, useMotionValue, useSpring, useTransform, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";
import { customEaseCurve } from "@/components/ui/motion";

export type GlassCardVariant = "standard" | "elevated" | "subtle" | "strong" | "primary" | "cyan" | "emerald" | "amber";

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  className?: string;
  variant?: GlassCardVariant;
  tilt?: boolean;
  reflection?: boolean;
  interactive?: boolean;
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  maxTilt?: number;
}

/**
 * GlassCard Component
 * Reusable Liquid Glass surface card with optional perspective mouse tilt,
 * color-tinted visual hierarchy variants, diagonal reflection sheen, and spring physics.
 */
export function GlassCard({
  children,
  className,
  variant = "standard",
  tilt = false,
  reflection = true,
  interactive = false,
  onClick,
  maxTilt = 3,
  ...restProps
}: GlassCardProps) {
  const shouldReduceMotion = useReducedMotion();
  const cardRef = useRef<HTMLDivElement>(null);
  const [, setIsHovered] = useState(false);

  const pointerX = useMotionValue(0);
  const pointerY = useMotionValue(0);

  const rotateX = useSpring(useTransform(pointerY, [-0.5, 0.5], [maxTilt, -maxTilt]), {
    stiffness: 240,
    damping: 24,
  });
  const rotateY = useSpring(useTransform(pointerX, [-0.5, 0.5], [-maxTilt, maxTilt]), {
    stiffness: 240,
    damping: 24,
  });

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!tilt || shouldReduceMotion || e.pointerType !== "mouse" || !cardRef.current) return;
    const bounds = cardRef.current.getBoundingClientRect();
    const normX = (e.clientX - bounds.left) / bounds.width - 0.5;
    const normY = (e.clientY - bounds.top) / bounds.height - 0.5;
    pointerX.set(normX);
    pointerY.set(normY);
  };

  const handlePointerLeave = () => {
    setIsHovered(false);
    pointerX.set(0);
    pointerY.set(0);
  };

  const handlePointerEnter = () => {
    setIsHovered(true);
  };

  const variantClasses: Record<GlassCardVariant, string> = {
    standard: "glass-card",
    elevated: "glass-panel",
    subtle: "bg-surface/60 backdrop-blur-md hairline shadow-sm",
    strong: "glass-modal",
    primary: "glass-card-primary",
    cyan: "glass-card-cyan",
    emerald: "glass-card-emerald",
    amber: "glass-card-amber",
  };

  return (
    <div className={cn(tilt && "perspective-1000")}>
      <motion.div
        ref={cardRef}
        onClick={onClick}
        onPointerMove={handlePointerMove}
        onPointerEnter={handlePointerEnter}
        onPointerLeave={handlePointerLeave}
        whileHover={
          interactive || onClick
            ? shouldReduceMotion
              ? undefined
              : { y: -3.5, scale: 1.008 }
            : undefined
        }
        whileTap={interactive || onClick ? { scale: 0.985 } : undefined}
        style={tilt && !shouldReduceMotion ? { rotateX, rotateY, transformStyle: "preserve-3d" } : undefined}
        transition={{ duration: 0.24, ease: customEaseCurve }}
        className={cn(
          "relative overflow-hidden rounded-card transition-all duration-fast select-none",
          variantClasses[variant],
          reflection && "glass-reflection",
          (interactive || onClick) && "cursor-pointer hover:border-brand/45 hover:shadow-lift",
          className
        )}
        {...(restProps as React.ComponentPropsWithoutRef<typeof motion.div>)}
      >
        {/* Subtle top inner reflection border */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent dark:via-white/12" />

        {children}
      </motion.div>
    </div>
  );
}
