"use client";

import React, {
  forwardRef,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";
import { customEaseCurve } from "@/components/ui/motion";

// ───────── Button Component ─────────
type ButtonVariant = "primary" | "ghost" | "outline" | "danger";
type ButtonSize = "sm" | "md";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
}

/**
 * Reusable Interactive Action Button
 * Supports primary brand blue, outline, ghost, and danger themes.
 * Equipped with tactile spring press feedback and smooth loading spinner.
 */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", loading, children, disabled, ...restProps }, ref) => (
    <motion.button
      ref={ref}
      disabled={disabled || loading}
      whileHover={disabled || loading ? undefined : { y: -1.5, scale: 1.015 }}
      whileTap={disabled || loading ? undefined : { scale: 0.97 }}
      transition={{ type: "spring", stiffness: 450, damping: 25 }}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-ctl font-medium transition-colors duration-fast disabled:opacity-50 disabled:pointer-events-none select-none",
        size === "sm" ? "h-8 px-3 text-[13px]" : "h-10 px-4 text-sm",
        variant === "primary" &&
          "bg-brand text-brand-fg shadow-[inset_0_1px_0_rgb(255_255_255/0.22),0_8px_16px_-8px_rgb(var(--brand)/0.7)] hover:bg-brand-dark",
        variant === "outline" &&
          "border border-brand/35 bg-surface text-brand hover:bg-brand/5 hover:border-brand/60 dark:text-ink shadow-sm",
        variant === "ghost" && "hover:bg-line/50 text-ink",
        variant === "danger" &&
          "bg-shcred text-white shadow-[0_8px_16px_-8px_rgb(var(--red)/0.7)] hover:brightness-110",
        className
      )}
      {...(restProps as React.ComponentPropsWithoutRef<typeof motion.button>)}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
      {children}
    </motion.button>
  )
);
Button.displayName = "Button";

// Shared base styles for text inputs, textareas, and select dropdowns
const commonInputStyles =
  "w-full rounded-ctl glass-input px-3 text-sm text-ink placeholder:text-muted/70 transition-all duration-fast focus-visible:outline-none";

/** Form Input Field */
export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...restProps }, ref) => (
    <input ref={ref} className={cn(commonInputStyles, "h-10", className)} {...restProps} />
  )
);
Input.displayName = "Input";

/** Password Input Field with Interactive Show/Hide Toggle */
export const PasswordInput = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...restProps }, ref) => {
    const [showPassword, setShowPassword] = useState(false);
    return (
      <div className="relative w-full">
        <input
          ref={ref}
          type={showPassword ? "text" : "password"}
          className={cn(commonInputStyles, "h-10 pr-10", className)}
          {...restProps}
        />
        <button
          type="button"
          onClick={() => setShowPassword((prev) => !prev)}
          className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-muted hover:text-ink focus:outline-none focus-visible:ring-2 focus-visible:ring-brand rounded-md transition-colors select-none"
          title={showPassword ? "Hide password" : "Show password"}
          aria-label={showPassword ? "Hide password" : "Show password"}
        >
          {showPassword ? <EyeOff className="h-4 w-4 text-muted hover:text-ink" /> : <Eye className="h-4 w-4 text-muted hover:text-ink" />}
        </button>
      </div>
    );
  }
);
PasswordInput.displayName = "PasswordInput";

/** Form Textarea Input */
export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...restProps }, ref) => (
    <textarea ref={ref} className={cn(commonInputStyles, "py-2.5 min-h-[96px] resize-y", className)} {...restProps} />
  )
);
Textarea.displayName = "Textarea";

/** Form Select Dropdown */
export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(
  ({ className, ...restProps }, ref) => (
    <select ref={ref} className={cn(commonInputStyles, "h-10", className)} {...restProps} />
  )
);
Select.displayName = "Select";

// ───────── Form Field Wrapper ─────────
interface FieldProps {
  label: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}

/**
 * Form Field Container
 * Wraps an input control with an accessible label, optional hint text, and animated error message reveal.
 */
export function Field({ label, error, hint, children }: FieldProps) {
  return (
    <label className="block space-y-1.5">
      <span className="text-[13px] font-medium text-ink">{label}</span>
      {children}
      {hint && !error && <span className="block text-xs text-muted">{hint}</span>}
      <AnimatePresence mode="wait">
        {error && (
          <motion.span
            role="alert"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.2, ease: customEaseCurve }}
            className="block text-xs text-danger font-medium"
          >
            {error}
          </motion.span>
        )}
      </AnimatePresence>
    </label>
  );
}

// ───────── Card Container ─────────
/**
 * Liquid Glass Card Container
 * Elevated translucent surface card used across dashboard widgets, event lists, and admin panels.
 */
export function Card({ className, children, ...restProps }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("glass-card glass-reflection transition-all duration-fast hover:shadow-lift", className)}
      {...restProps}
    >
      {/* Subtle top inner reflection border */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent dark:via-white/10" />
      {children}
    </div>
  );
}

// ───────── Badge Pill ─────────
const badgeToneStyles = {
  neutral: "bg-line/70 text-ink",
  brass: "bg-brass/12 text-brass border border-brass/25",
  yellow: "bg-shcyellow/25 text-ink border border-shcyellow/40",
  ok: "bg-ok/15 text-ok border border-ok/25",
  warn: "bg-warn/15 text-warn border border-warn/25",
  danger: "bg-danger/15 text-danger border border-danger/25",
} as const;

interface BadgeProps {
  tone?: keyof typeof badgeToneStyles;
  children: ReactNode;
  className?: string;
}

/** Small Status & Category Badge Pill */
export function Badge({ tone = "neutral", children, className }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold tracking-wide transition-all duration-fast",
        badgeToneStyles[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

// ───────── Skeleton Loader ─────────
/** Loading Skeleton Placeholder */
export const Skeleton = ({ className }: { className?: string }) => (
  <div className={cn("skeleton rounded-ctl", className)} aria-hidden />
);

// ───────── Empty State ─────────
interface EmptyStateProps {
  icon: ReactNode;
  title: string;
  body: string;
  action?: ReactNode;
}

/** Renders a friendly placeholder state when list items or search results are empty */
export function EmptyState({ icon, title, body, action }: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.35, ease: customEaseCurve }}
      className="relative overflow-hidden rounded-card border border-dashed border-line bg-surface/60 px-6 py-14 text-center"
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{ background: "radial-gradient(400px 160px at 50% 0%, rgb(var(--brass)/0.10), transparent)" }}
      />
      <div className="relative mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl hairline bg-raised text-brass shadow-card">
        {icon}
      </div>
      <h3 className="relative text-lg font-semibold">{title}</h3>
      <p className="relative mx-auto mt-1.5 max-w-sm text-sm text-muted">{body}</p>
      {action && <div className="relative mt-5">{action}</div>}
    </motion.div>
  );
}

// ───────── Page Header ─────────
interface PageHeaderProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}

/** Standard Header Section for all CampusX student and admin pages */
export function PageHeader({ eyebrow, title, subtitle, actions }: PageHeaderProps) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && <div className="eyebrow mb-1.5">{eyebrow}</div>}
        <h1 className="text-3xl font-semibold md:text-[34px] tracking-tight">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-muted">{subtitle}</p>}
      </div>
      {actions}
    </header>
  );
}
