"use client";
import { useTransition } from "react";
import { setAssignmentStatus } from "@/actions/student";
import { Button } from "@/components/ui";

const OPTS = [["PENDING", "Pending"], ["SUBMITTED", "Submitted"], ["COMPLETED", "Completed"]] as const;
export function AssignmentStatus({ id, status }: { id: string; status: "PENDING" | "SUBMITTED" | "COMPLETED" }) {
  const [pending, start] = useTransition();
  return (
    <div className="flex items-center gap-2" role="group" aria-label="Set status">
      <span className="text-xs text-muted">My status:</span>
      {OPTS.map(([v, l]) => <Button key={v} size="sm" variant={status === v ? "primary" : "outline"} disabled={pending} aria-pressed={status === v} onClick={() => start(() => setAssignmentStatus(id, v))}>{l}</Button>)}
    </div>
  );
}
