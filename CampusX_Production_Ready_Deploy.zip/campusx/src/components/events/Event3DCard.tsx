"use client";

import React, { useState, useRef, useEffect } from "react";
import { Calendar, MapPin, Sparkles, CheckCircle2, Clock, ArrowRight, UserCheck } from "lucide-react";
import type { Event } from "@/server/db/schema";

interface Event3DCardProps {
  event: Event & { isRegistered?: boolean; registrationCount?: number };
  onSelect: (event: Event) => void;
  featured?: boolean;
}

/**
 * Event 3D Card Component
 * Displays individual campus events with subtle 3D tilt interaction on hover.
 * Reads accessibility motion preferences to disable tilt for users who prefer reduced motion.
 */
export function Event3DCard({ event, onSelect, featured = false }: Event3DCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [transformStyle, setTransformStyle] = useState("none");
  const [isHovered, setIsHovered] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Listen for user OS accessibility setting (prefers-reduced-motion)
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);

    const handleMotionPreferenceChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };

    mediaQuery.addEventListener("change", handleMotionPreferenceChange);
    return () => mediaQuery.removeEventListener("change", handleMotionPreferenceChange);
  }, []);

  /**
   * Calculates 3D tilt rotation angles based on cursor offset from card center.
   * Max rotation is capped at 6 degrees for subtle, readable interaction.
   */
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion || !cardRef.current) return;

    const bounds = cardRef.current.getBoundingClientRect();
    const cursorX = e.clientX - bounds.left;
    const cursorY = e.clientY - bounds.top;
    const centerX = bounds.width / 2;
    const centerY = bounds.height / 2;

    const rotateX = ((cursorY - centerY) / centerY) * -6; // Tilt up/down
    const rotateY = ((cursorX - centerX) / centerX) * 6; // Tilt left/right

    setTransformStyle(
      `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`
    );
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    // Reset card transform smoothly back to flat state when mouse exits
    setTransformStyle("perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)");
  };

  /**
   * Formats the event date depending on date precision (exact date, month only, or TBD)
   */
  const formatDateDisplay = () => {
    if (event.datePrecision === "TBD" || !event.date) {
      return "Date TBD";
    }

    const eventDate = new Date(event.startDate || event.date);
    if (isNaN(eventDate.getTime())) return event.date;

    if (event.datePrecision === "MONTH_ONLY") {
      return eventDate.toLocaleDateString("en-IN", { month: "long", year: "numeric" });
    }

    if (event.datePrecision === "DATE_RANGE" && event.endDate) {
      const endDate = new Date(event.endDate);
      return `${eventDate.toLocaleDateString("en-IN", { day: "numeric", month: "short" })} – ${endDate.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}`;
    }

    return eventDate.toLocaleDateString("en-IN", {
      weekday: "short",
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  // Color mapping for different event categories
  const categoryBadgeColors: Record<string, string> = {
    CULTURAL:
      "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800",
    ACADEMIC:
      "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800",
    SPORTS:
      "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800",
    WORKSHOP:
      "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800",
    COMPETITION:
      "bg-rose-100 text-rose-800 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800",
    CELEBRATION:
      "bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800",
    TBD: "bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700",
  };

  const categoryStyle =
    categoryBadgeColors[event.category?.toUpperCase() || ""] || "bg-blue-50 text-blue-700 border-blue-200";

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={() => onSelect(event)}
      style={{
        transform: transformStyle,
        transition: isHovered
          ? "transform 0.1s ease-out, box-shadow 0.2s ease"
          : "transform 0.4s ease-out, box-shadow 0.3s ease",
        transformStyle: "preserve-3d",
      }}
      className={`group relative cursor-pointer overflow-hidden rounded-2xl border bg-white p-5 shadow-sm transition-all dark:bg-slate-900 ${
        featured
          ? "border-blue-300 bg-gradient-to-br from-blue-50/50 via-white to-indigo-50/30 shadow-md ring-2 ring-blue-500/20 dark:from-slate-900 dark:via-slate-900 dark:to-blue-950/30 dark:border-blue-700"
          : "border-slate-200 hover:border-blue-400 hover:shadow-lg dark:border-slate-800 dark:hover:border-blue-600"
      }`}
    >
      {/* Category Pill and Badges */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider ${categoryStyle}`}
          >
            {event.category || "General"}
          </span>

          {/* Special badge for canonical AAGAT Freshers event */}
          {event.title.toUpperCase() === "AAGAT" && (
            <span className="inline-flex items-center gap-1 rounded-md border border-purple-300 bg-purple-50 px-2 py-0.5 text-xs font-semibold text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-700">
              Freshers Welcome
            </span>
          )}

          {/* Spotlight banner badge */}
          {event.featured && (
            <span className="inline-flex items-center gap-1 rounded-md border border-amber-300 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-700">
              <Sparkles className="h-3 w-3 text-amber-600 dark:text-amber-400" /> Spotlight
            </span>
          )}
        </div>

        {/* Verification Source Indicator */}
        {event.sourceType === "OFFICIAL_WEBSITE" && (
          <span
            title="Verified from Official Study Hall College Website"
            className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 dark:text-emerald-400"
          >
            <CheckCircle2 className="h-3.5 w-3.5" /> Official
          </span>
        )}
        {event.sourceType === "USER_SUPPLIED" && (
          <span
            title="From Campus Planning Schedule"
            className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 dark:text-slate-400"
          >
            <Clock className="h-3.5 w-3.5" /> Campus Plan
          </span>
        )}
      </div>

      {/* Date Header Badge */}
      <div className="mb-3 flex items-start gap-3">
        <div className="flex flex-col items-center justify-center rounded-xl bg-blue-600 px-3 py-2 text-white shadow-sm shrink-0 min-w-[58px]">
          <span className="text-[10px] font-bold uppercase tracking-widest text-blue-100">
            {event.datePrecision === "TBD"
              ? "TBD"
              : new Date(event.startDate || event.date).toLocaleDateString("en-IN", { month: "short" })}
          </span>
          <span className="text-xl font-extrabold leading-none">
            {event.datePrecision === "TBD" ? "?" : new Date(event.startDate || event.date).getDate()}
          </span>
        </div>

        <div className="min-w-0 flex-1">
          <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 dark:text-white dark:group-hover:text-blue-400 transition-colors line-clamp-2 leading-snug">
            {event.title}
          </h3>
          <p className="mt-1 flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-300">
            <Calendar className="h-3.5 w-3.5 text-blue-500 shrink-0" />
            <span className="truncate">{formatDateDisplay()}</span>
          </p>
        </div>
      </div>

      {/* Short Summary Description */}
      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
        {event.shortDescription || event.description || "Join us for this event at Study Hall College."}
      </p>

      {/* Card Footer: Venue & Registration Status */}
      <div className="mt-auto flex items-center justify-between border-t border-slate-100 pt-3 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 truncate max-w-[65%]">
          <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
          <span className="truncate">{event.venue || event.location || "Study Hall Campus"}</span>
        </div>

        <div className="flex items-center gap-2">
          {event.isRegistered && (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
              <UserCheck className="h-3 w-3" /> Registered
            </span>
          )}
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 group-hover:translate-x-0.5 transition-transform dark:text-blue-400">
            Details <ArrowRight className="h-3.5 w-3.5" />
          </span>
        </div>
      </div>
    </div>
  );
}
