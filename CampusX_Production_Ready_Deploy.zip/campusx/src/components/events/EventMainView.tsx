"use client";

import React, { useState, useMemo } from "react";
import { Search, Calendar, LayoutGrid, ListTree, Sparkles, Filter, CheckCircle2, Clock, ShieldCheck, MapPin, ArrowRight } from "lucide-react";
import type { Event } from "@/server/db/schema";
import { Event3DCard } from "./Event3DCard";
import { EventTimelineView } from "./EventTimelineView";
import { EventCalendarView } from "./EventCalendarView";
import { EventDetailModal } from "./EventDetailModal";

interface EventMainViewProps {
  initialEvents: Event[];
  userRegistrations?: string[]; // IDs of events user registered for
}

export function EventMainView({ initialEvents, userRegistrations = [] }: EventMainViewProps) {
  const [events, setEvents] = useState(initialEvents);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("ALL");
  const [activeTab, setActiveTab] = useState<"GRID" | "TIMELINE" | "CALENDAR" | "UPCOMING" | "PAST" | "TBD">("GRID");
  const [activeEvent, setActiveEvent] = useState<Event | null>(null);

  const registeredSet = useMemo(() => new Set(userRegistrations), [userRegistrations]);

  // Spotlight / Featured Event (AAGAT prioritized as main campus highlight)
  const spotlightEvent = useMemo(() => {
    return (
      events.find((e) => e.title.toUpperCase() === "AAGAT") ||
      events.find((e) => e.featured && e.published && (e.startDate || e.date) >= "2026-10-01") ||
      events.find((e) => e.published && e.eventStatus === "UPCOMING") ||
      events[0]
    );
  }, [events]);

  const categories = ["ALL", "CULTURAL", "ACADEMIC", "SPORTS", "WORKSHOP", "COMPETITION", "CELEBRATION"];

  // Filtered Events
  const filteredEvents = useMemo(() => {
    const searchLower = searchQuery.toLowerCase().trim();
    return events.filter((ev) => {
      // Search with alias support (e.g. searching 'freshers' or 'aagat' matches AAGAT)
      const matchesSearch =
        !searchLower ||
        ev.title.toLowerCase().includes(searchLower) ||
        (ev.shortDescription || "").toLowerCase().includes(searchLower) ||
        (ev.description || "").toLowerCase().includes(searchLower) ||
        (ev.venue || ev.location || "").toLowerCase().includes(searchLower) ||
        ((searchLower.includes("fresher") || searchLower.includes("welcome") || searchLower.includes("aagat")) &&
          ev.title.toUpperCase() === "AAGAT");

      // Category
      const matchesCategory = selectedCategory === "ALL" || ev.category?.toUpperCase() === selectedCategory;

      // View Tab Filtering
      let matchesTab = true;
      if (activeTab === "UPCOMING") {
        matchesTab = ev.eventStatus === "UPCOMING" || (!!ev.date && ev.date >= "2026-09-01");
      } else if (activeTab === "PAST") {
        matchesTab = ev.eventStatus === "COMPLETED" || (!!ev.date && ev.date < "2026-09-01");
      } else if (activeTab === "TBD") {
        matchesTab = ev.datePrecision === "TBD" || ev.eventStatus === "TBD" || !ev.date;
      }

      return matchesSearch && matchesCategory && matchesTab;
    });
  }, [events, searchQuery, selectedCategory, activeTab]);

  return (
    <div className="space-y-8">
      {/* 1. HERO SPOTLIGHT BANNER */}
      {spotlightEvent && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-900 via-slate-900 to-indigo-950 p-6 sm:p-8 text-white shadow-xl ring-1 ring-white/10">
          <div className="absolute right-0 top-0 -mt-12 -mr-12 h-64 w-64 rounded-full bg-blue-500/20 blur-3xl pointer-events-none" />

          <div className="grid gap-6 lg:grid-cols-12 lg:items-center">
            <div className="space-y-4 lg:col-span-7">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-500/30 px-3 py-1 text-xs font-bold uppercase tracking-wider text-blue-200 border border-blue-400/30 backdrop-blur-md">
                  <Sparkles className="h-3.5 w-3.5 text-blue-300" /> Featured Campus Highlight
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-semibold text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Verified Schedule
                </span>
              </div>

              <h1 className="text-3xl font-black leading-tight sm:text-4xl lg:text-5xl tracking-tight">
                {spotlightEvent.title}
              </h1>

              <p className="text-sm sm:text-base text-blue-100/90 max-w-xl leading-relaxed">
                {spotlightEvent.shortDescription || spotlightEvent.description || "Join us for Study Hall College's premier campus celebration."}
              </p>

              <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-blue-200 pt-2">
                <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl backdrop-blur-md">
                  <Calendar className="h-4 w-4 text-blue-300" />
                  <span>
                    {spotlightEvent.startDate
                      ? new Date(spotlightEvent.startDate).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "long", year: "numeric" })
                      : spotlightEvent.date}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl backdrop-blur-md">
                  <MapPin className="h-4 w-4 text-blue-300" />
                  <span>{spotlightEvent.venue || spotlightEvent.location || "Study Hall Campus"}</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setActiveEvent(spotlightEvent)}
                  className="inline-flex items-center gap-2 rounded-xl bg-blue-500 px-6 py-3 text-xs font-bold text-white shadow-lg hover:bg-blue-400 transition-all transform hover:-translate-y-0.5"
                >
                  View Event & Register <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Spotlight 3D Preview Card */}
            <div className="lg:col-span-5">
              <Event3DCard
                event={{ ...spotlightEvent, isRegistered: registeredSet.has(spotlightEvent.id) }}
                onSelect={setActiveEvent}
                featured
              />
            </div>
          </div>
        </div>
      )}

      {/* 2. FILTER & TOOLBAR */}
      <div className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search events by title, venue..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white pl-10 pr-4 py-2.5 text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 dark:border-slate-800 dark:bg-slate-900 dark:text-white dark:placeholder:text-slate-500"
            />
          </div>

          {/* View Tab Buttons */}
          <div className="flex flex-wrap items-center gap-1 rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
            {(
              [
                ["GRID", "Cards Grid", LayoutGrid],
                ["TIMELINE", "Timeline", ListTree],
                ["CALENDAR", "Calendar", Calendar],
                ["UPCOMING", "Upcoming"],
                ["PAST", "Past"],
                ["TBD", "Flexible / TBD"],
              ] as const
            ).map(([key, label, Icon]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as any)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                  activeTab === key
                    ? "bg-white text-blue-600 shadow-sm dark:bg-slate-900 dark:text-blue-400"
                    : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
                }`}
              >
                {Icon && <Icon className="h-3.5 w-3.5" />}
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Filter className="h-3 w-3" /> Category:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-full px-3 py-1 text-xs font-bold transition-all shrink-0 ${
                selectedCategory === cat
                  ? "bg-blue-600 text-white shadow-sm"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 3. EVENT CONTENT VIEWS */}
      {filteredEvents.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-200 p-12 text-center dark:border-slate-800">
          <Calendar className="mx-auto h-10 w-10 text-slate-400 mb-3" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">No events found</h3>
          <p className="mt-1 text-xs text-slate-500">Try adjusting your search query or category filter.</p>
        </div>
      ) : activeTab === "TIMELINE" ? (
        <EventTimelineView events={filteredEvents} onSelectEvent={setActiveEvent} />
      ) : activeTab === "CALENDAR" ? (
        <EventCalendarView events={filteredEvents} onSelectEvent={setActiveEvent} />
      ) : (
        /* GRID VIEW (GRID, UPCOMING, PAST, TBD) */
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredEvents.map((ev) => (
            <Event3DCard
              key={ev.id}
              event={{ ...ev, isRegistered: registeredSet.has(ev.id) }}
              onSelect={setActiveEvent}
            />
          ))}
        </div>
      )}

      {/* 4. DETAIL MODAL */}
      <EventDetailModal
        event={activeEvent ? { ...activeEvent, isRegistered: registeredSet.has(activeEvent.id) } : null}
        onClose={() => setActiveEvent(null)}
      />
    </div>
  );
}
