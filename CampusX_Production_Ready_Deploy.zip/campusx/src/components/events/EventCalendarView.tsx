"use client";

import React, { useState } from "react";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, MapPin } from "lucide-react";
import type { Event } from "@/server/db/schema";

interface EventCalendarViewProps {
  events: Event[];
  onSelectEvent: (event: Event) => void;
}

export function EventCalendarView({ events, onSelectEvent }: EventCalendarViewProps) {
  // Current view date (default to Oct 2026 where key mandatory events sit, or current date)
  const [currentDate, setCurrentDate] = useState(() => {
    // Check if there are events in Oct 2026
    const oct2026Event = events.find((e) => (e.startDate || e.date || "").startsWith("2026-10"));
    if (oct2026Event) return new Date(2026, 9, 1);
    return new Date();
  });

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const todayMonth = () => setCurrentDate(new Date(2026, 9, 1)); // Default to Oct 2026 peak semester

  const firstDayOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Monday-first offset (0 for Mon, 6 for Sun)
  const startingDayOffset = (firstDayOfMonth.getDay() + 6) % 7;

  // Map events by day number
  const eventsByDay: Record<number, Event[]> = {};
  events.forEach((ev) => {
    const dStr = ev.startDate || ev.date;
    if (dStr && /^\d{4}-\d{2}-\d{2}$/.test(dStr)) {
      const evD = new Date(dStr);
      if (evD.getFullYear() === year && evD.getMonth() === month) {
        const dayNum = evD.getDate();
        if (!eventsByDay[dayNum]) eventsByDay[dayNum] = [];
        eventsByDay[dayNum].push(ev);
      }
    }
  });

  const monthName = currentDate.toLocaleDateString("en-IN", { month: "long", year: "numeric" });
  const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      {/* Calendar Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-2">
          <CalendarIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">{monthName}</h2>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={todayMonth}
            className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-colors"
          >
            Oct 2026 Peak
          </button>
          <button
            onClick={prevMonth}
            aria-label="Previous Month"
            className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={nextMonth}
            aria-label="Next Month"
            className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Weekday Labels */}
      <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
        {weekDays.map((d) => (
          <div key={d} className="py-1">
            {d}
          </div>
        ))}
      </div>

      {/* Days Grid */}
      <div className="grid grid-cols-7 gap-1">
        {/* Offset empty slots */}
        {Array.from({ length: startingDayOffset }).map((_, i) => (
          <div key={`offset-${i}`} className="min-h-[90px] rounded-xl bg-slate-50/50 dark:bg-slate-950/20" />
        ))}

        {/* Month Days */}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const dayNum = i + 1;
          const dayEvents = eventsByDay[dayNum] || [];

          return (
            <div
              key={`day-${dayNum}`}
              className="min-h-[90px] sm:min-h-[110px] rounded-xl border border-slate-100 bg-slate-50/70 p-2 dark:border-slate-800 dark:bg-slate-800/40 flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{dayNum}</span>
                {dayEvents.length > 0 && (
                  <span className="rounded-full bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                    {dayEvents.length}
                  </span>
                )}
              </div>

              {/* Event Chips */}
              <div className="space-y-1 overflow-y-auto max-h-[70px]">
                {dayEvents.map((ev) => (
                  <button
                    key={ev.id}
                    onClick={() => onSelectEvent(ev)}
                    className="w-full text-left truncate rounded-md bg-blue-600 px-1.5 py-1 text-[11px] font-medium text-white shadow-xs hover:bg-blue-700 transition-colors"
                  >
                    {ev.title}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
