"use client";

import React, { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, Calendar, MapPin, Clock, ExternalLink, Download, CheckCircle2, UserCheck, Loader2, Sparkles } from "lucide-react";
import type { Event } from "@/server/db/schema";
import { registerForEventAction, unregisterForEventAction } from "@/actions/events";
import { customEaseCurve } from "@/components/ui/motion";

interface EventDetailModalProps {
  event: (Event & { isRegistered?: boolean; registrationCount?: number }) | null;
  onClose: () => void;
  onStatusChange?: () => void;
}

export function EventDetailModal({ event, onClose, onStatusChange }: EventDetailModalProps) {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [registered, setRegistered] = useState(event?.isRegistered ?? false);
  const [regCount, setRegCount] = useState(event?.registrationCount ?? 0);

  useEffect(() => {
    if (!event) return;
    const handleKeyDown = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [event, onClose]);

  if (!event) return null;

  const handleRegisterToggle = async () => {
    setLoading(true);
    setMsg(null);
    try {
      if (registered) {
        const res = await unregisterForEventAction(event.id);
        if (res.success) {
          setRegistered(false);
          setRegCount((c) => Math.max(0, c - 1));
          setMsg({ type: "success", text: "Registration cancelled." });
          onStatusChange?.();
        } else {
          setMsg({ type: "error", text: res.error || "Failed to cancel registration." });
        }
      } else {
        const res = await registerForEventAction(event.id);
        if (res.success) {
          setRegistered(true);
          setRegCount((c) => c + 1);
          setMsg({ type: "success", text: "Successfully registered for this event!" });
          onStatusChange?.();
        } else {
          setMsg({ type: "error", text: res.error || "Failed to register." });
        }
      }
    } catch (e: any) {
      setMsg({ type: "error", text: "An error occurred." });
    } finally {
      setLoading(false);
    }
  };

  // Generate .ics calendar download
  const downloadIcsFile = () => {
    const title = event.title.replace(/\n/g, " ");
    const desc = (event.description || event.shortDescription || "").replace(/\n/g, "\\n");
    const loc = (event.venue || event.location || "Study Hall College, Lucknow").replace(/\n/g, " ");
    
    // Format date string for iCal (YYYYMMDDTHHMMSS)
    let startDateStr = "";
    let endDateStr = "";

    const dStr = event.startDate || event.date;
    if (dStr && /^\d{4}-\d{2}-\d{2}$/.test(dStr)) {
      const cleanDate = dStr.replace(/-/g, "");
      startDateStr = `${cleanDate}T090000`;
      endDateStr = `${cleanDate}T170000`;
    } else {
      const now = new Date().toISOString().replace(/[-:]/g, "").slice(0, 15);
      startDateStr = now;
      endDateStr = now;
    }

    const icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Study Hall College//CampusX Events//EN",
      "CALSCALE:GREGORIAN",
      "BEGIN:VEVENT",
      `SUMMARY:${title}`,
      `DESCRIPTION:${desc}`,
      `LOCATION:${loc}`,
      `DTSTART:${startDateStr}`,
      `DTEND:${endDateStr}`,
      `STATUS:CONFIRMED`,
      "END:VEVENT",
      "END:VCALENDAR",
    ].join("\r\n");

    const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${event.slug || "event"}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const formatDateLabel = () => {
    if (event.datePrecision === "TBD" || !event.date) return "Date to be announced";
    const d = new Date(event.startDate || event.date);
    if (isNaN(d.getTime())) return event.date;

    if (event.datePrecision === "MONTH_ONLY") {
      return `${d.toLocaleDateString("en-IN", { month: "long", year: "numeric" })} (Exact date TBD)`;
    }
    if (event.datePrecision === "DATE_RANGE" && event.endDate) {
      const endD = new Date(event.endDate);
      return `${d.toLocaleDateString("en-IN", { day: "numeric", month: "long" })} – ${endD.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}`;
    }
    return d.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  };

  return (
    <AnimatePresence>
      {event && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 perspective-1000">
          <motion.div
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={event.title}
            className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 max-h-[90vh] flex flex-col"
            initial={{ opacity: 0, scale: 0.94, y: 24, rotateX: 4 }}
            animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 16, rotateX: -2 }}
            transition={{ duration: 0.3, ease: customEaseCurve }}
            style={{ transformStyle: "preserve-3d" }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header Banner */}
            <div className="relative bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 p-6 text-white dark:from-blue-900 dark:via-slate-900 dark:to-indigo-950 shrink-0">
              <button
                onClick={onClose}
                aria-label="Close modal"
                className="absolute right-4 top-4 rounded-full bg-white/20 p-2 text-white hover:bg-white/30 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-bold uppercase tracking-wider text-white backdrop-blur-md">
                  {event.category || "General"}
                </span>
                {event.title.toUpperCase() === "AAGAT" && (
                  <span className="rounded-full bg-purple-500/30 px-3 py-1 text-xs font-bold text-purple-200 border border-purple-400/30 backdrop-blur-md">
                    Cultural Welcome • Freshers
                  </span>
                )}
                {event.featured && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/30 px-3 py-1 text-xs font-bold text-amber-200 backdrop-blur-md">
                    <Sparkles className="h-3.5 w-3.5" /> Featured Spotlight
                  </span>
                )}
              </div>

              <h2 className="text-2xl font-black leading-tight tracking-tight sm:text-3xl">
                {event.title}
              </h2>

              <div className="mt-4 flex flex-wrap gap-y-2 gap-x-4 text-xs font-medium text-blue-100">
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4 text-blue-200" />
                  <span>{formatDateLabel()}</span>
                </div>
                {(event.startTime || event.endTime) && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4 text-blue-200" />
                    <span>
                      {event.startTime ? event.startTime : ""} {event.endTime ? `– ${event.endTime}` : ""}
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-blue-200" />
                  <span>{event.venue || event.location || "Study Hall College Main Campus"}</span>
                </div>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {msg && (
                <div
                  className={`rounded-xl p-3 text-xs font-semibold ${
                    msg.type === "success" ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300" : "bg-rose-50 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300"
                  }`}
                >
                  {msg.text}
                </div>
              )}

              {/* Description */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">About This Event</h4>
                <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-line">
                  {event.description || event.shortDescription || "No detailed description has been provided for this campus event."}
                </p>
              </div>

              {/* Source Attribution & Verifications */}
              <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/50 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Data Verification Source</span>
                  {event.sourceType === "OFFICIAL_WEBSITE" ? (
                    <span className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="h-4 w-4" /> Official Website Verified
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 font-bold text-blue-600 dark:text-blue-400">
                      <Clock className="h-4 w-4" /> Campus Planning Calendar 2026
                    </span>
                  )}
                </div>

                {event.sourceUrl && (
                  <a
                    href={event.sourceUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-medium text-blue-600 hover:underline dark:text-blue-400"
                  >
                    View on Study Hall College Portal <ExternalLink className="h-3 w-3" />
                  </a>
                )}
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900 shrink-0">
              <button
                onClick={downloadIcsFile}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors shadow-sm"
              >
                <Download className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Add to iCal / Google Calendar (.ics)
              </button>

              {event.registrationEnabled ? (
                <button
                  onClick={handleRegisterToggle}
                  disabled={loading}
                  className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold shadow-md transition-all ${
                    registered
                      ? "bg-slate-200 text-slate-800 hover:bg-rose-100 hover:text-rose-800 dark:bg-slate-700 dark:text-white dark:hover:bg-rose-950 dark:hover:text-rose-300"
                      : "bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500"
                  }`}
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : registered ? (
                    <>
                      <UserCheck className="h-4 w-4 text-emerald-600 dark:text-emerald-400" /> Registered (Click to Cancel)
                    </>
                  ) : (
                    "Register for Event"
                  )}
                </button>
              ) : (
                <span className="text-xs font-medium text-slate-500 dark:text-slate-400 italic">
                  No registration required (Open Entry)
                </span>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
