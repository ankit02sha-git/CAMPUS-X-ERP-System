"use client";

import React from "react";
import { Calendar, MapPin, Sparkles, Clock, CheckCircle2 } from "lucide-react";
import type { Event } from "@/server/db/schema";
import { Event3DCard } from "./Event3DCard";

interface EventTimelineViewProps {
  events: Event[];
  onSelectEvent: (event: Event) => void;
}

export function EventTimelineView({ events, onSelectEvent }: EventTimelineViewProps) {
  if (events.length === 0) {
    return (
      <div className="py-12 text-center text-slate-500">
        No timeline events found matching your criteria.
      </div>
    );
  }

  // Group events by Month & Year
  const groups: { monthYear: string; items: Event[] }[] = [];
  events.forEach((ev) => {
    let monthYear = "Flexible / TBD";
    if (ev.startDate || ev.date) {
      const d = new Date(ev.startDate || ev.date);
      if (!isNaN(d.getTime())) {
        monthYear = d.toLocaleDateString("en-IN", { month: "long", year: "numeric" });
      }
    }
    const existingGroup = groups.find((g) => g.monthYear === monthYear);
    if (existingGroup) {
      existingGroup.items.push(ev);
    } else {
      groups.push({ monthYear, items: [ev] });
    }
  });

  return (
    <div className="relative border-l-2 border-blue-500/30 pl-6 sm:pl-8 ml-3 sm:ml-4 space-y-10 my-6">
      {groups.map((group, groupIdx) => (
        <div key={group.monthYear} className="relative">
          {/* Month Marker Node */}
          <div className="absolute -left-[31px] sm:-left-[39px] top-0 flex items-center justify-center">
            <div className="h-6 w-6 sm:h-7 sm:w-7 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md ring-4 ring-white dark:ring-slate-950">
              <Calendar className="h-3.5 w-3.5" />
            </div>
          </div>

          <div className="mb-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {group.monthYear}
            </h3>
            <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
              {group.items.length} {group.items.length === 1 ? "Event" : "Events"}
            </span>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {group.items.map((ev) => (
              <Event3DCard key={ev.id} event={ev} onSelect={onSelectEvent} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
