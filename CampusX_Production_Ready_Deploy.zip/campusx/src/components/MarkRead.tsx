"use client";
import { useTransition } from "react";
import { markAnnouncementRead } from "@/actions/student";
import { Button } from "@/components/ui";
export function MarkRead({ id }: { id: string }) {
  const [p, s] = useTransition();
  return <Button size="sm" variant="outline" loading={p} onClick={() => s(() => markAnnouncementRead(id))}>Mark as read</Button>;
}
