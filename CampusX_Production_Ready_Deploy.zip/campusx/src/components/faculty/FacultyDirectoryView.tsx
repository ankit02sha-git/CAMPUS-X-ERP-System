"use client";

import React, { useState } from "react";
import { FacultyDirectory } from "@/server/db/schema";
import { Users, Mail, Building, BookOpen, GraduationCap, Search } from "lucide-react";
import { cn } from "@/lib/utils";

interface FacultyDirectoryViewProps {
  facultyList: FacultyDirectory[];
}

export function FacultyDirectoryView({ facultyList }: FacultyDirectoryViewProps) {
  const [search, setSearch] = useState("");
  const [selectedDept, setSelectedDept] = useState("ALL");

  const departments = Array.from(new Set(facultyList.map((f) => f.department)));

  const filteredFaculty = facultyList.filter((f) => {
    if (selectedDept !== "ALL" && f.department !== selectedDept) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const mName = f.name.toLowerCase().includes(q);
      const mSub = f.subjectsTaught?.toLowerCase().includes(q);
      if (!mName && !mSub) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-card glass p-6 hairline shadow-sm">
        <div>
          <h1 className="text-xl font-extrabold text-ink sm:text-2xl flex items-center gap-2">
            <Users className="h-6 w-6 text-brand" /> Study Hall College Faculty Directory
          </h1>
          <p className="text-xs text-muted">
            Official academic faculty profiles, department leadership, qualifications, and office locations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="rounded-ctl glass-input px-3.5 py-2 text-xs font-semibold text-ink"
          >
            <option value="ALL">All Departments</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-3 h-4 w-4 text-muted" />
        <input
          type="text"
          placeholder="Search faculty by name or subject taught..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-ctl glass-input pl-10 pr-4 py-2.5 text-xs text-ink placeholder:text-muted"
        />
      </div>

      {/* Faculty Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFaculty.length === 0 ? (
          <div className="col-span-2 rounded-card glass p-8 text-center text-muted hairline">
            No faculty members found matching your search.
          </div>
        ) : (
          filteredFaculty.map((fac) => (
            <div key={fac.id} className="rounded-card glass p-5 hairline shadow-sm space-y-3 hover:shadow-md transition-all">
              <div className="flex items-start gap-3.5">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-brand/10 text-brand font-bold text-lg border border-brand/30">
                  {fac.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                </div>

                <div className="min-w-0 flex-1">
                  <span className="rounded-full bg-surface border border-line px-2 py-0.5 text-[10px] font-bold text-muted uppercase">
                    {fac.department}
                  </span>
                  <h3 className="font-bold text-sm sm:text-base text-ink mt-0.5">{fac.name}</h3>
                  <p className="text-xs font-semibold text-brand dark:text-sky-300">{fac.designation}</p>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-muted border-t border-line/60 pt-3">
                {fac.qualification && (
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-3.5 w-3.5 text-brand shrink-0" />
                    <span>{fac.qualification}</span>
                  </div>
                )}

                {fac.subjectsTaught && (
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-3.5 w-3.5 text-brand shrink-0" />
                    <span><strong>Subjects:</strong> {fac.subjectsTaught}</span>
                  </div>
                )}

                {fac.officeRoom && (
                  <div className="flex items-center gap-2">
                    <Building className="h-3.5 w-3.5 text-brand shrink-0" />
                    <span>{fac.officeRoom}</span>
                  </div>
                )}

                {fac.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="h-3.5 w-3.5 text-brand shrink-0" />
                    <span className="font-mono text-[11px]">{fac.email}</span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
