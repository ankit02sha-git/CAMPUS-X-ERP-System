"use client";
import { useActionState } from "react";
import { updateProfile } from "@/actions/student";
import type { FormState } from "@/actions/auth";
import { ImageUpload } from "@/components/ImageUpload";
import { Button, Field, Input } from "@/components/ui";

export function ProfileForm({ name, image, showStudentId }: { name: string; image: string | null; showStudentId: boolean }) {
  const [s, action, pending] = useActionState<FormState, FormData>(updateProfile, undefined);
  return (
    <form action={action} className="space-y-4">
      <Field label="Name"><Input name="name" defaultValue={name} required maxLength={80} /></Field>
      <ImageUpload name="image" purpose="profile" initialUrl={image} label="Profile photo" />
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="showStudentId" defaultChecked={showStudentId} className="h-4 w-4 accent-[rgb(var(--brass))]" />Show my Student ID on my Lost &amp; Found posts</label>
      {s?.error && <p role="alert" className="text-sm text-danger">{s.error}</p>}
      {s?.fieldErrors?._ok && <p role="status" className="text-sm text-ok">Saved.</p>}
      <Button type="submit" loading={pending}>Save changes</Button>
    </form>
  );
}
