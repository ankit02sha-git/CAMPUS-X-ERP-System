"use client";

import React, { useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { fetchTodaysBirthdaysAction } from "@/actions/birthday";
import { StudentBirthdayGreeting } from "@/server/birthday";
import { BirthdayCard } from "./BirthdayCard";

/**
 * Container component for active birthday greetings.
 * Manages fetching, localStorage dismissal state, and multi-card rendering.
 */
export function BirthdayBanner() {
  const [greetings, setGreetings] = useState<StudentBirthdayGreeting[]>([]);
  const [todayKeyStr, setTodayKeyStr] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function loadBirthdays() {
      try {
        const res = await fetchTodaysBirthdaysAction();
        if (!isMounted) return;

        setTodayKeyStr(res.todayKeyStr);

        // Filter out students whose birthday cards have already been dismissed today
        const activeGreetings = res.greetings.filter((g) => {
          try {
            const key = `campusx:birthday-dismissed:${res.todayKeyStr}:${g.id}`;
            return localStorage.getItem(key) !== "true";
          } catch {
            return true;
          }
        });

        setGreetings(activeGreetings);
      } catch (err) {
        console.error("Failed to load birthday greetings:", err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadBirthdays();

    return () => {
      isMounted = false;
    };
  }, []);

  const handleDismiss = (id: string) => {
    setGreetings((prev) => prev.filter((item) => item.id !== id));
  };

  if (isLoading || greetings.length === 0) {
    return null;
  }

  return (
    <div className="mb-6 space-y-3" aria-label="Birthday Greetings Notification Area">
      <AnimatePresence mode="popLayout">
        {greetings.map((item) => (
          <BirthdayCard
            key={item.id}
            greeting={item}
            todayKeyStr={todayKeyStr}
            onDismiss={handleDismiss}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}
