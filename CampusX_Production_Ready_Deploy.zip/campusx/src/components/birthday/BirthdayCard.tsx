"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Cake, Sparkles, X, PartyPopper } from "lucide-react";
import { StudentBirthdayGreeting } from "@/server/birthday";

interface BirthdayCardProps {
  greeting: StudentBirthdayGreeting;
  todayKeyStr: string;
  onDismiss: (id: string) => void;
}

/**
 * Interactive Birthday Greeting Glass Card with Paper Crumple & Slide Dismissal.
 * 
 * - Click '×' button: Smooth slide & fade out dismissal.
 * - Click card body: Wrinkle / paper crumple & fall downward dismissal.
 * - Saves dismissal key in localStorage: campusx:birthday-dismissed:YYYY-MM-DD:<student-id>
 */
export function BirthdayCard({ greeting, todayKeyStr, onDismiss }: BirthdayCardProps) {
  const [dismissState, setDismissState] = useState<"idle" | "slide" | "crumple">("idle");

  const saveDismissalToStorage = () => {
    try {
      const storageKey = `campusx:birthday-dismissed:${todayKeyStr}:${greeting.id}`;
      localStorage.setItem(storageKey, "true");
    } catch {
      // Ignore localStorage read/write exceptions
    }
  };

  const handleCloseClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (dismissState !== "idle") return;
    saveDismissalToStorage();
    setDismissState("slide");
    setTimeout(() => {
      onDismiss(greeting.id);
    }, 220);
  };

  const handleBodyClick = () => {
    if (dismissState !== "idle") return;
    saveDismissalToStorage();
    setDismissState("crumple");
    setTimeout(() => {
      onDismiss(greeting.id);
    }, 450);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -12, scale: 0.96 }}
      animate={
        dismissState === "slide"
          ? { opacity: 0, x: 80, scale: 0.95 }
          : dismissState === "crumple"
          ? {
              opacity: 0,
              scale: 0.52,
              rotate: 15,
              skewX: -9,
              skewY: 3,
              y: 90,
              filter: "brightness(0.9) contrast(1.2)",
            }
          : { opacity: 1, y: 0, scale: 1, rotate: 0, skewX: 0, skewY: 0 }
      }
      transition={
        dismissState === "crumple"
          ? { duration: 0.44, ease: [0.36, 0, 0.66, -0.56] }
          : dismissState === "slide"
          ? { duration: 0.22, ease: "easeInOut" }
          : { type: "spring", stiffness: 350, damping: 28 }
      }
      onClick={handleBodyClick}
      className="group relative cursor-pointer overflow-hidden rounded-card border border-shcyellow/40 bg-gradient-to-r from-amber-500/10 via-surface/80 to-amber-500/15 p-4 shadow-lift backdrop-blur-md transition-all hover:border-shcyellow/70 hover:shadow-lg"
      title="Click card to crumple & dismiss greeting"
    >
      {/* Decorative Golden Ambient Glow */}
      <div className="pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-shcyellow/20 blur-xl transition-transform group-hover:scale-125" />
      <div className="pointer-events-none absolute -left-6 -bottom-6 h-24 w-24 rounded-full bg-amber-400/15 blur-xl" />

      {/* Close button (Action A: Smooth Slide-Fade Out) */}
      <button
        type="button"
        onClick={handleCloseClick}
        aria-label={`Dismiss birthday card for ${greeting.name}`}
        className="absolute right-3 top-3 z-10 grid h-7 w-7 place-items-center rounded-ctl bg-surface/60 text-muted border border-line hover:bg-shcyellow/20 hover:text-amber-600 dark:hover:text-shcyellow transition-colors"
      >
        <X className="h-4 w-4" />
      </button>

      <div className="relative z-0 flex items-start gap-3.5 pr-8">
        {/* Animated Cake / Party Icon */}
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-md border border-white/30 group-hover:rotate-6 transition-transform">
          <Cake className="h-5 w-5 animate-pulse" />
        </div>

        <div className="min-w-0 flex-1">
          {/* Header Badge */}
          <div className="mb-1 flex items-center gap-2">
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/20 px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-shcyellow border border-amber-500/30">
              <PartyPopper className="h-3 w-3" /> Birthday Today
            </span>
            <span className="text-[10px] text-muted opacity-80 hidden sm:inline-flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-shcyellow" /> Click card to crumple
            </span>
          </div>

          {/* Student Greeting Body */}
          <h3 className="text-sm font-bold text-ink sm:text-base flex items-center gap-1.5">
            Happy Birthday, <span className="text-brand dark:text-shcyellow">{greeting.name}</span>! 🎉
          </h3>
          <p className="mt-0.5 text-xs sm:text-sm text-muted leading-relaxed">
            {greeting.message}
          </p>
        </div>
      </div>
    </motion.div>
  );
}
