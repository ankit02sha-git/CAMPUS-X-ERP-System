"use client";
import { useActionState, useState } from "react";
import Link from "next/link";
import { studentLoginAction, adminLoginAction, type FormState } from "@/actions/auth";
import { Button, Field, Input, PasswordInput } from "@/components/ui";

export function LoginForm() {
  const [tab, setTab] = useState<"STUDENT" | "ADMIN">("STUDENT");

  const [studentState, studentAction, studentPending] = useActionState<FormState, FormData>(
    studentLoginAction,
    undefined
  );

  const [adminState, adminAction, adminPending] = useActionState<FormState, FormData>(
    adminLoginAction,
    undefined
  );

  return (
    <div className="space-y-4">
      {/* Role Switcher Tabs */}
      <div className="grid grid-cols-2 rounded-ctl bg-surface p-1 hairline">
        <button
          type="button"
          onClick={() => setTab("STUDENT")}
          className={`rounded-[6px] py-1.5 text-xs font-semibold transition-colors ${
            tab === "STUDENT" ? "bg-brass text-white shadow-sm" : "text-muted hover:text-ink"
          }`}
        >
          🎓 Student Portal Login
        </button>
        <button
          type="button"
          onClick={() => setTab("ADMIN")}
          className={`rounded-[6px] py-1.5 text-xs font-semibold transition-colors ${
            tab === "ADMIN" ? "bg-navy-deep text-white shadow-sm" : "text-muted hover:text-ink"
          }`}
        >
          🛡️ Admin Login
        </button>
      </div>

      {/* STUDENT LOGIN FORM */}
      {tab === "STUDENT" && (
        <form action={studentAction} className="space-y-4 pt-1">
          <Field label="Student ID" hint="Official College ID (e.g. SHC2504023)">
            <Input
              name="studentId"
              type="text"
              required
              autoFocus
              placeholder="e.g. SHC2504023"
              className="uppercase font-mono tracking-wide"
            />
          </Field>
          <Field label="Password">
            <PasswordInput name="password" autoComplete="current-password" required placeholder="••••••••" />
          </Field>

          <div className="flex items-center justify-end text-xs">
            <Link href="/forgot-password" className="font-medium text-brass hover:underline">
              Forgot Password?
            </Link>
          </div>

          {studentState?.error && (
            <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger font-medium">
              {studentState.error}
            </p>
          )}

          <Button type="submit" loading={studentPending} className="w-full">
            Sign In to Student Portal
          </Button>

          <div className="rounded-card bg-brass/5 p-3.5 border border-brass/20 text-center space-y-1 mt-4">
            <p className="text-xs text-muted">New student or haven't set a password?</p>
            <Link
              href="/activate"
              className="inline-block font-semibold text-xs text-brass hover:underline uppercase tracking-wide"
            >
              👉 Activate Student Account
            </Link>
          </div>
        </form>
      )}

      {/* ADMIN LOGIN FORM */}
      {tab === "ADMIN" && (
        <form action={adminAction} className="space-y-4 pt-1">
          <Field label="Admin Email or Username">
            <Input name="emailOrId" type="text" autoComplete="username" required placeholder="admin@campusx.local" />
          </Field>
          <Field label="Admin Password">
            <PasswordInput name="password" autoComplete="current-password" required placeholder="••••••••" />
          </Field>

          {adminState?.error && (
            <p role="alert" className="rounded-ctl bg-danger/10 px-3 py-2 text-sm text-danger font-medium">
              {adminState.error}
            </p>
          )}

          <Button type="submit" loading={adminPending} className="w-full bg-navy-deep hover:bg-navy">
            Sign In to Administration
          </Button>
        </form>
      )}
    </div>
  );
}
