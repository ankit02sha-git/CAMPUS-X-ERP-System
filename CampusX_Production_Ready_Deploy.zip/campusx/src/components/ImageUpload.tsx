"use client";
import { ImagePlus, RefreshCw, Trash2 } from "lucide-react";
import { useRef, useState } from "react";
import { Button } from "@/components/ui";

const OK = ["image/jpeg", "image/png", "image/webp"];
const MAX = 5 * 1024 * 1024;

/** Client-validated for UX, but the server re-validates type, size and magic bytes. Renders a hidden input `name` with the stored URL. */
export function ImageUpload({ name, purpose, initialUrl, label = "Photo" }: { name: string; purpose: "lost" | "response" | "profile" | "event" | "canteen"; initialUrl?: string | null; label?: string }) {
  const [url, setUrl] = useState(initialUrl ?? "");
  const [preview, setPreview] = useState(initialUrl ?? "");
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState("");
  const input = useRef<HTMLInputElement>(null);

  function pick(file?: File) {
    if (!file) return;
    setError("");
    if (!OK.includes(file.type)) return setError("Use a JPG, PNG or WebP image.");
    if (file.size > MAX) return setError("Image must be 5 MB or smaller.");
    const local = URL.createObjectURL(file);
    setPreview(local); setProgress(0);
    const fd = new FormData(); fd.append("file", file); fd.append("purpose", purpose);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload");
    xhr.upload.onprogress = (e) => e.lengthComputable && setProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      setProgress(null);
      try { const r = JSON.parse(xhr.responseText); if (xhr.status === 200) setUrl(r.url); else { setError(r.error ?? "Upload failed."); setPreview(url); } }
      catch { setError("Upload failed. Please try again."); setPreview(url); }
    };
    xhr.onerror = () => { setProgress(null); setError("Network error. Check your connection and retry."); setPreview(url); };
    xhr.send(fd);
  }
  return (
    <div>
      <span className="mb-1.5 block text-[13px] font-medium">{label}</span>
      <input type="hidden" name={name} value={url} />
      <input ref={input} type="file" accept={OK.join(",")} className="sr-only" aria-label={label} onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
      {preview ? (
        <div className="relative overflow-hidden rounded-card hairline bg-raised">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={preview} alt="Upload preview" className="h-52 w-full object-cover" />
          {progress !== null && (
            <div className="absolute inset-x-0 bottom-0 bg-black/55 p-3 text-xs text-white"><div className="mb-1.5">Uploading… {progress}%</div><div className="h-1 overflow-hidden rounded-full bg-white/30"><div className="h-full bg-brass transition-all" style={{ width: `${progress}%` }} /></div></div>
          )}
          <div className="absolute right-2 top-2 flex gap-1.5">
            <Button type="button" size="sm" variant="outline" onClick={() => input.current?.click()}><RefreshCw className="h-3.5 w-3.5" />Replace</Button>
            <Button type="button" size="sm" variant="outline" onClick={() => { setUrl(""); setPreview(""); setProgress(null); }}><Trash2 className="h-3.5 w-3.5" />Remove</Button>
          </div>
        </div>
      ) : (
        <button type="button" onClick={() => input.current?.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); pick(e.dataTransfer.files?.[0]); }}
          className="flex h-36 w-full flex-col items-center justify-center gap-2 rounded-card border border-dashed border-line bg-surface/60 text-sm text-muted transition-colors hover:border-brass hover:text-ink">
          <ImagePlus className="h-6 w-6 text-brass" /><span>Click or drop an image</span><span className="text-xs">JPG, PNG or WebP · up to 5 MB</span>
        </button>
      )}
      {error && <p role="alert" className="mt-1.5 text-xs text-danger">{error}</p>}
    </div>
  );
}
