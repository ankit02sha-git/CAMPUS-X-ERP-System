"use server";
import bcrypt from "bcryptjs";
import { and, desc, eq } from "drizzle-orm";
import { AuthError } from "next-auth";
import { headers } from "next/headers";
import { signIn, signOut } from "@/auth";
import { db } from "@/server/db";
import { otps, studentStats, studentsMaster, users } from "@/server/db/schema";
import {
  activateCompleteSchema,
  activateStep1Schema,
  forgotPasswordResetSchema,
  studentLoginSchema,
  verifyOtpSchema,
} from "@/lib/validators";
import { rateLimit } from "@/server/ratelimit";
import {
  maskMobileNumber,
  resendVerificationCode,
  sendVerificationCode,
  verifyVerificationCode,
} from "@/lib/sms";

/**
 * Shape passed between the server actions and the two OTP flow client components.
 * Every field is optional — actions return only what the UI needs to render next.
 */
export type FormState =
  | {
      error?: string;
      fieldErrors?: Record<string, string>;
      step?: number;
      studentId?: string;
      maskedMobile?: string;
      devOtp?: string;
      isRealSMS?: boolean;
      successMessage?: string;
      /** Informational hint for the resend countdown. Server always re-checks server-side. */
      resendCooldownSeconds?: number;
    }
  | undefined;

/** Flow session TTL, in ms. */
const OTP_TTL_MS = 5 * 60 * 1000;
/** Per (ip, student) resend cooldown, enforced server-side. */
const RESEND_COOLDOWN_SECONDS = 60;

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────

async function getClientIp(): Promise<string> {
  try {
    return (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  } catch {
    return "local";
  }
}

/**
 * Send-first, persist-on-success helper for an ACTIVATION flow session.
 * Twilio Verify generates and delivers the OTP.
 */
async function sendAndPersistActivationOtp(
  studentId: string,
  sm: { registeredMobile: string }
): Promise<FormState> {
  const smsResult = await sendVerificationCode({
    toMobile: sm.registeredMobile,
    purpose: "ACTIVATION",
  });

  if (!smsResult.success) {
    return {
      error: smsResult.userFacingMessage || "Unable to send verification code. Please try again.",
    };
  }

  const expiresAt = new Date(Date.now() + OTP_TTL_MS);

  await db
    .update(otps)
    .set({ used: true })
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "ACTIVATION"), eq(otps.used, false)));

  await db.insert(otps).values({
    studentId,
    mobile: sm.registeredMobile,
    otpHash: "TWILIO_VERIFY",
    rawOtpForDev: null,
    type: "ACTIVATION",
    expiresAt,
    attempts: 0,
    used: false,
  });

  return {
    step: 2,
    studentId,
    maskedMobile: maskMobileNumber(sm.registeredMobile),
    isRealSMS: smsResult.isRealSMS,
    successMessage: `Verification code sent via SMS to registered mobile: ${maskMobileNumber(sm.registeredMobile)}`,
    resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
  };
}

/** Send-first, persist-on-success helper for a FORGOT_PASSWORD flow session. */
async function sendAndPersistForgotPasswordOtp(
  studentId: string,
  mobile: string
): Promise<FormState> {
  const smsResult = await sendVerificationCode({
    toMobile: mobile,
    purpose: "FORGOT_PASSWORD",
  });

  if (!smsResult.success) {
    return {
      error: smsResult.userFacingMessage || "Unable to send verification code. Please try again.",
    };
  }

  const expiresAt = new Date(Date.now() + OTP_TTL_MS);

  await db
    .update(otps)
    .set({ used: true })
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "FORGOT_PASSWORD"), eq(otps.used, false)));

  await db.insert(otps).values({
    studentId,
    mobile,
    otpHash: "TWILIO_VERIFY",
    rawOtpForDev: null,
    type: "FORGOT_PASSWORD",
    expiresAt,
    attempts: 0,
    used: false,
  });

  return {
    step: 2,
    studentId,
    maskedMobile: maskMobileNumber(mobile),
    isRealSMS: smsResult.isRealSMS,
    successMessage: `Verification code sent via SMS to registered mobile: ${maskMobileNumber(mobile)}`,
    resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
  };
}

// ─────────────────────────────────────────────────────────────
// Login actions (unchanged)
// ─────────────────────────────────────────────────────────────

/** Student Login: Student ID + Password. */
export async function studentLoginAction(_: FormState, fd: FormData): Promise<FormState> {
  const studentId = String(fd.get("studentId") || "").trim();
  const password = String(fd.get("password") || "").trim();

  const parsed = studentLoginSchema.safeParse({ studentId, password });
  if (!parsed.success) return { error: "Please enter a valid Student ID and Password." };

  try {
    await signIn("credentials", {
      studentId: parsed.data.studentId,
      password: parsed.data.password,
      redirectTo: "/dashboard",
    });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Invalid Student ID or password, or account is disabled." };
    }
    throw e;
  }
}

/** Admin Login: Email / Admin ID + Password. */
export async function adminLoginAction(_: FormState, fd: FormData): Promise<FormState> {
  const emailOrId = String(fd.get("emailOrId") || "").trim();
  const password = String(fd.get("password") || "").trim();

  if (!emailOrId || !password) return { error: "Please enter Email and Password." };

  try {
    await signIn("credentials", {
      emailOrId,
      password,
      redirectTo: "/admin",
    });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Invalid admin credentials." };
    }
    throw e;
  }
}

// ─────────────────────────────────────────────────────────────
// Activation flow
// ─────────────────────────────────────────────────────────────

/**
 * Activation Step 1: check official student master record, then request Twilio Verify OTP.
 */
export async function startActivationAction(_: FormState, fd: FormData): Promise<FormState> {
  const ip = await getClientIp();
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();

  const parsed = activateStep1Schema.safeParse({ studentId });
  if (!parsed.success) return { error: "Enter a valid official Student ID." };

  if (!rateLimit(`otp_req:${ip}:${studentId}`, 5, 15 * 60_000)) {
    return { error: "Too many verification requests. Please wait a few minutes." };
  }

  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.studentId, studentId)).limit(1);
  if (!sm) {
    return { error: "Student ID not found in official college database. Please contact campus admin." };
  }
  if (sm.status === "DISABLED") {
    return { error: "This student record has been disabled by admin." };
  }
  if (sm.activationStatus === "ACTIVATED") {
    return { error: "This account has already been activated. Please log in using Student ID and Password." };
  }

  return sendAndPersistActivationOtp(studentId, sm);
}

/**
 * Resend the activation verification code via Twilio Verify.
 */
export async function resendActivationOtpAction(_: FormState, fd: FormData): Promise<FormState> {
  const ip = await getClientIp();
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();

  const parsed = activateStep1Schema.safeParse({ studentId });
  if (!parsed.success) return { error: "Enter a valid official Student ID.", step: 2, studentId };

  if (!rateLimit(`otp_resend:${ip}:${studentId}`, 1, RESEND_COOLDOWN_SECONDS * 1000)) {
    return {
      error: "Please wait a moment before requesting another code.",
      step: 2,
      studentId,
    };
  }

  if (!rateLimit(`otp_req:${ip}:${studentId}`, 5, 15 * 60_000)) {
    return {
      error: "Too many verification requests. Please wait a few minutes.",
      step: 2,
      studentId,
    };
  }

  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.studentId, studentId)).limit(1);
  if (!sm) {
    return { error: "Student ID not found in official college database. Please contact campus admin.", step: 1 };
  }
  if (sm.status === "DISABLED") {
    return { error: "This student record has been disabled by admin.", step: 1 };
  }
  if (sm.activationStatus === "ACTIVATED") {
    return { error: "This account has already been activated. Please log in using Student ID and Password.", step: 1 };
  }

  const resendResult = await resendVerificationCode({
    toMobile: sm.registeredMobile,
    purpose: "ACTIVATION",
  });

  if (!resendResult.success) {
    return {
      error: resendResult.userFacingMessage || "Unable to resend verification code right now. Please try again.",
      step: 2,
      studentId,
    };
  }

  const expiresAt = new Date(Date.now() + OTP_TTL_MS);
  await db
    .update(otps)
    .set({ expiresAt })
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "ACTIVATION"), eq(otps.used, false)));

  return {
    step: 2,
    studentId,
    maskedMobile: maskMobileNumber(sm.registeredMobile),
    isRealSMS: true,
    successMessage: "A new verification code has been sent.",
    resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
  };
}

/** Activation Step 2: verify code with Twilio Verify. */
export async function verifyActivationOtpAction(_: FormState, fd: FormData): Promise<FormState> {
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();
  const otp = String(fd.get("otp") || "").trim();

  const parsed = verifyOtpSchema.safeParse({ studentId, otp, type: "ACTIVATION" });
  if (!parsed.success) return { error: "Please enter a valid numeric verification code.", step: 2, studentId };

  const [record] = await db
    .select()
    .from(otps)
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "ACTIVATION"), eq(otps.used, false)))
    .orderBy(desc(otps.createdAt))
    .limit(1);

  if (!record) return { error: "Session expired or invalid. Please request a new code.", step: 2, studentId };

  if (record.expiresAt.getTime() < Date.now()) {
    await db.update(otps).set({ used: true }).where(eq(otps.id, record.id));
    return { error: "Verification code has expired. Please request a new code.", step: 2, studentId };
  }

  if (record.attempts >= 5) {
    await db.update(otps).set({ used: true }).where(eq(otps.id, record.id));
    return { error: "Too many failed attempts. Please request a new code.", step: 2, studentId };
  }

  const verifyResult = await verifyVerificationCode({
    toMobile: record.mobile,
    otp,
  });

  if (!verifyResult.success) {
    await db.update(otps).set({ attempts: record.attempts + 1 }).where(eq(otps.id, record.id));
    return {
      error: verifyResult.userFacingMessage || "Invalid or expired verification code. Please try again.",
      step: 2,
      studentId,
    };
  }

  return {
    step: 3,
    studentId,
    successMessage: "Code verified! Please create your account password.",
  };
}

/** Activation Step 3: create password + finalise account + sign the student in. */
export async function completeActivationAction(_: FormState, fd: FormData): Promise<FormState> {
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();
  const otp = String(fd.get("otp") || "").trim();
  const password = String(fd.get("password") || "").trim();

  const parsed = activateCompleteSchema.safeParse({ studentId, otp, password });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      fieldErrors[String(issue.path[0])] = issue.message;
    }
    return { fieldErrors, step: 3, studentId };
  }

  const [record] = await db
    .select()
    .from(otps)
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "ACTIVATION"), eq(otps.used, false)))
    .orderBy(desc(otps.createdAt))
    .limit(1);

  if (!record || record.expiresAt.getTime() < Date.now()) {
    return { error: "Session expired. Please restart activation.", step: 1 };
  }

  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.studentId, studentId)).limit(1);
  if (!sm) return { error: "Student master record not found.", step: 1 };

  const passwordHash = await bcrypt.hash(password, 12);
  const email = `${studentId.toLowerCase()}@student.campusx.local`;

  const [existingUser] = await db.select().from(users).where(eq(users.studentId, studentId)).limit(1);

  if (existingUser) {
    await db
      .update(users)
      .set({
        name: sm.fullName,
        passwordHash,
        registeredMobile: sm.registeredMobile,
        courseId: sm.courseId,
        semester: sm.semester,
        section: sm.section,
        department: sm.department,
        academicYear: sm.academicYear,
        rollNumber: sm.rollNumber,
        active: true,
        activationStatus: "ACTIVATED",
        studentMasterId: sm.id,
      })
      .where(eq(users.id, existingUser.id));
  } else {
    const [u] = await db
      .insert(users)
      .values({
        name: sm.fullName,
        email,
        studentId: sm.studentId,
        passwordHash,
        registeredMobile: sm.registeredMobile,
        courseId: sm.courseId,
        semester: sm.semester,
        section: sm.section,
        department: sm.department,
        academicYear: sm.academicYear,
        rollNumber: sm.rollNumber,
        role: "STUDENT",
        active: true,
        activationStatus: "ACTIVATED",
        studentMasterId: sm.id,
      })
      .returning();

    await db.insert(studentStats).values({ userId: u.id, isDemo: false });
  }

  await db.update(otps).set({ used: true }).where(eq(otps.id, record.id));
  await db.update(studentsMaster).set({ activationStatus: "ACTIVATED" }).where(eq(studentsMaster.id, sm.id));

  try {
    await signIn("credentials", {
      studentId: sm.studentId,
      password,
      redirectTo: "/dashboard",
    });
  } catch (e) {
    if (e instanceof AuthError) return { successMessage: "Account activated successfully! Please sign in." };
    throw e;
  }
}

// ─────────────────────────────────────────────────────────────
// Forgot-password flow
// ─────────────────────────────────────────────────────────────

/**
 * Forgot-password Step 1: verify Student ID and request Twilio Verify code.
 */
export async function startForgotPasswordAction(_: FormState, fd: FormData): Promise<FormState> {
  const ip = await getClientIp();
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();

  if (!studentId) return { error: "Please enter your Student ID." };

  if (!rateLimit(`reset_req:${ip}:${studentId}`, 5, 15 * 60_000)) {
    return { error: "Too many password reset attempts. Please wait." };
  }

  const [u] = await db.select().from(users).where(eq(users.studentId, studentId)).limit(1);
  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.studentId, studentId)).limit(1);

  const mobile = u?.registeredMobile || sm?.registeredMobile;

  if (!mobile || (!u && !sm)) {
    return {
      step: 2,
      studentId,
      maskedMobile: "******",
      successMessage: "If the Student ID is registered, a verification code has been sent.",
      resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
    };
  }

  return sendAndPersistForgotPasswordOtp(studentId, mobile);
}

/** Resend the forgot-password code via Twilio Verify. */
export async function resendForgotPasswordOtpAction(_: FormState, fd: FormData): Promise<FormState> {
  const ip = await getClientIp();
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();

  if (!studentId) return { error: "Please enter your Student ID.", step: 1 };

  if (!rateLimit(`reset_resend:${ip}:${studentId}`, 1, RESEND_COOLDOWN_SECONDS * 1000)) {
    return {
      error: "Please wait a moment before requesting another code.",
      step: 2,
      studentId,
    };
  }

  if (!rateLimit(`reset_req:${ip}:${studentId}`, 5, 15 * 60_000)) {
    return {
      error: "Too many password reset attempts. Please wait.",
      step: 2,
      studentId,
    };
  }

  const [u] = await db.select().from(users).where(eq(users.studentId, studentId)).limit(1);
  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.studentId, studentId)).limit(1);

  const mobile = u?.registeredMobile || sm?.registeredMobile;

  if (!mobile || (!u && !sm)) {
    return {
      step: 2,
      studentId,
      maskedMobile: "******",
      successMessage: "If the Student ID is registered, a verification code has been sent.",
      resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
    };
  }

  const resendResult = await resendVerificationCode({
    toMobile: mobile,
    purpose: "FORGOT_PASSWORD",
  });

  if (!resendResult.success) {
    return {
      error: resendResult.userFacingMessage || "Unable to resend verification code right now. Please try again.",
      step: 2,
      studentId,
    };
  }

  const expiresAt = new Date(Date.now() + OTP_TTL_MS);
  await db
    .update(otps)
    .set({ expiresAt })
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "FORGOT_PASSWORD"), eq(otps.used, false)));

  return {
    step: 2,
    studentId,
    maskedMobile: maskMobileNumber(mobile),
    isRealSMS: true,
    successMessage: "A new verification code has been sent.",
    resendCooldownSeconds: RESEND_COOLDOWN_SECONDS,
  };
}

/** Forgot-password Step 2: verify code with Twilio Verify + set new password. */
export async function resetForgotPasswordAction(_: FormState, fd: FormData): Promise<FormState> {
  const studentId = String(fd.get("studentId") || "").trim().toUpperCase();
  const otp = String(fd.get("otp") || "").trim();
  const newPassword = String(fd.get("newPassword") || "").trim();

  const parsed = forgotPasswordResetSchema.safeParse({ studentId, otp, newPassword });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      fieldErrors[String(issue.path[0])] = issue.message;
    }
    return { fieldErrors, step: 2, studentId };
  }

  const [record] = await db
    .select()
    .from(otps)
    .where(and(eq(otps.studentId, studentId), eq(otps.type, "FORGOT_PASSWORD"), eq(otps.used, false)))
    .orderBy(desc(otps.createdAt))
    .limit(1);

  if (!record || record.expiresAt.getTime() < Date.now()) {
    return { error: "Verification code expired or invalid. Please request a new code.", step: 1 };
  }

  if (record.attempts >= 5) {
    await db.update(otps).set({ used: true }).where(eq(otps.id, record.id));
    return { error: "Too many failed attempts. Please request a new code.", step: 1 };
  }

  const verifyResult = await verifyVerificationCode({
    toMobile: record.mobile,
    otp,
  });

  if (!verifyResult.success) {
    await db.update(otps).set({ attempts: record.attempts + 1 }).where(eq(otps.id, record.id));
    return { error: verifyResult.userFacingMessage || "Invalid or expired verification code.", step: 2, studentId };
  }

  const [u] = await db.select().from(users).where(eq(users.studentId, studentId)).limit(1);
  if (!u) return { error: "Student user account not found. Please activate your account first.", step: 1 };

  const newHash = await bcrypt.hash(newPassword, 12);
  await db.update(users).set({ passwordHash: newHash }).where(eq(users.id, u.id));
  await db.update(otps).set({ used: true }).where(eq(otps.id, record.id));

  return {
    successMessage: "Password reset successfully! You can now log in with your new password.",
  };
}

export async function logoutAction() {
  await signOut({ redirectTo: "/login" });
}
