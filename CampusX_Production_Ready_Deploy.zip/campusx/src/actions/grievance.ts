"use server";

import { requireUser, requireAdmin } from "@/server/guards";
import {
  getStudentGrievanceTickets,
  getAdminGrievanceTickets,
  createGrievanceTicket,
  updateAdminGrievanceStatus,
} from "@/server/grievance";
import { revalidatePath } from "next/cache";

export async function fetchMyGrievancesAction() {
  const user = await requireUser();
  return await getStudentGrievanceTickets(user.id);
}

export async function submitGrievanceTicketAction(
  category: "ACADEMIC" | "FEE" | "TIMETABLE" | "INFRASTRUCTURE" | "TECHNICAL",
  subject: string,
  description: string
) {
  const user = await requireUser();
  const ticket = await createGrievanceTicket(user.id, category, subject, description);
  revalidatePath("/grievance");
  return ticket;
}

export async function fetchAdminGrievancesAction() {
  await requireAdmin();
  return await getAdminGrievanceTickets();
}

export async function updateAdminGrievanceAction(
  ticketId: string,
  status: "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED",
  adminResponse?: string
) {
  await requireAdmin();
  const res = await updateAdminGrievanceStatus(ticketId, status, adminResponse);
  revalidatePath("/grievance");
  revalidatePath("/admin/grievances");
  return res;
}
