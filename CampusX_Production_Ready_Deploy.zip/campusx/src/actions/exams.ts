"use server";

import { requireUser } from "@/server/guards";
import { getStudentExamsList, getStudentResultsList } from "@/server/exams";

export async function fetchMyExamsAction(semester?: number) {
  const user = await requireUser();
  return await getStudentExamsList(user.courseId, user.semester, semester);
}

export async function fetchMyResultsAction(semester?: number) {
  const user = await requireUser();
  return await getStudentResultsList(user.id, user.courseId, user.semester, semester);
}
