"use server";
import { and, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/server/db";
import { courses, timetableSlots, timetablesMaster } from "@/server/db/schema";
import { requireAdmin } from "@/server/guards";
import type { FormState } from "@/actions/auth";

export async function getTimetableData(courseId: string, semester: number) {
  const [master] = await db
    .select()
    .from(timetablesMaster)
    .where(and(eq(timetablesMaster.courseId, courseId), eq(timetablesMaster.semester, semester)))
    .limit(1);

  if (!master) return null;

  const slots = await db
    .select()
    .from(timetableSlots)
    .where(eq(timetableSlots.timetableId, master.id));

  return { master, slots };
}

export async function saveTimetableHeaderAction(_: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const timetableId = String(fd.get("timetableId") || "").trim();
    const title = String(fd.get("title") || "").trim();
    const effectiveDate = String(fd.get("effectiveDate") || "").trim();
    const classAdvisor = String(fd.get("classAdvisor") || "").trim();

    if (!timetableId) return { error: "Timetable ID missing." };

    await db
      .update(timetablesMaster)
      .set({
        title: title || "CLASS TIME TABLE",
        effectiveDate: effectiveDate || "20th July, 2026",
        classAdvisor: classAdvisor || null,
      })
      .where(eq(timetablesMaster.id, timetableId));

    revalidatePath("/admin/timetable");
    revalidatePath("/timetable");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    console.error(e);
    return { error: "Failed to update timetable header." };
  }
}

export async function saveSlotAction(_: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const slotId = String(fd.get("slotId") || "").trim();
    const timetableId = String(fd.get("timetableId") || "").trim();
    const day = String(fd.get("day") || "").trim() as "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY";
    const startPeriod = Number(fd.get("startPeriod") || 1);
    const spanPeriods = Number(fd.get("spanPeriods") || 1);
    const entryType = String(fd.get("entryType") || "NORMAL_CLASS").trim();
    const facultyName = String(fd.get("facultyName") || "").trim();
    const subjectName = String(fd.get("subjectName") || "").trim();
    const isSpecialActivity = fd.get("isSpecialActivity") === "on" || fd.get("isSpecialActivity") === "true" || entryType !== "NORMAL_CLASS";
    const activityTitle = String(fd.get("activityTitle") || "").trim();
    const activityDescription = String(fd.get("activityDescription") || "").trim();
    const colorTheme = String(fd.get("colorTheme") || "").trim();

    if (!timetableId || !day || !startPeriod) {
      return { error: "Missing required slot arguments." };
    }

    const payload = {
      timetableId,
      day,
      startPeriod,
      spanPeriods,
      entryType,
      facultyName: facultyName || null,
      subjectName: subjectName || null,
      isSpecialActivity,
      activityTitle: activityTitle || null,
      activityDescription: activityDescription || null,
      colorTheme: colorTheme || null,
    };

    if (slotId) {
      await db.update(timetableSlots).set(payload).where(eq(timetableSlots.id, slotId));
    } else {
      // Remove any overlapping slots on the same day and startPeriod
      await db
        .delete(timetableSlots)
        .where(
          and(
            eq(timetableSlots.timetableId, timetableId),
            eq(timetableSlots.day, day),
            eq(timetableSlots.startPeriod, startPeriod)
          )
        );

      await db.insert(timetableSlots).values(payload);
    }

    revalidatePath("/admin/timetable");
    revalidatePath("/timetable");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    console.error(e);
    return { error: "Failed to save timetable slot." };
  }
}

export async function deleteSlotAction(slotId: string) {
  await requireAdmin();
  await db.delete(timetableSlots).where(eq(timetableSlots.id, slotId));
  revalidatePath("/admin/timetable");
  revalidatePath("/timetable");
}

export async function createTimetableMasterAction(courseId: string, semester: number, title: string) {
  await requireAdmin();
  const [existing] = await db
    .select()
    .from(timetablesMaster)
    .where(and(eq(timetablesMaster.courseId, courseId), eq(timetablesMaster.semester, semester)))
    .limit(1);

  if (existing) return existing.id;

  const [tm] = await db
    .insert(timetablesMaster)
    .values({
      courseId,
      semester,
      title: title || "CLASS TIME TABLE",
      effectiveDate: "20th July, 2026",
      published: true,
    })
    .returning();

  revalidatePath("/admin/timetable");
  return tm.id;
}
