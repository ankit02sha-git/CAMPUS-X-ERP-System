"use server";

import { and, eq, isNull, or, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/server/db";
import { eventRegistrations, events } from "@/server/db/schema";
import { requireAdmin, requireUser } from "@/server/guards";
import { eventSchema } from "@/lib/validators";

export async function checkDuplicateEventAction(title: string, date: string, excludeId?: string) {
  try {
    await requireAdmin();
    const cleanTitle = title.trim().toLowerCase();
    const all = await db.select().from(events).where(isNull(events.deletedAt));

    const dup = all.find((e) => {
      if (excludeId && e.id === excludeId) return false;
      const t = e.title.trim().toLowerCase();
      // Exact title match or same date + similar title
      if (t === cleanTitle) return true;
      if (e.date === date && (t.includes(cleanTitle) || cleanTitle.includes(t))) return true;
      // Special check for Freshers / AAGAT
      if ((cleanTitle.includes("fresher") || cleanTitle === "aagat") && (t.includes("fresher") || t === "aagat")) {
        return true;
      }
      return false;
    });

    if (dup) {
      if (dup.title.toUpperCase() === "AAGAT" || cleanTitle.includes("fresher")) {
        return {
          duplicate: true,
          warning: `Notice: AAGAT (Freshers Party) already exists on 1 October 2026. AAGAT and Freshers refer to the same event identity in Study Hall College.`,
        };
      }
      return {
        duplicate: true,
        warning: `An event with a similar title/date ("${dup.title}" on ${dup.date}) already exists. Please verify before creating a duplicate.`,
      };
    }

    return { duplicate: false };
  } catch (err: any) {
    return { duplicate: false };
  }
}

export async function createEventAction(rawData: Record<string, unknown>) {
  try {
    await requireAdmin();

    const parsed = eventSchema.safeParse(rawData);
    if (!parsed.success) {
      const firstErr = parsed.error.issues[0]?.message || "Invalid event input data.";
      return { success: false, error: firstErr };
    }

    const data = parsed.data;

    // Generate slug from title
    const slug = data.slug || data.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

    const newId = crypto.randomUUID();
    await db.insert(events).values({
      id: newId,
      title: data.title,
      slug,
      shortDescription: data.shortDescription || null,
      description: data.description || null,
      date: data.date,
      startDate: data.startDate || data.date,
      endDate: data.endDate || null,
      datePrecision: data.datePrecision,
      startTime: data.startTime || null,
      endTime: data.endTime || null,
      venue: data.venue || data.location || null,
      location: data.location || data.venue || null,
      organizer: data.organizer || null,
      category: data.category || "General",
      tags: data.tags || null,
      featured: data.featured,
      registrationEnabled: data.registrationEnabled,
      registrationDeadline: data.registrationDeadline || null,
      registrationUrl: data.registrationUrl || null,
      contactInfo: data.contactInfo || null,
      sourceType: data.sourceType,
      sourceUrl: data.sourceUrl || null,
      verificationStatus: data.verificationStatus,
      eventStatus: data.eventStatus,
      published: data.published,
      imageUrl: data.imageUrl || null,
      status: data.published ? "PUBLISHED" : "DRAFT",
    });

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: "Event created successfully!", id: newId };
  } catch (err: any) {
    console.error("createEventAction error:", err);
    return { success: false, error: err.message || "Failed to create event." };
  }
}

export async function updateEventAction(id: string, rawData: Record<string, unknown>) {
  try {
    await requireAdmin();

    const [existing] = await db.select().from(events).where(eq(events.id, id)).limit(1);
    if (!existing) return { success: false, error: "Event not found." };

    const parsed = eventSchema.safeParse(rawData);
    if (!parsed.success) {
      const firstErr = parsed.error.issues[0]?.message || "Invalid event input data.";
      return { success: false, error: firstErr };
    }

    const data = parsed.data;

    await db
      .update(events)
      .set({
        title: data.title,
        shortDescription: data.shortDescription || null,
        description: data.description || null,
        date: data.date,
        startDate: data.startDate || data.date,
        endDate: data.endDate || null,
        datePrecision: data.datePrecision,
        startTime: data.startTime || null,
        endTime: data.endTime || null,
        venue: data.venue || data.location || null,
        location: data.location || data.venue || null,
        organizer: data.organizer || null,
        category: data.category || "General",
        tags: data.tags || null,
        featured: data.featured,
        registrationEnabled: data.registrationEnabled,
        registrationDeadline: data.registrationDeadline || null,
        registrationUrl: data.registrationUrl || null,
        contactInfo: data.contactInfo || null,
        sourceType: data.sourceType,
        sourceUrl: data.sourceUrl || null,
        verificationStatus: data.verificationStatus,
        eventStatus: data.eventStatus,
        published: data.published,
        imageUrl: data.imageUrl || null,
        status: data.published ? "PUBLISHED" : "DRAFT",
        updatedAt: new Date(),
      })
      .where(eq(events.id, id));

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: "Event updated successfully!" };
  } catch (err: any) {
    console.error("updateEventAction error:", err);
    return { success: false, error: err.message || "Failed to update event." };
  }
}

export async function registerForEventAction(eventId: string) {
  try {
    const user = await requireUser();
    
    const [ev] = await db.select().from(events).where(eq(events.id, eventId)).limit(1);
    if (!ev || ev.deletedAt) return { success: false, error: "Event not found." };
    if (!ev.registrationEnabled) return { success: false, error: "Registrations are disabled for this event." };

    const existing = await db
      .select()
      .from(eventRegistrations)
      .where(and(eq(eventRegistrations.eventId, eventId), eq(eventRegistrations.userId, user.id)))
      .limit(1);

    if (existing.length > 0) {
      if (existing[0].status === "CONFIRMED") {
        return { success: false, error: "You are already registered for this event." };
      }
      await db
        .update(eventRegistrations)
        .set({ status: "CONFIRMED", registeredAt: new Date() })
        .where(eq(eventRegistrations.id, existing[0].id));
    } else {
      await db.insert(eventRegistrations).values({
        id: crypto.randomUUID(),
        eventId,
        userId: user.id,
        status: "CONFIRMED",
        registeredAt: new Date(),
      });
    }

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: "Registered successfully!" };
  } catch (err: any) {
    console.error("registerForEventAction error:", err);
    return { success: false, error: err.message || "Failed to register for event." };
  }
}

export async function unregisterForEventAction(eventId: string) {
  try {
    const user = await requireUser();
    
    const existing = await db
      .select()
      .from(eventRegistrations)
      .where(and(eq(eventRegistrations.eventId, eventId), eq(eventRegistrations.userId, user.id)))
      .limit(1);

    if (existing.length === 0 || existing[0].status === "CANCELLED") {
      return { success: false, error: "You are not currently registered for this event." };
    }

    await db
      .update(eventRegistrations)
      .set({ status: "CANCELLED" })
      .where(eq(eventRegistrations.id, existing[0].id));

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: "Registration cancelled." };
  } catch (err: any) {
    console.error("unregisterForEventAction error:", err);
    return { success: false, error: err.message || "Failed to cancel registration." };
  }
}

export async function toggleEventPublishAction(eventId: string) {
  try {
    await requireAdmin();

    const [ev] = await db.select().from(events).where(eq(events.id, eventId)).limit(1);
    if (!ev) return { success: false, error: "Event not found." };

    const newPublished = !ev.published;
    const newStatus = newPublished ? "PUBLISHED" : "DRAFT";

    await db
      .update(events)
      .set({ published: newPublished, status: newStatus, updatedAt: new Date() })
      .where(eq(events.id, eventId));

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: `Event ${newPublished ? "published" : "unpublished"}.` };
  } catch (err: any) {
    console.error("toggleEventPublishAction error:", err);
    return { success: false, error: err.message || "Failed to update publish state." };
  }
}

export async function toggleEventFeaturedAction(eventId: string) {
  try {
    await requireAdmin();

    const [ev] = await db.select().from(events).where(eq(events.id, eventId)).limit(1);
    if (!ev) return { success: false, error: "Event not found." };

    await db
      .update(events)
      .set({ featured: !ev.featured, updatedAt: new Date() })
      .where(eq(events.id, eventId));

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: `Spotlight status ${!ev.featured ? "enabled" : "disabled"}.` };
  } catch (err: any) {
    console.error("toggleEventFeaturedAction error:", err);
    return { success: false, error: err.message || "Failed to update spotlight state." };
  }
}

export async function deleteEventAction(eventId: string) {
  try {
    await requireAdmin();

    // Soft delete to prevent accidental data loss
    await db
      .update(events)
      .set({ deletedAt: new Date().toISOString(), published: false, status: "DRAFT" })
      .where(eq(events.id, eventId));

    revalidatePath("/events");
    revalidatePath("/admin/events");
    return { success: true, message: "Event archived/deleted successfully." };
  } catch (err: any) {
    console.error("deleteEventAction error:", err);
    return { success: false, error: err.message || "Failed to delete event." };
  }
}
