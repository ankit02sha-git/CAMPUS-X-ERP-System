"use server";
import { and, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/server/db";
import { feeStructures, feeDueRules, feePayments } from "@/server/db/schema";
import { requireAdmin } from "@/server/guards";
import type { FormState } from "@/actions/auth";

export async function saveFeeStructureAction(_: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const id = String(fd.get("id") || "").trim();
    const courseId = String(fd.get("courseId") || "").trim();
    const academicSession = String(fd.get("academicSession") || "2026-27").trim();
    const admissionFee = Number(fd.get("admissionFee") || 2000);
    const tuitionFee = Number(fd.get("tuitionFee") || 0);
    const studentDevelopmentFee = Number(fd.get("studentDevelopmentFee") || 1000);
    const universityExamFee = String(fd.get("universityExamFee") || "AS_PER_UNIVERSITY").trim();

    if (!courseId) return { error: "Course ID missing." };

    if (id) {
      await db
        .update(feeStructures)
        .set({
          admissionFee,
          tuitionFee,
          studentDevelopmentFee,
          universityExamFee,
        })
        .where(eq(feeStructures.id, id));
    } else {
      await db.insert(feeStructures).values({
        courseId,
        academicSession,
        admissionFee,
        tuitionFee,
        studentDevelopmentFee,
        universityExamFee,
      });
    }

    revalidatePath("/admin/fees");
    revalidatePath("/fees");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    console.error(e);
    return { error: "Failed to save fee structure." };
  }
}

export async function saveFeeDueRuleAction(_: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const id = String(fd.get("id") || "").trim();
    const courseId = String(fd.get("courseId") || "").trim();
    const academicSession = String(fd.get("academicSession") || "2026-27").trim();
    const dueDate = String(fd.get("dueDate") || "2026-10-15").trim();
    const fineType = String(fd.get("fineType") || "PER_DAY").trim() as "NONE" | "PER_DAY" | "FIXED" | "PERCENTAGE";
    const fineValue = Number(fd.get("fineValue") || 50);
    const maxFine = Number(fd.get("maxFine") || 2500);

    if (!courseId) return { error: "Course ID missing." };

    if (id) {
      await db
        .update(feeDueRules)
        .set({
          dueDate,
          fineType,
          fineValue,
          maxFine,
        })
        .where(eq(feeDueRules.id, id));
    } else {
      await db.insert(feeDueRules).values({
        courseId,
        academicSession,
        dueDate,
        fineType,
        fineValue,
        maxFine,
      });
    }

    revalidatePath("/admin/fees");
    revalidatePath("/fees");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    console.error(e);
    return { error: "Failed to save fee due rule." };
  }
}

export async function recordPaymentAction(_: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const paymentId = String(fd.get("paymentId") || "").trim();
    const studentId = String(fd.get("studentId") || "").trim();
    const feeStructureId = String(fd.get("feeStructureId") || "").trim();
    const amount = Number(fd.get("amount") || 0);
    const feeType = String(fd.get("feeType") || "TUITION_FEE").trim();
    const paymentDate = String(fd.get("paymentDate") || new Date().toISOString().slice(0, 10)).trim();
    const paymentMethod = String(fd.get("paymentMethod") || "UPI").trim();
    const notes = String(fd.get("notes") || "").trim();

    if (!studentId || !feeStructureId || amount <= 0) {
      return { error: "Please enter a valid student, fee structure, and positive amount." };
    }

    if (paymentId) {
      await db
        .update(feePayments)
        .set({
          amount,
          feeType,
          paymentDate,
          paymentMethod,
          notes: notes || null,
        })
        .where(eq(feePayments.id, paymentId));
    } else {
      const randomSuffix = Math.floor(100000 + Math.random() * 900000);
      const receiptNo = `SHC-REC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const txnId = `TXN-${new Date().getFullYear()}-${paymentMethod}-${randomSuffix}`;

      await db.insert(feePayments).values({
        studentId,
        feeStructureId,
        amount,
        feeType,
        paymentDate,
        paymentMethod,
        transactionId: txnId,
        receiptNumber: receiptNo,
        status: "PAID",
        notes: notes || "Recorded via Admin Panel",
      });
    }

    revalidatePath("/admin/fees");
    revalidatePath("/fees");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    console.error(e);
    return { error: "Failed to record payment." };
  }
}

export async function deletePaymentAction(paymentId: string) {
  await requireAdmin();
  await db.delete(feePayments).where(eq(feePayments.id, paymentId));
  revalidatePath("/admin/fees");
  revalidatePath("/fees");
}
