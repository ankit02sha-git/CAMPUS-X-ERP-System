"use server";
import { eq, getTableColumns } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/server/db";
import { announcements, assignments, canteenItems, courses, events, notes, studentsMaster, timetable, users } from "@/server/db/schema";
import { AuthError, requireAdmin } from "@/server/guards";
import { notifyCohort } from "@/server/notify";
import { ENTITIES } from "@/server/admin/registry";
import type { FormState } from "@/actions/auth";

// Form checkboxes arrive as "on"; empty strings become undefined so optional fields validate.
function normalize(fd: FormData, checkboxes: string[]) {
  const o: Record<string, unknown> = {};
  for (const [k, v] of fd.entries()) if (typeof v === "string") o[k] = v;
  for (const c of checkboxes) o[c] = fd.get(c) === "on";
  return o;
}
const istToDate = (v: string) => new Date(/[zZ+]|-\d\d:\d\d$/.test(v) ? v : `${v.length === 16 ? v + ":00" : v}+05:30`);

export async function saveEntity(entityKey: string, id: string | null, _: FormState, fd: FormData): Promise<FormState> {
  try {
    const admin = await requireAdmin();
    const ent = ENTITIES[entityKey];
    if (!ent) return { error: "Unknown section." };
    const checkboxes = ent.fields.filter((f) => f.type === "checkbox").map((f) => f.name);
    const parsed = ent.schema.safeParse(normalize(fd, checkboxes));
    if (!parsed.success) return { fieldErrors: Object.fromEntries(parsed.error.issues.map((i) => [String(i.path[0]), i.message])) };
    const d = parsed.data as Record<string, unknown>;
    // On edit, cleared optional inputs must become NULL (drizzle ignores undefined).
    if (id) for (const f of ent.fields) if (d[f.name] === undefined) d[f.name] = null;

    if (entityKey === "courses") {
      const [c] = id ? await db.update(courses).set(d as never).where(eq(courses.id, id)).returning() : await db.insert(courses).values(d as never).returning();
      void c;
    } else if (entityKey === "timetable") {
      const [row] = id ? await db.update(timetable).set(d as never).where(eq(timetable.id, id)).returning() : await db.insert(timetable).values(d as never).returning();
      await notifyCohort(row.courseId, row.semester, { type: "TIMETABLE_UPDATE", title: "Timetable updated", body: `${row.subject} — ${row.day.toLowerCase()} ${row.startTime}`, link: "/timetable" });
    } else if (entityKey === "notes") {
      const v = { ...d, uploadedById: admin.id };
      if (id) await db.update(notes).set(d as never).where(eq(notes.id, id)); else await db.insert(notes).values(v as never);
    } else if (entityKey === "assignments") {
      const v = { ...d, dueDate: istToDate(String(d.dueDate)) };
      if (Number.isNaN(v.dueDate.getTime())) return { fieldErrors: { dueDate: "Invalid date" } };
      const [row] = id ? await db.update(assignments).set(v as never).where(eq(assignments.id, id)).returning() : await db.insert(assignments).values(v as never).returning();
      if (!id) await notifyCohort(row.courseId, row.semester, { type: "ASSIGNMENT_ADDED", title: `New assignment: ${row.title}`, body: row.subject, link: "/assignments" });
    } else if (entityKey === "events") {
      const [row] = id ? await db.update(events).set(d as never).where(eq(events.id, id)).returning() : await db.insert(events).values(d as never).returning();
      if (!id && row.status === "PUBLISHED") await notifyCohort(null, null, { type: "EVENT_ADDED", title: `New event: ${row.title}`, body: row.date, link: `/events?id=${row.id}` });
    } else if (entityKey === "announcements") {
      const prev = id ? (await db.select().from(announcements).where(eq(announcements.id, id)).limit(1))[0] : null;
      const publishing = d.published === true && !prev?.published;
      const v = { ...d, ...(publishing ? { publishedAt: new Date() } : {}), ...(!id ? { createdById: admin.id } : {}) };
      const [row] = id ? await db.update(announcements).set(v as never).where(eq(announcements.id, id)).returning() : await db.insert(announcements).values(v as never).returning();
      if (publishing) await notifyCohort(null, null, { type: "ANNOUNCEMENT", title: row.title, body: row.content.slice(0, 140), link: `/announcements?id=${row.id}` });
    } else if (entityKey === "canteen") {
      if (id) await db.update(canteenItems).set(d as never).where(eq(canteenItems.id, id)); else await db.insert(canteenItems).values(d as never);
    }
    revalidatePath(`/admin/${entityKey}`); revalidatePath("/dashboard");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    if (e instanceof AuthError) return { error: "You don't have permission to do that." };
    console.error(e);
    const msg = String((e as { cause?: { message?: string }; message?: string })?.cause?.message ?? (e as Error)?.message ?? "");
    return { error: /UNIQUE constraint/i.test(msg) ? "That value already exists." : "Couldn't save. Please check the details and try again." };
  }
}

export async function deleteEntity(entityKey: string, id: string) {
  await requireAdmin();
  const ent = ENTITIES[entityKey];
  if (!ent) return;
  const cols = getTableColumns(ent.table) as unknown as { id: never };
  await db.delete(ent.table).where(eq(cols.id, id));
  revalidatePath(`/admin/${entityKey}`);
}

export async function togglePublish(id: string, published: boolean) {
  await requireAdmin();
  await db.update(announcements).set({ published, ...(published ? { publishedAt: new Date() } : {}) }).where(eq(announcements.id, id));
  revalidatePath("/admin/announcements");
}

export async function setUserActive(userId: string, active: boolean) {
  const me = await requireAdmin();
  if (me.id === userId) return; // never lock yourself out
  await db.update(users).set({ active }).where(eq(users.id, userId));
  revalidatePath("/admin/users");
}
export async function setUserRole(userId: string, role: "STUDENT" | "ADMIN") {
  const me = await requireAdmin();
  if (me.id === userId) return; // never demote yourself
  await db.update(users).set({ role }).where(eq(users.id, userId));
  revalidatePath("/admin/users");
}
export async function setUserCohort(userId: string, courseId: string, semester: number) {
  await requireAdmin();
  if (!(semester >= 1 && semester <= 8)) return;
  await db.update(users).set({ courseId, semester }).where(eq(users.id, userId));
  revalidatePath("/admin/users");
}

export async function saveStudentMaster(id: string | null, _: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const studentId = String(fd.get("studentId") || "").trim().toUpperCase();
    const fullName = String(fd.get("fullName") || "").trim();
    const registeredMobile = String(fd.get("registeredMobile") || "").trim();
    const courseId = String(fd.get("courseId") || "").trim();
    const semester = Number(fd.get("semester") || 1);
    const department = String(fd.get("department") || "").trim();
    const academicYear = String(fd.get("academicYear") || "").trim();
    const section = String(fd.get("section") || "").trim();
    const rollNumber = String(fd.get("rollNumber") || "").trim();
    const dob = String(fd.get("dob") || "").trim();
    const admissionSession = String(fd.get("admissionSession") || "").trim();

    if (!studentId || !fullName || !registeredMobile || !courseId) {
      return { error: "Student ID, Full Name, Mobile, and Course are required fields." };
    }

    const payload = {
      studentId,
      fullName,
      registeredMobile,
      courseId,
      semester,
      department: department || null,
      academicYear: academicYear || null,
      section: section || null,
      rollNumber: rollNumber || null,
      dob: dob || null,
      admissionSession: admissionSession || null,
    };

    if (id) {
      await db.update(studentsMaster).set(payload).where(eq(studentsMaster.id, id));
      // Sync associated active user account if present
      await db.update(users).set({
        name: fullName,
        registeredMobile,
        courseId,
        semester,
        section: section || null,
        department: department || null,
        academicYear: academicYear || null,
        rollNumber: rollNumber || null,
      }).where(eq(users.studentId, studentId));
    } else {
      await db.insert(studentsMaster).values({
        ...payload,
        activationStatus: "NOT_ACTIVATED",
        status: "ACTIVE",
      });
    }

    revalidatePath("/admin/users");
    return { fieldErrors: { _ok: "1" } };
  } catch (e) {
    console.error("saveStudentMaster error:", e);
    return { error: "Failed to save student master record. Check for duplicate Student ID." };
  }
}

export async function resetStudentActivation(masterId: string) {
  await requireAdmin();
  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.id, masterId)).limit(1);
  if (!sm) return;

  // Reset activation status in master table
  await db.update(studentsMaster).set({ activationStatus: "NOT_ACTIVATED" }).where(eq(studentsMaster.id, masterId));

  // If user account exists, set active to false so they must reactivate
  await db.update(users).set({ active: false, activationStatus: "NOT_ACTIVATED" }).where(eq(users.studentId, sm.studentId));

  revalidatePath("/admin/users");
}

export async function toggleStudentStatus(masterId: string, currentStatus: string) {
  await requireAdmin();
  const newStatus = currentStatus === "ACTIVE" ? "DISABLED" : "ACTIVE";
  const [sm] = await db.select().from(studentsMaster).where(eq(studentsMaster.id, masterId)).limit(1);
  if (!sm) return;

  await db.update(studentsMaster).set({ status: newStatus }).where(eq(studentsMaster.id, masterId));

  // Sync user table active flag
  await db.update(users).set({ active: newStatus === "ACTIVE" }).where(eq(users.studentId, sm.studentId));

  revalidatePath("/admin/users");
}

export async function deleteStudentMaster(masterId: string) {
  await requireAdmin();
  await db.delete(studentsMaster).where(eq(studentsMaster.id, masterId));
  revalidatePath("/admin/users");
}

