"use server";
import { and, eq, or, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/server/db";
import { lostImages, lostMessages, lostPosts, lostReports, lostResponses, lostThreads, users } from "@/server/db/schema";
import { AuthError, requireAdmin, requireUser } from "@/server/guards";
import { notifyUser, notifyUsers } from "@/server/notify";
import { rateLimit } from "@/server/ratelimit";
import { lostPostSchema, lostResponseSchema, messageSchema, reportSchema, categorySchema } from "@/lib/validators";
import type { FormState } from "@/actions/auth";

const fieldErrs = (issues: { path: PropertyKey[]; message: string }[]) => Object.fromEntries(issues.map((i) => [String(i.path[0]), i.message]));
const guard = (e: unknown): { error: string } => (e instanceof AuthError ? { error: e.code === "FORBIDDEN" ? "You don't have permission to do that." : "Please sign in again." } : (console.error(e), { error: "Something went wrong. Please try again." }));

export async function createLostPost(_: FormState, fd: FormData): Promise<FormState> {
  let id: string;
  try {
    const u = await requireUser();
    if (!rateLimit(`lostpost:${u.id}`, 10, 60 * 60_000)) return { error: "You're posting too quickly. Please wait a while." };
    const parsed = lostPostSchema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) return { fieldErrors: fieldErrs(parsed.error.issues) };
    const { imageUrl, ...d } = parsed.data;
    const [p] = await db.insert(lostPosts).values({ ...d, authorId: u.id }).returning({ id: lostPosts.id });
    if (imageUrl) await db.insert(lostImages).values({ postId: p.id, url: imageUrl });
    id = p.id;
  } catch (e) { return guard(e); }
  revalidatePath("/lost-found");
  redirect(`/lost-found/${id}`);
}

export async function updateLostPost(postId: string, _: FormState, fd: FormData): Promise<FormState> {
  try {
    const u = await requireUser();
    const [post] = await db.select().from(lostPosts).where(eq(lostPosts.id, postId)).limit(1);
    if (!post || (post.authorId !== u.id && u.role !== "ADMIN")) return { error: "You can't edit this post." };
    const parsed = lostPostSchema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) return { fieldErrors: fieldErrs(parsed.error.issues) };
    const { imageUrl, kind: _k, ...d } = parsed.data; void _k;
    await db.update(lostPosts).set(d).where(eq(lostPosts.id, postId));
    await db.delete(lostImages).where(eq(lostImages.postId, postId));
    if (imageUrl) await db.insert(lostImages).values({ postId, url: imageUrl });
  } catch (e) { return guard(e); }
  revalidatePath("/lost-found");
  redirect(`/lost-found/${postId}`);
}

export async function deleteLostPost(postId: string) {
  const u = await requireUser();
  const [post] = await db.select().from(lostPosts).where(eq(lostPosts.id, postId)).limit(1);
  if (!post || (post.authorId !== u.id && u.role !== "ADMIN")) throw new AuthError("FORBIDDEN");
  await db.delete(lostPosts).where(eq(lostPosts.id, postId));
  revalidatePath("/lost-found"); revalidatePath("/admin/lost-found");
  redirect("/lost-found");
}

export async function setLostStatus(postId: string, status: "LOST" | "POSSIBLY_FOUND" | "FOUND" | "CLOSED") {
  const u = await requireUser();
  const [post] = await db.select().from(lostPosts).where(eq(lostPosts.id, postId)).limit(1);
  if (!post) return;
  const isOwner = post.authorId === u.id;
  if (!isOwner && u.role !== "ADMIN") throw new AuthError("FORBIDDEN");
  await db.update(lostPosts).set({ status }).where(eq(lostPosts.id, postId));
  if (status === "FOUND") {
    const rs = await db.select({ userId: lostResponses.userId }).from(lostResponses).where(eq(lostResponses.postId, postId));
    await notifyUsers([...new Set(rs.map((r) => r.userId))].filter((i) => i !== u.id), { type: "LOST_FOUND", title: `"${post.title}" was marked as found`, body: "Thanks for helping out!", link: `/lost-found/${postId}` });
  }
  revalidatePath(`/lost-found/${postId}`); revalidatePath("/lost-found"); revalidatePath("/admin/lost-found");
}

export async function setLostHidden(postId: string, hidden: boolean) {
  await requireAdmin();
  await db.update(lostPosts).set({ hidden }).where(eq(lostPosts.id, postId));
  revalidatePath("/lost-found"); revalidatePath("/admin/lost-found");
}

async function ensureThread(postId: string, ownerId: string, otherId: string) {
  const [t] = await db.select().from(lostThreads).where(and(eq(lostThreads.postId, postId), eq(lostThreads.ownerId, ownerId), eq(lostThreads.otherId, otherId))).limit(1);
  if (t) return t;
  const [n] = await db.insert(lostThreads).values({ postId, ownerId, otherId }).onConflictDoNothing().returning();
  return n ?? (await db.select().from(lostThreads).where(and(eq(lostThreads.postId, postId), eq(lostThreads.ownerId, ownerId), eq(lostThreads.otherId, otherId))).limit(1))[0];
}

/** "I Found This" (or "This is mine" on a FOUND notice). Stores response, opens a private thread, notifies the poster. */
export async function submitResponse(_: FormState, fd: FormData): Promise<FormState> {
  try {
    const u = await requireUser();
    if (!rateLimit(`resp:${u.id}`, 15, 60 * 60_000)) return { error: "Too many responses. Please wait a while." };
    const parsed = lostResponseSchema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) return { fieldErrors: fieldErrs(parsed.error.issues) };
    const d = parsed.data;
    const [post] = await db.select().from(lostPosts).where(eq(lostPosts.id, d.postId)).limit(1);
    if (!post || post.hidden) return { error: "This notice is no longer available." };
    if (post.authorId === u.id) return { error: "You can't respond to your own notice." };
    if (post.status === "FOUND" || post.status === "CLOSED") return { error: "This notice is already resolved." };
    await db.insert(lostResponses).values({ postId: d.postId, userId: u.id, message: d.message, foundAt: d.foundAt, foundOn: d.foundOn, imageUrl: d.imageUrl, contactInfo: d.contactInfo });
    if (post.status === "LOST") await db.update(lostPosts).set({ status: "POSSIBLY_FOUND" }).where(eq(lostPosts.id, post.id));
    const t = await ensureThread(post.id, post.authorId, u.id);
    await db.insert(lostMessages).values({ threadId: t.id, senderId: u.id, body: d.message });
    await notifyUser(post.authorId, { type: "LOST_RESPONSE", title: post.kind === "LOST" ? `Someone may have found "${post.title}"` : `Someone says "${post.title}" is theirs`, body: d.message.slice(0, 140), link: `/lost-found/${post.id}` });
  } catch (e) { return guard(e); }
  revalidatePath(`/lost-found/${(fd.get("postId") as string) ?? ""}`);
  return { error: undefined, fieldErrors: { _ok: "1" } };
}

/** "Contact Poster": opens (or reuses) a private thread with an optional first message. */
export async function contactPoster(postId: string, _: FormState, fd: FormData): Promise<FormState> {
  let threadId: string;
  try {
    const u = await requireUser();
    const body = messageSchema.shape.body.safeParse(fd.get("body"));
    if (!body.success) return { fieldErrors: { body: "Write a short message." } };
    if (!rateLimit(`msg:${u.id}`, 40, 60 * 60_000)) return { error: "Too many messages. Please wait." };
    const [post] = await db.select().from(lostPosts).where(eq(lostPosts.id, postId)).limit(1);
    if (!post || post.hidden) return { error: "This notice is no longer available." };
    if (post.authorId === u.id) return { error: "This is your own notice." };
    const t = await ensureThread(post.id, post.authorId, u.id);
    await db.insert(lostMessages).values({ threadId: t.id, senderId: u.id, body: body.data });
    await notifyUser(post.authorId, { type: "LOST_MESSAGE", title: `New message about "${post.title}"`, body: body.data.slice(0, 140), link: `/lost-found/${post.id}?thread=${t.id}` });
    threadId = t.id;
  } catch (e) { return guard(e); }
  redirect(`/lost-found/${postId}?thread=${threadId}`);
}

export async function sendMessage(threadId: string, body: string): Promise<{ error?: string }> {
  try {
    const u = await requireUser();
    const parsed = messageSchema.safeParse({ threadId, body });
    if (!parsed.success) return { error: "Message can't be empty." };
    if (!rateLimit(`msg:${u.id}`, 60, 60 * 60_000)) return { error: "Too many messages. Please wait." };
    const [t] = await db.select().from(lostThreads).where(and(eq(lostThreads.id, threadId), or(eq(lostThreads.ownerId, u.id), eq(lostThreads.otherId, u.id)))).limit(1);
    if (!t) return { error: "Conversation not found." };
    await db.insert(lostMessages).values({ threadId, senderId: u.id, body: parsed.data.body });
    const to = t.ownerId === u.id ? t.otherId : t.ownerId;
    const [post] = await db.select({ title: lostPosts.title }).from(lostPosts).where(eq(lostPosts.id, t.postId)).limit(1);
    await notifyUser(to, { type: "LOST_MESSAGE", title: `New message about "${post?.title ?? "your notice"}"`, body: parsed.data.body.slice(0, 140), link: `/lost-found/${t.postId}?thread=${t.id}` });
    return {};
  } catch (e) { return guard(e); }
}

export async function reportPost(_: FormState, fd: FormData): Promise<FormState> {
  try {
    const u = await requireUser();
    const parsed = reportSchema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) return { fieldErrors: fieldErrs(parsed.error.issues) };
    if (!rateLimit(`report:${u.id}`, 10, 60 * 60_000)) return { error: "Too many reports." };
    const dup = await db.select({ n: sql<number>`count(*)` }).from(lostReports).where(and(eq(lostReports.postId, parsed.data.postId), eq(lostReports.reporterId, u.id), eq(lostReports.status, "OPEN")));
    if (Number(dup[0].n) > 0) return { error: "You've already reported this post. Admins will review it." };
    await db.insert(lostReports).values({ postId: parsed.data.postId, reporterId: u.id, reason: parsed.data.reason });
    const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, "ADMIN"));
    await notifyUsers(admins.map((a) => a.id), { type: "ADMIN_MESSAGE", title: "A Lost & Found post was reported", body: parsed.data.reason.slice(0, 140), link: "/admin/lost-found" });
  } catch (e) { return guard(e); }
  return { fieldErrors: { _ok: "1" } };
}

export async function resolveReport(reportId: string, status: "RESOLVED" | "DISMISSED", resolution: string) {
  await requireAdmin();
  await db.update(lostReports).set({ status, resolution: resolution.slice(0, 500) }).where(eq(lostReports.id, reportId));
  revalidatePath("/admin/lost-found");
}

export async function addCategory(_: FormState, fd: FormData): Promise<FormState> {
  try {
    await requireAdmin();
    const p = categorySchema.safeParse(Object.fromEntries(fd));
    if (!p.success) return { error: "Enter a category name." };
    const { lostCategories } = await import("@/server/db/schema");
    const slug = p.data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    await db.insert(lostCategories).values({ name: p.data.name, slug }).onConflictDoNothing();
    revalidatePath("/admin/lost-found");
  } catch (e) { return guard(e); }
}
export async function toggleCategory(id: string, active: boolean) {
  await requireAdmin();
  const { lostCategories } = await import("@/server/db/schema");
  await db.update(lostCategories).set({ active }).where(eq(lostCategories.id, id));
  revalidatePath("/admin/lost-found");
}
