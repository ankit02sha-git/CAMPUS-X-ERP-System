"use server";

import { requireUser, requireAdmin } from "@/server/guards";
import { getStudentAttendanceOverview, getAdminAttendanceClassSheet, saveAdminAttendanceSession } from "@/server/attendance";
import { revalidatePath } from "next/cache";

export async function fetchMyAttendanceAction(semester?: number, thresholdPct?: number) {
  const user = await requireUser();
  return await getStudentAttendanceOverview(user.id, user.courseId, user.semester, semester, thresholdPct);
}

export async function fetchAdminAttendanceSheetAction(
  courseId: string,
  semester: number,
  section: string,
  subjectId: string,
  dateStr: string
) {
  await requireAdmin();
  return await getAdminAttendanceClassSheet(courseId, semester, section, subjectId, dateStr);
}

export async function saveAdminAttendanceAction(
  courseId: string,
  semester: number,
  section: string,
  subjectId: string,
  dateStr: string,
  records: Array<{ userId: string; status: "PRESENT" | "ABSENT" | "LATE" }>
) {
  const admin = await requireAdmin();
  const res = await saveAdminAttendanceSession(courseId, semester, section, subjectId, dateStr, records, admin.id);
  revalidatePath("/attendance");
  revalidatePath("/admin/attendance");
  return res;
}

export async function fetchAdminDepartmentOverviewAction(courseId?: string, semester?: number) {
  await requireAdmin();
  const { getAdminDepartmentAttendanceOverview } = await import("@/server/attendance");
  return await getAdminDepartmentAttendanceOverview(courseId, semester);
}

export async function fetchAdminTimetableSubjectsAction(courseId: string, semester: number) {
  await requireAdmin();
  const { getAdminTimetableSubjects } = await import("@/server/attendance");
  return await getAdminTimetableSubjects(courseId, semester);
}
