"use server";

import { getAdminBirthdayRecords, getTodaysBirthdayGreetings } from "@/server/birthday";
import { requireAdmin, requireUser } from "@/server/guards";

/**
 * Action to fetch today's active student birthday greetings.
 * Strict Privacy Enforcement: Returns ONLY student name, greeting message, and student ID for dismissal tracking.
 */
export async function fetchTodaysBirthdaysAction() {
  await requireUser();
  return await getTodaysBirthdayGreetings();
}

/**
 * Admin action to fetch full birthday directory with age, full DOB, course details, and filters.
 */
export async function fetchAdminBirthdaysAction(monthFilter?: number) {
  await requireAdmin();
  return await getAdminBirthdayRecords(monthFilter);
}
