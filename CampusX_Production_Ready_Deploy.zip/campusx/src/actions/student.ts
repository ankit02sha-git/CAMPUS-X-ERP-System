"use server";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/server/db";
import { announcementReads, assignmentSubmissions, assignments, users } from "@/server/db/schema";
import { requireUser } from "@/server/guards";
import { profileSchema } from "@/lib/validators";
import type { FormState } from "@/actions/auth";

export async function setAssignmentStatus(assignmentId: string, status: "PENDING" | "SUBMITTED" | "COMPLETED") {
  const u = await requireUser();
  const [a] = await db.select({ id: assignments.id, c: assignments.courseId, s: assignments.semester }).from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
  if (!a || a.c !== u.courseId || a.s !== u.semester) return; // only your own cohort's assignments
  await db.insert(assignmentSubmissions).values({ assignmentId, userId: u.id, status }).onConflictDoUpdate({ target: [assignmentSubmissions.assignmentId, assignmentSubmissions.userId], set: { status } });
  revalidatePath("/assignments"); revalidatePath("/dashboard");
}
export async function markAnnouncementRead(announcementId: string) {
  const u = await requireUser();
  await db.insert(announcementReads).values({ announcementId, userId: u.id }).onConflictDoNothing();
  revalidatePath("/announcements");
}
export async function updateProfile(_: FormState, fd: FormData): Promise<FormState> {
  const u = await requireUser();
  const p = profileSchema.safeParse({ name: fd.get("name"), showStudentId: fd.get("showStudentId") === "on", image: fd.get("image") });
  if (!p.success) return { error: "Please check your details." };
  await db.update(users).set({ name: p.data.name, showStudentId: p.data.showStudentId, image: p.data.image ?? null }).where(eq(users.id, u.id));
  revalidatePath("/profile");
  return { fieldErrors: { _ok: "1" } };
}
