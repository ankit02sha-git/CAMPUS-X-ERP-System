// Verified public facts from https://www.studyhallcollege.org/ (checked Sep 2026). Nothing here is invented.
// Add further verified facilities when the admin provides them.
export const COLLEGE = {
  name: "Study Hall College",
  established: 2016,
  city: "Lucknow, Uttar Pradesh",
  address: "Piparsand–Kanpur Road, Lucknow, UP, India",
  phone: "+91-8400078621",
  email: "info@studyhallcollege.org",
  affiliation: "University of Lucknow",
  website: "https://www.studyhallcollege.org/",
};
export const FACILITIES = [
  { key: "library", title: "Library", body: "A campus library for study and reference." },
  { key: "labs", title: "Computer Labs", body: "Computer laboratories supporting practical coursework." },
  { key: "media", title: "Media Studio", body: "A media studio for journalism and mass communication practice." },
  { key: "sports", title: "Indoor & Outdoor Sports", body: "Indoor and outdoor sports arenas." },
] as const;
export const CLUBS = ["Cultural", "Media", "Literary", "Sports", "Drama", "AI & IT"];
export const COURSE_INFO: Record<string, string> = {
  BCA: "Three-year undergraduate programme in computer applications.",
  BBA: "Three-year undergraduate programme in business administration.",
  BCOM: "Three-year undergraduate programme in commerce.",
  BJMC: "Three-year undergraduate programme in journalism and mass communication (listed as BAJMC on the official site).",
};
