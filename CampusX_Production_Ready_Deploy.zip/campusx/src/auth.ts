import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { eq, or } from "drizzle-orm";
import { db } from "@/server/db";
import { users } from "@/server/db/schema";
import { rateLimit } from "@/server/ratelimit";
import { authConfig } from "./auth.config";

export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  providers: [
    Credentials({
      async authorize(raw) {
        const rawObj = raw as Record<string, unknown>;
        const identifier = String(rawObj.studentId || rawObj.email || rawObj.emailOrId || "").trim();
        const password = String(rawObj.password || "").trim();
        if (!identifier || !password) return null;

        if (!rateLimit(`login:${identifier.toLowerCase()}`, 10, 15 * 60_000)) return null;

        const [u] = await db
          .select()
          .from(users)
          .where(or(eq(users.studentId, identifier), eq(users.email, identifier.toLowerCase())))
          .limit(1);

        const ok = await bcrypt.compare(
          password,
          u?.passwordHash ?? "$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi"
        );

        if (!u || !ok || !u.active) return null;
        return { id: u.id, name: u.name, email: u.email, role: u.role, image: u.image, studentId: u.studentId };
      },
    }),
  ],
});
