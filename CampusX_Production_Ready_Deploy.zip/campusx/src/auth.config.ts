import type { NextAuthConfig } from "next-auth";

// Edge-safe config (no DB). Used by middleware for optimistic redirects.
// Real authorization is always re-checked server-side in src/server/guards.ts.
export const authConfig = {
  pages: { signIn: "/login" },
  session: { strategy: "jwt", maxAge: 60 * 60 * 24 * 7 },
  providers: [],
  callbacks: {
    authorized({ auth, request }) {
      const { pathname } = request.nextUrl;
      const isAuthPage = pathname === "/login" || pathname === "/activate" || pathname === "/forgot-password" || pathname === "/register";
      const isPublic = pathname === "/" || isAuthPage;

      if (isAuthPage && auth?.user) {
        const dest = auth.user.role === "ADMIN" ? "/admin" : "/dashboard";
        return Response.redirect(new URL(dest, request.nextUrl));
      }

      if (isPublic) return true;
      if (!auth?.user) return false;

      // Role isolation checks
      if (pathname.startsWith("/admin") && auth.user.role !== "ADMIN") {
        return Response.redirect(new URL("/dashboard", request.nextUrl));
      }

      return true;
    },
    jwt({ token, user }) {
      if (user) {
        token.id = user.id as string;
        token.role = (user as { role: "STUDENT" | "ADMIN" }).role;
        token.studentId = (user as { studentId?: string | null }).studentId ?? null;
      }
      return token;
    },
    session({ session, token }) {
      if (token.id) {
        session.user.id = token.id as string;
        session.user.role = token.role as "STUDENT" | "ADMIN";
        session.user.studentId = (token.studentId as string | null) ?? null;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;
