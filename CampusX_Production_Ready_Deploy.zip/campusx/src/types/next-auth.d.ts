import "next-auth";

declare module "next-auth" {
  interface User {
    role?: "STUDENT" | "ADMIN";
    studentId?: string | null;
  }
  interface Session {
    user: {
      id: string;
      role: "STUDENT" | "ADMIN";
      studentId?: string | null;
      name?: string | null;
      email?: string | null;
      image?: string | null;
    };
  }
}
