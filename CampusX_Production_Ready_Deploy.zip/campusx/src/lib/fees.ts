import { db } from "@/server/db";
import { eq, and, inArray } from "drizzle-orm";
import {
  courses,
  users,
  feeStructures,
  feeDueRules,
  feePayments,
  type FeeStructure,
  type FeeDueRule,
  type FeePayment,
} from "@/server/db/schema";

export const OFFICIAL_FEE_DEFAULTS = [
  {
    code: "BCA",
    admissionFee: 2000,
    tuitionFee: 70000,
    studentDevelopmentFee: 1000,
    universityExamFee: "AS_PER_UNIVERSITY",
  },
  {
    code: "BBA",
    admissionFee: 2000,
    tuitionFee: 62000,
    studentDevelopmentFee: 1000,
    universityExamFee: "AS_PER_UNIVERSITY",
  },
  {
    code: "BCOM",
    admissionFee: 2000,
    tuitionFee: 24000,
    studentDevelopmentFee: 1000,
    universityExamFee: "AS_PER_UNIVERSITY",
  },
  {
    code: "BJMC",
    admissionFee: 2000,
    tuitionFee: 40000,
    studentDevelopmentFee: 1000,
    universityExamFee: "AS_PER_UNIVERSITY",
  },
];

export function computeKnownAnnualFee(fs: {
  admissionFee: number;
  tuitionFee: number;
  studentDevelopmentFee: number;
}): number {
  return fs.admissionFee + fs.tuitionFee + fs.studentDevelopmentFee;
}

export function computeLateFine(
  remainingAmount: number,
  rule: FeeDueRule | null,
  referenceDate: Date = new Date()
): { lateDays: number; lateFine: number } {
  if (!rule || !rule.active || remainingAmount <= 0) {
    return { lateDays: 0, lateFine: 0 };
  }

  const due = new Date(rule.dueDate);
  if (isNaN(due.getTime())) return { lateDays: 0, lateFine: 0 };

  // Set times to midnight for accurate date comparison
  const d1 = new Date(due.getFullYear(), due.getMonth(), due.getDate());
  const d2 = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), referenceDate.getDate());

  const diffTime = d2.getTime() - d1.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays <= 0) {
    return { lateDays: 0, lateFine: 0 };
  }

  let fine = 0;
  if (rule.fineType === "PER_DAY") {
    fine = diffDays * rule.fineValue;
  } else if (rule.fineType === "FIXED") {
    fine = rule.fineValue;
  }

  if (rule.maxFine && fine > rule.maxFine) {
    fine = rule.maxFine;
  }

  return { lateDays: diffDays, lateFine: Math.max(0, fine) };
}

export type StudentFeeSummary = {
  student: typeof users.$inferSelect;
  course: typeof courses.$inferSelect | null;
  feeStructure: FeeStructure | null;
  dueRule: FeeDueRule | null;
  knownAnnualFee: number;
  amountPaid: number;
  remainingAmount: number;
  paymentStatus: "PAID" | "PARTIALLY_PAID" | "UNPAID";
  progressPercentage: number;
  lateDays: number;
  lateFine: number;
  totalPayable: number;
  payments: FeePayment[];
};

export async function getStudentFeeSummary(studentId: string): Promise<StudentFeeSummary | null> {
  const [student] = await db.select().from(users).where(eq(users.id, studentId)).limit(1);
  if (!student) return null;

  let course = null;
  if (student.courseId) {
    [course] = await db.select().from(courses).where(eq(courses.id, student.courseId)).limit(1);
  }

  let feeStructure: FeeStructure | null = null;
  let dueRule: FeeDueRule | null = null;

  if (student.courseId) {
    [feeStructure] = await db
      .select()
      .from(feeStructures)
      .where(and(eq(feeStructures.courseId, student.courseId), eq(feeStructures.academicSession, "2026-27")))
      .limit(1);

    [dueRule] = await db
      .select()
      .from(feeDueRules)
      .where(and(eq(feeDueRules.courseId, student.courseId), eq(feeDueRules.academicSession, "2026-27")))
      .limit(1);
  }

  const payments = feeStructure
    ? await db
        .select()
        .from(feePayments)
        .where(
          and(
            eq(feePayments.studentId, studentId),
            inArray(feePayments.status, ["PAID", "ADJUSTED"])
          )
        )
    : [];

  const admissionFee = feeStructure?.admissionFee ?? 2000;
  const tuitionFee = feeStructure?.tuitionFee ?? 70000;
  const studentDevelopmentFee = feeStructure?.studentDevelopmentFee ?? 1000;
  const knownAnnualFee = admissionFee + tuitionFee + studentDevelopmentFee;

  const amountPaid = payments.reduce((sum, p) => sum + p.amount, 0);
  const remainingAmount = Math.max(0, knownAnnualFee - amountPaid);

  let paymentStatus: "PAID" | "PARTIALLY_PAID" | "UNPAID" = "UNPAID";
  if (amountPaid >= knownAnnualFee) {
    paymentStatus = "PAID";
  } else if (amountPaid > 0) {
    paymentStatus = "PARTIALLY_PAID";
  }

  const progressPercentage = Math.min(100, Math.round((amountPaid / knownAnnualFee) * 100));

  const { lateDays, lateFine } = computeLateFine(remainingAmount, dueRule);
  const totalPayable = remainingAmount + lateFine;

  return {
    student,
    course: course || null,
    feeStructure: feeStructure || null,
    dueRule: dueRule || null,
    knownAnnualFee,
    amountPaid,
    remainingAmount,
    paymentStatus,
    progressPercentage,
    lateDays,
    lateFine,
    totalPayable,
    payments,
  };
}
