import { z } from "zod";

const clean = (max: number, min = 1) => z.string().trim().min(min, "Required").max(max);
const withDefault = (max: number, d: string) => z.string().trim().max(max).optional().transform((v) => (v ? v : d));
const optional = (max: number) => z.string().trim().max(max).optional().transform((v) => (v ? v : undefined));
export const COURSE_CODES = ["BCA", "BBA", "BCOM", "BJMC"] as const;
export const DAYS = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"] as const;
export const MEALS = ["BREAKFAST", "LUNCH", "SNACKS", "BEVERAGES"] as const;
const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use HH:MM (24h)");
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date");
const url = z.string().max(500).refine((v) => v.startsWith("/api/files/") || /^https:\/\//.test(v), "Invalid file URL");

export const loginSchema = z.object({
  // Accepts Student ID or Email
  emailOrId: z.string().trim().min(1, "Student ID or Email is required").max(200),
  password: z.string().min(1, "Password is required").max(200),
});

export const studentLoginSchema = z.object({
  studentId: z.string().trim().min(1, "Student ID is required").max(50),
  password: z.string().min(1, "Password is required").max(200),
});

export const activateStep1Schema = z.object({
  studentId: z.string().trim().min(1, "Student ID is required").max(50),
});

export const verifyOtpSchema = z.object({
  studentId: z.string().trim().min(1, "Student ID is required").max(50),
  otp: z.string().trim().length(6, "OTP must be exactly 6 digits").regex(/^\d+$/, "OTP must contain numbers only"),
  type: z.enum(["ACTIVATION", "FORGOT_PASSWORD"]).default("ACTIVATION"),
});

export const activateCompleteSchema = z.object({
  studentId: z.string().trim().min(1, "Student ID is required").max(50),
  otp: z.string().trim().length(6, "OTP must be 6 digits"),
  password: z.string().min(6, "Password must be at least 6 characters").max(100),
});

export const forgotPasswordResetSchema = z.object({
  studentId: z.string().trim().min(1, "Student ID is required").max(50),
  otp: z.string().trim().length(6, "OTP must be 6 digits"),
  newPassword: z.string().min(6, "New Password must be at least 6 characters").max(100),
});

export const studentMasterSchema = z.object({
  studentId: clean(50, 2).transform((s) => s.toUpperCase()),
  fullName: clean(100, 2),
  registeredMobile: z.string().trim().min(10, "Valid 10+ digit mobile number required").max(20),
  courseId: clean(60),
  department: optional(100),
  academicYear: optional(40),
  semester: z.coerce.number().int().min(1).max(8),
  section: optional(20),
  rollNumber: optional(50),
  dob: optional(30),
  admissionSession: optional(50),
  status: z.enum(["ACTIVE", "DISABLED"]).default("ACTIVE"),
});

export const lostPostSchema = z.object({
  kind: z.enum(["LOST", "FOUND"]),
  title: clean(80, 2),
  categoryId: clean(60),
  description: clean(1000, 5),
  location: clean(120, 2),
  occurredOn: isoDate,
  approxTime: optional(40),
  details: optional(500),
  contactPref: z.enum(["IN_APP", "PICKUP_AT_OFFICE"]).default("IN_APP"),
  imageUrl: url.optional().or(z.literal("").transform(() => undefined)),
});
export const lostResponseSchema = z.object({
  postId: clean(60), message: clean(800, 3), foundAt: clean(160, 2), foundOn: isoDate,
  imageUrl: url.optional().or(z.literal("").transform(() => undefined)), contactInfo: optional(120),
});
export const messageSchema = z.object({ threadId: clean(60), body: clean(1000) });
export const reportSchema = z.object({ postId: clean(60), reason: clean(500, 5) });

export const courseSchema = z.object({ code: clean(10).transform((s) => s.toUpperCase()), name: clean(120), description: optional(500), semesters: z.coerce.number().int().min(1).max(10), active: z.coerce.boolean() });
export const timetableSchema = z.object({
  courseId: clean(60), semester: z.coerce.number().int().min(1).max(10), day: z.enum(DAYS),
  startTime: time, endTime: time, subject: clean(120), faculty: optional(120), room: optional(60),
}).refine((v) => v.startTime < v.endTime, { message: "End time must be after start time", path: ["endTime"] });
export const noteSchema = z.object({ title: clean(120), description: optional(500), courseId: clean(60), semester: z.coerce.number().int().min(1).max(10), subject: clean(120), fileUrl: url, fileName: optional(120), fileType: optional(60) });
export const assignmentSchema = z.object({ title: clean(120), description: optional(2000), courseId: clean(60), semester: z.coerce.number().int().min(1).max(10), subject: clean(120), dueDate: z.string().min(8), attachmentUrl: url.optional().or(z.literal("").transform(() => undefined)) });
export const eventSchema = z.object({
  title: clean(120),
  slug: optional(140),
  shortDescription: optional(300),
  description: optional(2000),
  date: isoDate,
  startDate: isoDate.optional().or(z.literal("").transform(() => undefined)),
  endDate: isoDate.optional().or(z.literal("").transform(() => undefined)),
  datePrecision: z.enum(["EXACT_DATE", "DATE_RANGE", "MONTH_ONLY", "TBD"]).default("EXACT_DATE"),
  startTime: time.optional().or(z.literal("").transform(() => undefined)),
  endTime: time.optional().or(z.literal("").transform(() => undefined)),
  venue: optional(160),
  location: optional(120),
  organizer: optional(120),
  category: withDefault(40, "General"),
  tags: optional(200),
  featured: z.coerce.boolean().default(false),
  registrationEnabled: z.coerce.boolean().default(false),
  registrationDeadline: isoDate.optional().or(z.literal("").transform(() => undefined)),
  registrationUrl: z.string().max(500).optional().or(z.literal("").transform(() => undefined)),
  contactInfo: optional(200),
  sourceType: z.enum(["USER_SUPPLIED", "OFFICIAL_WEBSITE", "ADMIN_ENTERED", "VERIFIED"]).default("ADMIN_ENTERED"),
  sourceUrl: z.string().max(500).optional().or(z.literal("").transform(() => undefined)),
  verificationStatus: z.enum(["UNVERIFIED", "VERIFIED"]).default("VERIFIED"),
  eventStatus: z.enum(["UPCOMING", "ONGOING", "COMPLETED", "TBD", "CANCELLED"]).default("UPCOMING"),
  published: z.coerce.boolean().default(true),
  imageUrl: url.optional().or(z.literal("").transform(() => undefined)),
  status: z.enum(["DRAFT", "PUBLISHED", "CANCELLED"]).default("PUBLISHED"),
});
export const announcementSchema = z.object({ title: clean(140), content: clean(4000), category: withDefault(40, "General"), priority: z.enum(["LOW", "NORMAL", "HIGH", "URGENT"]).default("NORMAL"), published: z.coerce.boolean() });
export const canteenSchema = z.object({ date: isoDate, meal: z.enum(MEALS), name: clean(100), price: z.coerce.number().int().min(0).max(100000), available: z.coerce.boolean(), imageUrl: url.optional().or(z.literal("").transform(() => undefined)) });
export const profileSchema = z.object({ name: clean(80, 2), showStudentId: z.coerce.boolean(), image: url.optional().or(z.literal("").transform(() => undefined)) });
export const categorySchema = z.object({ name: clean(40, 2) });
