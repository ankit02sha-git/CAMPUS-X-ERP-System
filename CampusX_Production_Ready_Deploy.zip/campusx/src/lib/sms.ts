/**
 * SMS & OTP Provider Abstraction powered by Twilio Verify V2
 *
 * Twilio Verify is the authoritative generator, sender, and verifier for OTPs.
 * CampusX maintains flow sessions in the `otps` table to enforce rate limits,
 * expiry times, max verification attempts, purpose binding, and single-use
 * security state.
 *
 * Twilio Verify V2 Endpoints:
 * - Start Verification: POST https://verify.twilio.com/v2/Services/{ServiceSid}/Verifications
 * - Verification Check:  POST https://verify.twilio.com/v2/Services/{ServiceSid}/VerificationCheck
 *
 * Security guarantees:
 * - No plain-text OTPs or secret keys logged.
 * - Mobile numbers masked in log output.
 * - Timeout handling (10 seconds max per provider request).
 * - E.164 phone formatting (+91XXXXXXXXXX for India).
 * - No hardcoded/mock OTP bypasses.
 */

import {
  formatMobileForTwilio,
  maskMobileNumber,
} from "@/lib/mobile";

export { formatMobileForTwilio, maskMobileNumber };

export type SmsPurpose = "ACTIVATION" | "FORGOT_PASSWORD";

export interface SendSMSInput {
  toMobile: string;
  purpose: SmsPurpose;
}

export interface ResendSMSInput {
  toMobile: string;
  purpose: SmsPurpose;
}

export interface SendSMSResult {
  success: boolean;
  provider: "twilio_verify" | "unconfigured";
  isRealSMS: boolean;
  messageId?: string;
  error?: string;
  userFacingMessage?: string;
}

export interface VerifySMSOtpInput {
  toMobile: string;
  otp: string;
}

export interface VerifySMSOtpResult {
  success: boolean;
  provider: "twilio_verify" | "unconfigured";
  error?: string;
  userFacingMessage?: string;
}

const UI_SEND_FAILED = "Unable to send verification code. Please try again.";
const UI_SERVICE_UNAVAILABLE = "Verification service is currently unconfigured or unavailable. Please try again later.";
const TWILIO_REQUEST_TIMEOUT_MS = 10_000;

/**
 * Reads Twilio credentials securely from process.env.
 * Supports either TWILIO_API_KEY + TWILIO_API_SECRET or TWILIO_ACCOUNT_SID + TWILIO_AUTH_TOKEN.
 */
function readTwilioConfig():
  | { ok: true; serviceSid: string; authHeader: string }
  | { ok: false } {
  const serviceSid = (process.env.TWILIO_VERIFY_SERVICE_SID || "").trim();
  const accountSid = (process.env.TWILIO_ACCOUNT_SID || "").trim();
  const apiKey = (process.env.TWILIO_API_KEY || "").trim();
  const apiSecret = (process.env.TWILIO_API_SECRET || "").trim();
  const authToken = (process.env.TWILIO_AUTH_TOKEN || "").trim();

  if (!serviceSid) return { ok: false };

  let user = "";
  let pass = "";
  if (apiKey && apiSecret) {
    user = apiKey;
    pass = apiSecret;
  } else if (accountSid && authToken) {
    user = accountSid;
    pass = authToken;
  } else if (accountSid && apiSecret) {
    user = accountSid;
    pass = apiSecret;
  } else {
    return { ok: false };
  }

  const authHeader = "Basic " + Buffer.from(`${user}:${pass}`).toString("base64");
  return { ok: true, serviceSid, authHeader };
}

function scrubForLog(s: unknown, max = 120): string {
  if (typeof s !== "string") return "";
  return s.replace(/[^\w .,:'\-]/g, "").slice(0, max);
}

/**
 * Send a verification code via Twilio Verify V2 API (Start Verification)
 */
export async function sendSMS(input: SendSMSInput): Promise<SendSMSResult> {
  const maskedDest = maskMobileNumber(input.toMobile);
  const cfg = readTwilioConfig();

  if (!cfg.ok) {
    console.error(
      `[TWILIO VERIFY CONFIG] purpose=${input.purpose} dest=${maskedDest} reason=misconfigured`
    );
    return {
      success: false,
      provider: "unconfigured",
      isRealSMS: false,
      error: "Twilio Verify misconfigured",
      userFacingMessage: UI_SERVICE_UNAVAILABLE,
    };
  }

  const formattedMobile = formatMobileForTwilio(input.toMobile);
  if (!formattedMobile) {
    console.error(
      `[TWILIO VERIFY INPUT] purpose=${input.purpose} dest=${maskedDest} reason=invalid_mobile`
    );
    return {
      success: false,
      provider: "twilio_verify",
      isRealSMS: false,
      error: "Malformed mobile number",
      userFacingMessage: UI_SEND_FAILED,
    };
  }

  const requestUrl = `https://verify.twilio.com/v2/Services/${cfg.serviceSid}/Verifications`;
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), TWILIO_REQUEST_TIMEOUT_MS);

  try {
    const params = new URLSearchParams({
      To: formattedMobile,
      Channel: "sms",
    });

    const res = await fetch(requestUrl, {
      method: "POST",
      headers: {
        Authorization: cfg.authHeader,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
      signal: controller.signal,
    });

    let data: any = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }

    const sid = typeof data?.sid === "string" ? data.sid.trim() : "";
    const isAccepted = res.ok && sid.length > 0 && (data?.status === "pending" || res.status === 201);

    if (isAccepted) {
      console.log(
        `[TWILIO VERIFY SUCCESS] purpose=${input.purpose} dest=${maskedDest} sid=${scrubForLog(sid, 64)}`
      );
      return {
        success: true,
        provider: "twilio_verify",
        isRealSMS: true,
        messageId: sid,
      };
    }

    const shortReason = scrubForLog(data?.message || data?.code, 120) || "provider rejected";
    console.error(
      `[TWILIO VERIFY FAILED] purpose=${input.purpose} dest=${maskedDest} status=${res.status} reason=${shortReason}`
    );
    return {
      success: false,
      provider: "twilio_verify",
      isRealSMS: true,
      error: `twilio_rejected:${res.status}:${shortReason}`,
      userFacingMessage: UI_SEND_FAILED,
    };
  } catch (e: any) {
    const reason = e?.name === "AbortError" ? "timeout" : "network";
    console.error(
      `[TWILIO VERIFY ERROR] purpose=${input.purpose} dest=${maskedDest} reason=${reason}`
    );
    return {
      success: false,
      provider: "twilio_verify",
      isRealSMS: true,
      error: reason,
      userFacingMessage: UI_SEND_FAILED,
    };
  } finally {
    clearTimeout(timeoutHandle);
  }
}

/**
 * Resend a verification code via Twilio Verify V2 API
 */
export async function resendSMS(input: ResendSMSInput): Promise<SendSMSResult> {
  return sendSMS(input);
}

/**
 * Verify a code via Twilio Verify V2 API (Verification Check)
 */
export async function verifySMSOtp(input: VerifySMSOtpInput): Promise<VerifySMSOtpResult> {
  const maskedDest = maskMobileNumber(input.toMobile);
  const cleanCode = String(input.otp || "").trim();

  if (!/^\d{4,8}$/.test(cleanCode)) {
    return {
      success: false,
      provider: "twilio_verify",
      error: "invalid_code_shape",
      userFacingMessage: "Please enter a valid numeric verification code.",
    };
  }

  const cfg = readTwilioConfig();
  if (!cfg.ok) {
    console.error(`[TWILIO VERIFY CONFIG] dest=${maskedDest} reason=misconfigured`);
    return {
      success: false,
      provider: "unconfigured",
      error: "Twilio Verify misconfigured",
      userFacingMessage: UI_SERVICE_UNAVAILABLE,
    };
  }

  const formattedMobile = formatMobileForTwilio(input.toMobile);
  if (!formattedMobile) {
    return {
      success: false,
      provider: "twilio_verify",
      error: "Malformed mobile number",
      userFacingMessage: UI_SEND_FAILED,
    };
  }

  const requestUrl = `https://verify.twilio.com/v2/Services/${cfg.serviceSid}/VerificationCheck`;
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), TWILIO_REQUEST_TIMEOUT_MS);

  try {
    const params = new URLSearchParams({
      To: formattedMobile,
      Code: cleanCode,
    });

    const res = await fetch(requestUrl, {
      method: "POST",
      headers: {
        Authorization: cfg.authHeader,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
      signal: controller.signal,
    });

    let data: any = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }

    const isApproved = res.ok && data?.status === "approved" && data?.valid === true;

    if (isApproved) {
      console.log(`[TWILIO VERIFY CHECK APPROVED] dest=${maskedDest}`);
      return {
        success: true,
        provider: "twilio_verify",
      };
    }

    const shortReason = scrubForLog(data?.message || data?.status, 120) || "Code rejected";
    console.error(`[TWILIO VERIFY CHECK FAILED] dest=${maskedDest} status=${res.status} reason=${shortReason}`);
    return {
      success: false,
      provider: "twilio_verify",
      error: `twilio_check_failed:${shortReason}`,
      userFacingMessage: "Invalid or expired verification code. Please try again.",
    };
  } catch (e: any) {
    const reason = e?.name === "AbortError" ? "timeout" : "network";
    console.error(`[TWILIO VERIFY CHECK ERROR] dest=${maskedDest} reason=${reason}`);
    return {
      success: false,
      provider: "twilio_verify",
      error: reason,
      userFacingMessage: "Unable to check verification code. Please try again.",
    };
  } finally {
    clearTimeout(timeoutHandle);
  }
}

// Aliases for clear semantic naming
export const sendVerificationCode = sendSMS;
export const resendVerificationCode = resendSMS;
export const verifyVerificationCode = verifySMSOtp;
