/**
 * Browser-safe mobile-number helpers for CampusX.
 *
 * This module has NO server-only imports (no `node:crypto`, no DB,
 * no `next/headers`), so a "use client" component can import from it without
 * dragging server code into the browser bundle. `src/lib/sms.ts` re-exports
 * these same functions so existing server-side imports keep working.
 */

/**
 * Mask a mobile number for privacy in logs and UI.
 * Example: "+919876543210" -> "******3210", "9876543210" -> "******3210".
 */
export function maskMobileNumber(mobile: string): string {
  const digits = String(mobile ?? "").replace(/\D/g, "");
  if (digits.length < 4) return "****";
  return `******${digits.slice(-4)}`;
}

/**
 * Format a mobile number for Twilio Verify (E.164 format).
 * Returns null if the number cannot be safely normalised.
 *
 * Accepted inputs (any spacing / dashes / '+' allowed):
 *   9876543210          -> +919876543210
 *   +919876543210       -> +919876543210
 *   919876543210        -> +919876543210
 *   09876543210         -> +919876543210
 */
export function formatMobileForTwilio(mobile: string): string | null {
  const raw = String(mobile ?? "").trim();
  const digits = raw.replace(/\D/g, "");

  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
  if (digits.length === 11 && digits.startsWith("0")) return `+91${digits.slice(1)}`;
  if (digits.length > 10 && raw.startsWith("+")) return `+${digits}`;
  return null;
}
