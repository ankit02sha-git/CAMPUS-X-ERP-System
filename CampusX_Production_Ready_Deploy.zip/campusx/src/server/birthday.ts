import { db } from "@/server/db";
import { studentsMaster, courses } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { todayKey } from "@/lib/utils";

/**
 * Controlled pool of warm, inspiring, academic birthday message templates.
 */
export const BIRTHDAY_MESSAGES = [
  "Wishing you a wonderful day filled with happiness, success, and great achievements! 🎉",
  "May your special day be bright and full of inspiration for the year ahead! 🌟",
  "Happy Birthday! Wishing you brilliant success in all your academic and personal endeavors! 🎓",
  "Warmest birthday wishes! May this year bring you closer to all your dreams and goals! ✨",
  "Celebrating you today! Hope your birthday is as extraordinary and awesome as you are! 🥳",
  "Happy Birthday! May your day be filled with joy, laughter, and great memories with friends! 🎂",
  "Wishing you a fantastic birthday and an incredible year ahead filled with learning and joy! 🚀",
  "Happy Birthday! May this special day mark the start of an amazing chapter of accomplishments! 🌈",
  "Sending you warm wishes on your birthday! May your curiosity and passion continue to shine bright! 💖",
  "Happy Birthday! Wishing you good health, great success, and continuous growth on your journey! 🎈",
  "Have a delightful birthday! May all your hard work turn into stellar achievements this year! 🎯",
  "Happy Birthday! Wishing you endless inspiration, happiness, and unforgettable moments! 🎊",
];

export interface StudentBirthdayGreeting {
  id: string;
  name: string;
  message: string;
  todayKey: string;
}

export interface AdminBirthdayRecord {
  id: string;
  studentId: string;
  fullName: string;
  dob: string | null;
  age: number | null;
  courseCode: string | null;
  courseName: string | null;
  academicYear: string | null;
  semester: number | null;
  section: string | null;
  rollNumber: string | null;
  registeredMobile: string | null;
  status: string;
  isToday: boolean;
  birthMonth: number | null;
  birthDay: number | null;
}

/**
 * Simple hash helper to pick deterministic message per student ID without repeats
 */
function getMessageForStudent(studentId: string, indexOffset: number = 0): string {
  let hash = 0;
  for (let i = 0; i < studentId.length; i++) {
    hash = (hash << 5) - hash + studentId.charCodeAt(i);
    hash |= 0;
  }
  const idx = Math.abs(hash + indexOffset) % BIRTHDAY_MESSAGES.length;
  return BIRTHDAY_MESSAGES[idx];
}

/**
 * Calculates student age based on current IST date
 */
function computeAge(dobStr: string | null, todayYear: number, todayMonth: number, todayDay: number): number | null {
  if (!dobStr) return null;
  const parts = dobStr.split("-").map(Number);
  if (parts.length < 3 || !parts[0] || !parts[1] || !parts[2]) return null;
  const [bYear, bMonth, bDay] = parts;
  let age = todayYear - bYear;
  if (todayMonth < bMonth || (todayMonth === bMonth && todayDay < bDay)) {
    age--;
  }
  return age >= 0 ? age : null;
}

/**
 * Fetch today's birthday students for the student-facing notification banner.
 * Strict Privacy: Exposes ONLY student `id`, `name`, and assigned `message`.
 * No DOB, year, age, student ID, or contact info is returned.
 */
export async function getTodaysBirthdayGreetings(): Promise<{ greetings: StudentBirthdayGreeting[]; todayKeyStr: string }> {
  const todayStr = todayKey(); // "YYYY-MM-DD" in Asia/Kolkata
  const parts = todayStr.split("-").map(Number);
  const currYear = parts[0] || 2026;
  const currMonth = parts[1] || 1;
  const currDay = parts[2] || 1;

  // Leap year calculation for IST current year
  const isLeapYear = (currYear % 4 === 0 && currYear % 100 !== 0) || (currYear % 400 === 0);
  const isNonLeapFeb28 = !isLeapYear && currMonth === 2 && currDay === 28;

  // Query active students
  const activeStudents = await db
    .select({
      id: studentsMaster.id,
      studentId: studentsMaster.studentId,
      fullName: studentsMaster.fullName,
      dob: studentsMaster.dob,
    })
    .from(studentsMaster)
    .where(eq(studentsMaster.status, "ACTIVE"));

  const matchingGreetings: StudentBirthdayGreeting[] = [];

  activeStudents.forEach((st, idx) => {
    if (!st.dob) return;
    const dobParts = st.dob.split("-").map(Number);
    if (dobParts.length < 3) return;
    const [, bMonth, bDay] = dobParts;

    const isMatch = (bMonth === currMonth && bDay === currDay) || (isNonLeapFeb28 && bMonth === 2 && bDay === 29);

    if (isMatch) {
      matchingGreetings.push({
        id: st.id,
        name: st.fullName,
        message: getMessageForStudent(st.id || st.studentId, idx),
        todayKey: todayStr,
      });
    }
  });

  return { greetings: matchingGreetings, todayKeyStr: todayStr };
}

/**
 * Fetch student birthday records for Admin Control Panel.
 * Protected by Admin Guards. Returns full DOB, computed age, course info, search & filter support.
 */
export async function getAdminBirthdayRecords(monthFilter?: number): Promise<{
  records: AdminBirthdayRecord[];
  todayKeyStr: string;
  totalCount: number;
}> {
  const todayStr = todayKey();
  const parts = todayStr.split("-").map(Number);
  const currYear = parts[0] || 2026;
  const currMonth = parts[1] || 1;
  const currDay = parts[2] || 1;

  const isLeapYear = (currYear % 4 === 0 && currYear % 100 !== 0) || (currYear % 400 === 0);
  const isNonLeapFeb28 = !isLeapYear && currMonth === 2 && currDay === 28;

  const rows = await db
    .select({
      sm: studentsMaster,
      courseCode: courses.code,
      courseName: courses.name,
    })
    .from(studentsMaster)
    .leftJoin(courses, eq(studentsMaster.courseId, courses.id));

  const records: AdminBirthdayRecord[] = [];

  for (const row of rows) {
    const sm = row.sm;
    let birthMonth: number | null = null;
    let birthDay: number | null = null;
    let isToday = false;

    if (sm.dob) {
      const dobParts = sm.dob.split("-").map(Number);
      if (dobParts.length >= 3) {
        birthMonth = dobParts[1];
        birthDay = dobParts[2];
        isToday =
          (birthMonth === currMonth && birthDay === currDay) || (isNonLeapFeb28 && birthMonth === 2 && birthDay === 29);
      }
    }

    if (monthFilter && birthMonth !== monthFilter) {
      continue;
    }

    records.push({
      id: sm.id,
      studentId: sm.studentId,
      fullName: sm.fullName,
      dob: sm.dob,
      age: computeAge(sm.dob, currYear, currMonth, currDay),
      courseCode: row.courseCode ?? null,
      courseName: row.courseName ?? null,
      academicYear: sm.academicYear,
      semester: sm.semester,
      section: sm.section,
      rollNumber: sm.rollNumber,
      registeredMobile: sm.registeredMobile,
      status: sm.status,
      isToday,
      birthMonth,
      birthDay,
    });
  }

  // Sort by today's birthdays first, then by upcoming birth day in month
  records.sort((a, b) => {
    if (a.isToday && !b.isToday) return -1;
    if (!a.isToday && b.isToday) return 1;
    if (a.birthMonth !== b.birthMonth) return (a.birthMonth || 99) - (b.birthMonth || 99);
    return (a.birthDay || 99) - (b.birthDay || 99);
  });

  return {
    records,
    todayKeyStr: todayStr,
    totalCount: records.length,
  };
}
