import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";

export const UPLOAD_DIR = path.join(process.cwd(), ".uploads");

const IMAGE_TYPES: Record<string, { ext: string; magic: (b: Buffer) => boolean }> = {
  "image/jpeg": { ext: "jpg", magic: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  "image/png": { ext: "png", magic: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  "image/webp": { ext: "webp", magic: (b) => b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP" },
};
const DOC_TYPES: Record<string, { ext: string; magic: (b: Buffer) => boolean }> = {
  "application/pdf": { ext: "pdf", magic: (b) => b.subarray(0, 4).toString() === "%PDF" },
  ...IMAGE_TYPES,
};

export type UploadKind = "image" | "document";
const LIMITS = { image: 5 * 1024 * 1024, document: 15 * 1024 * 1024 };

export class UploadError extends Error {}

/** Validates on the server (declared type, size AND magic bytes), then stores in Cloudinary or local fallback. */
export async function storeFile(file: File, kind: UploadKind, folder: string): Promise<{ url: string; name: string; type: string }> {
  const allowed = kind === "image" ? IMAGE_TYPES : DOC_TYPES;
  const spec = allowed[file.type];
  if (!spec) throw new UploadError(kind === "image" ? "Only JPG, PNG or WebP images are allowed." : "Only PDF or image files are allowed.");
  if (file.size === 0) throw new UploadError("The file is empty.");
  if (file.size > LIMITS[kind]) throw new UploadError(`File is too large (max ${LIMITS[kind] / 1024 / 1024} MB).`);
  const buf = Buffer.from(await file.arrayBuffer());
  if (!spec.magic(buf)) throw new UploadError("File contents do not match its type.");

  const { CLOUDINARY_CLOUD_NAME: cloud, CLOUDINARY_API_KEY: key, CLOUDINARY_API_SECRET: secret } = process.env;
  if (cloud && key && secret) {
    const { v2: cloudinary } = await import("cloudinary");
    cloudinary.config({ cloud_name: cloud, api_key: key, api_secret: secret, secure: true });
    const res = await new Promise<{ secure_url: string }>((resolve, reject) => {
      cloudinary.uploader.upload_stream({ folder: `campusx/${folder}`, resource_type: "auto" }, (e, r) => (e || !r ? reject(e) : resolve(r as { secure_url: string }))).end(buf);
    });
    return { url: res.secure_url, name: file.name.slice(0, 120), type: file.type };
  }
  await mkdir(UPLOAD_DIR, { recursive: true });
  const name = `${randomBytes(16).toString("hex")}.${spec.ext}`;
  await writeFile(path.join(UPLOAD_DIR, name), buf);
  return { url: `/api/files/${name}`, name: file.name.slice(0, 120), type: file.type };
}
