import { inArray } from "drizzle-orm";
import { db } from "@/server/db";
import { notifications, users } from "@/server/db/schema";

type N = { type: typeof notifications.$inferInsert["type"]; title: string; body?: string; link?: string };

export async function notifyUser(userId: string, n: N) {
  await db.insert(notifications).values({ userId, ...n });
}
export async function notifyUsers(userIds: string[], n: N) {
  if (!userIds.length) return;
  await db.insert(notifications).values(userIds.map((userId) => ({ userId, ...n })));
}
/** Notify students of a course (optionally one semester). */
export async function notifyCohort(courseId: string | null, semester: number | null, n: N) {
  const rows = await db.select({ id: users.id, c: users.courseId, s: users.semester }).from(users).where(inArray(users.role, ["STUDENT"]));
  const ids = rows.filter((r) => (!courseId || r.c === courseId) && (!semester || r.s === semester)).map((r) => r.id);
  await notifyUsers(ids, n);
}
