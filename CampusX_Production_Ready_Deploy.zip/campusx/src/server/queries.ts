import { and, asc, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/server/db";
import { announcements, assignments, assignmentSubmissions, events, lostPosts, lostImages, timetable, studentStats, lostCategories } from "@/server/db/schema";
import type { User } from "@/server/db/schema";
import { istNow, todayKey } from "@/lib/utils";

export async function todaysClasses(u: User) {
  if (!u.courseId || !u.semester) return [];
  const { day } = istNow();
  return db.select().from(timetable).where(and(eq(timetable.courseId, u.courseId), eq(timetable.semester, u.semester), eq(timetable.day, day as never))).orderBy(asc(timetable.startTime));
}
export async function upcomingEvents(limit = 4) {
  return db.select().from(events).where(and(eq(events.status, "PUBLISHED"), gte(events.date, todayKey()))).orderBy(asc(events.date), asc(events.startTime)).limit(limit);
}
export async function recentAnnouncements(limit = 3) {
  return db.select().from(announcements).where(eq(announcements.published, true)).orderBy(desc(announcements.publishedAt)).limit(limit);
}
export async function recentLost(limit = 4) {
  return db.select({ p: lostPosts, category: lostCategories.name, image: sql<string | null>`(select url from ${lostImages} where ${lostImages.postId} = ${lostPosts.id} order by ${lostImages.order} limit 1)` })
    .from(lostPosts).innerJoin(lostCategories, eq(lostCategories.id, lostPosts.categoryId))
    .where(eq(lostPosts.hidden, false)).orderBy(desc(lostPosts.createdAt)).limit(limit);
}
export async function myAssignments(u: User) {
  if (!u.courseId || !u.semester) return [];
  const rows = await db.select({ a: assignments, status: assignmentSubmissions.status }).from(assignments)
    .leftJoin(assignmentSubmissions, and(eq(assignmentSubmissions.assignmentId, assignments.id), eq(assignmentSubmissions.userId, u.id)))
    .where(and(eq(assignments.courseId, u.courseId), eq(assignments.semester, u.semester))).orderBy(asc(assignments.dueDate));
  const now = Date.now();
  return rows.map(({ a, status }) => {
    const s = status ?? "PENDING";
    const display = s === "PENDING" && a.dueDate.getTime() < now ? "OVERDUE" : s;
    return { ...a, status: display as "PENDING" | "SUBMITTED" | "COMPLETED" | "OVERDUE" };
  });
}
export async function myStats(u: User) {
  const [s] = await db.select().from(studentStats).where(eq(studentStats.userId, u.id)).limit(1);
  return s ?? null;
}
