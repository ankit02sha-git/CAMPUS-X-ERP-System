import type { AnySQLiteTable } from "drizzle-orm/sqlite-core";
import type { ZodTypeAny } from "zod";
import { announcements, assignments, canteenItems, courses, events, notes, timetable } from "@/server/db/schema";
import { announcementSchema, assignmentSchema, canteenSchema, courseSchema, eventSchema, noteSchema, timetableSchema } from "@/lib/validators";

export type FieldDef = {
  name: string; label: string; hint?: string; required?: boolean;
  type: "text" | "textarea" | "number" | "date" | "time" | "datetime" | "select" | "course" | "semester" | "checkbox" | "image" | "document";
  options?: { value: string; label: string }[]; purpose?: string;
};
export type ColumnDef = { key: string; label: string; kind?: "course" | "bool" | "datetime" | "money" };

export type Entity = {
  key: string; label: string; singular: string; description: string;
  table: AnySQLiteTable; schema: ZodTypeAny; fields: FieldDef[]; columns: ColumnDef[];
  orderBy: string; // column key
};

const DAYS = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"].map((d) => ({ value: d, label: d[0] + d.slice(1).toLowerCase() }));
const MEALS = ["BREAKFAST", "LUNCH", "SNACKS", "BEVERAGES"].map((d) => ({ value: d, label: d[0] + d.slice(1).toLowerCase() }));

export const ENTITIES: Record<string, Entity> = {
  timetable: {
    key: "timetable", label: "Timetable", singular: "class", description: "Course → Semester → Day → Subject → Time → Room", table: timetable, schema: timetableSchema, orderBy: "day",
    fields: [
      { name: "courseId", label: "Course", type: "course", required: true }, { name: "semester", label: "Semester", type: "semester", required: true },
      { name: "day", label: "Day", type: "select", options: DAYS, required: true },
      { name: "startTime", label: "Start time", type: "time", required: true }, { name: "endTime", label: "End time", type: "time", required: true },
      { name: "subject", label: "Subject", type: "text", required: true }, { name: "faculty", label: "Faculty", type: "text" }, { name: "room", label: "Room", type: "text" },
    ],
    columns: [{ key: "courseId", label: "Course", kind: "course" }, { key: "semester", label: "Sem" }, { key: "day", label: "Day" }, { key: "startTime", label: "Start" }, { key: "endTime", label: "End" }, { key: "subject", label: "Subject" }, { key: "room", label: "Room" }],
  },
  notes: {
    key: "notes", label: "Notes", singular: "note", description: "Upload study material for a course and semester", table: notes, schema: noteSchema, orderBy: "createdAt",
    fields: [
      { name: "title", label: "Title", type: "text", required: true }, { name: "description", label: "Description", type: "textarea" },
      { name: "courseId", label: "Course", type: "course", required: true }, { name: "semester", label: "Semester", type: "semester", required: true },
      { name: "subject", label: "Subject", type: "text", required: true }, { name: "fileUrl", label: "File (PDF or image)", type: "document", purpose: "note", required: true },
    ],
    columns: [{ key: "title", label: "Title" }, { key: "courseId", label: "Course", kind: "course" }, { key: "semester", label: "Sem" }, { key: "subject", label: "Subject" }],
  },
  assignments: {
    key: "assignments", label: "Assignments", singular: "assignment", description: "Students in the cohort are notified automatically", table: assignments, schema: assignmentSchema, orderBy: "dueDate",
    fields: [
      { name: "title", label: "Title", type: "text", required: true }, { name: "description", label: "Description", type: "textarea" },
      { name: "courseId", label: "Course", type: "course", required: true }, { name: "semester", label: "Semester", type: "semester", required: true },
      { name: "subject", label: "Subject", type: "text", required: true }, { name: "dueDate", label: "Due (IST)", type: "datetime", required: true },
      { name: "attachmentUrl", label: "Attachment", type: "document", purpose: "assignment" },
    ],
    columns: [{ key: "title", label: "Title" }, { key: "courseId", label: "Course", kind: "course" }, { key: "semester", label: "Sem" }, { key: "subject", label: "Subject" }, { key: "dueDate", label: "Due", kind: "datetime" }],
  },
  events: {
    key: "events", label: "Events", singular: "event", description: "Publish and manage campus events, spotlit highlights, and dates", table: events, schema: eventSchema, orderBy: "date",
    fields: [
      { name: "title", label: "Title", type: "text", required: true },
      { name: "shortDescription", label: "Short Summary", type: "textarea", hint: "Brief 1-2 sentence overview for cards" },
      { name: "description", label: "Full Description", type: "textarea" },
      { name: "date", label: "Date (Primary)", type: "date", required: true },
      { name: "startDate", label: "Start Date", type: "date" },
      { name: "endDate", label: "End Date", type: "date" },
      { name: "datePrecision", label: "Date Precision", type: "select", options: [{ value: "EXACT_DATE", label: "Exact Date" }, { value: "DATE_RANGE", label: "Date Range" }, { value: "MONTH_ONLY", label: "Month Only" }, { value: "TBD", label: "Date TBD" }] },
      { name: "startTime", label: "Start Time", type: "time" },
      { name: "endTime", label: "End Time", type: "time" },
      { name: "venue", label: "Venue", type: "text", hint: "e.g. Study Hall College Auditorium" },
      { name: "category", label: "Category", type: "select", options: [{ value: "CULTURAL", label: "Cultural" }, { value: "ACADEMIC", label: "Academic" }, { value: "SPORTS", label: "Sports" }, { value: "WORKSHOP", label: "Workshop" }, { value: "COMPETITION", label: "Competition" }, { value: "CELEBRATION", label: "Celebration" }, { value: "TBD", label: "TBD" }] },
      { name: "eventStatus", label: "Event Lifecycle", type: "select", options: [{ value: "UPCOMING", label: "Upcoming" }, { value: "ONGOING", label: "Ongoing" }, { value: "COMPLETED", label: "Completed" }, { value: "TBD", label: "TBD" }, { value: "CANCELLED", label: "Cancelled" }] },
      { name: "featured", label: "Spotlight Featured", type: "checkbox" },
      { name: "registrationEnabled", label: "Student Registration Enabled", type: "checkbox" },
      { name: "sourceType", label: "Data Source Type", type: "select", options: [{ value: "OFFICIAL_WEBSITE", label: "Official Website" }, { value: "USER_SUPPLIED", label: "Planning Schedule" }, { value: "ADMIN_ENTERED", label: "Admin Entered" }, { value: "VERIFIED", label: "Verified" }] },
      { name: "published", label: "Published on Portal", type: "checkbox" },
      { name: "imageUrl", label: "Event Image", type: "image", purpose: "event" },
    ],
    columns: [
      { key: "title", label: "Title" },
      { key: "date", label: "Date" },
      { key: "category", label: "Category" },
      { key: "eventStatus", label: "Lifecycle" },
      { key: "featured", label: "Spotlight", kind: "bool" },
      { key: "published", label: "Published", kind: "bool" },
    ],
  },
  announcements: {
    key: "announcements", label: "Announcements", singular: "announcement", description: "Publish or unpublish notices", table: announcements, schema: announcementSchema, orderBy: "createdAt",
    fields: [
      { name: "title", label: "Title", type: "text", required: true }, { name: "content", label: "Content", type: "textarea", required: true },
      { name: "category", label: "Category", type: "text" }, { name: "priority", label: "Priority", type: "select", options: ["LOW", "NORMAL", "HIGH", "URGENT"].map((v) => ({ value: v, label: v[0] + v.slice(1).toLowerCase() })) },
      { name: "published", label: "Published", type: "checkbox" },
    ],
    columns: [{ key: "title", label: "Title" }, { key: "category", label: "Category" }, { key: "priority", label: "Priority" }, { key: "published", label: "Published", kind: "bool" }],
  },
  canteen: {
    key: "canteen", label: "Canteen", singular: "menu item", description: "Menu → Date → Meal → Item → Price", table: canteenItems, schema: canteenSchema, orderBy: "date",
    fields: [
      { name: "date", label: "Date", type: "date", required: true }, { name: "meal", label: "Meal", type: "select", options: MEALS, required: true },
      { name: "name", label: "Item", type: "text", required: true }, { name: "price", label: "Price (₹)", type: "number", required: true },
      { name: "available", label: "Available", type: "checkbox" }, { name: "imageUrl", label: "Image", type: "image", purpose: "canteen" },
    ],
    columns: [{ key: "date", label: "Date" }, { key: "meal", label: "Meal" }, { key: "name", label: "Item" }, { key: "price", label: "Price", kind: "money" }, { key: "available", label: "Avail.", kind: "bool" }],
  },
  courses: {
    key: "courses", label: "Courses", singular: "course", description: "Manage courses and semester counts", table: courses, schema: courseSchema, orderBy: "code",
    fields: [
      { name: "code", label: "Code", type: "text", required: true, hint: "BCA, BBA, BCOM, BJMC" }, { name: "name", label: "Name", type: "text", required: true },
      { name: "description", label: "Description", type: "textarea" }, { name: "semesters", label: "Number of semesters", type: "number", required: true }, { name: "active", label: "Active", type: "checkbox" },
    ],
    columns: [{ key: "code", label: "Code" }, { key: "name", label: "Name" }, { key: "semesters", label: "Semesters" }, { key: "active", label: "Active", kind: "bool" }],
  },
};
