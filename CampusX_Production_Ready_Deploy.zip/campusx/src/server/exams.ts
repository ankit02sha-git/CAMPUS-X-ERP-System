import { db } from "@/server/db";
import {
  exams,
  examSubjects,
  studentResults,
  subjects,
  courses,
} from "@/server/db/schema";
import { eq, and, sql } from "drizzle-orm";

export interface StudentExamCard {
  id: string;
  title: string;
  examType: string;
  semester: number;
  academicYear: string | null;
  startDate: string;
  endDate: string;
  instructions: string | null;
  subjectsList: Array<{
    subjectName: string;
    examDate: string;
    startTime: string;
    endTime: string;
    venue: string | null;
    maxMarks: number;
    passMarks: number;
  }>;
}

export interface StudentResultSummary {
  examTitle: string;
  examType: string;
  semester: number;
  overallTotal: number;
  overallMax: number;
  overallPercentage: number;
  finalStatus: "PASS" | "FAIL" | "ABSENT" | "WITHHELD" | "NOT_PUBLISHED";
  subjectResults: Array<{
    subjectName: string;
    internalMarks: number | null;
    externalMarks: number | null;
    practicalMarks: number | null;
    totalMarks: number;
    maxMarks: number;
    grade: string | null;
    status: string;
    remarks: string | null;
  }>;
}

/**
 * Fetch upcoming and published exam schedules for a student's course & semester.
 * Server security: Only queries published exams matching student cohort.
 */
export async function getStudentExamsList(
  userCourseId: string | null,
  userSemester: number | null,
  targetSemester?: number
): Promise<StudentExamCard[]> {
  const currentSem = targetSemester || userSemester || 3;
  if (!userCourseId) return [];

  const examRows = await db
    .select()
    .from(exams)
    .where(
      and(
        eq(exams.courseId, userCourseId),
        eq(exams.semester, currentSem),
        eq(exams.published, true)
      )
    );

  const cards: StudentExamCard[] = [];

  for (const ex of examRows) {
    const subjs = await db
      .select()
      .from(examSubjects)
      .where(eq(examSubjects.examId, ex.id));

    cards.push({
      id: ex.id,
      title: ex.title,
      examType: ex.examType,
      semester: ex.semester,
      academicYear: ex.academicYear,
      startDate: ex.startDate,
      endDate: ex.endDate,
      instructions: ex.instructions,
      subjectsList: subjs.map((s) => ({
        subjectName: s.subjectName,
        examDate: s.examDate,
        startTime: s.startTime,
        endTime: s.endTime,
        venue: s.venue,
        maxMarks: s.maxMarks,
        passMarks: s.passMarks,
      })),
    });
  }

  return cards;
}

/**
 * Fetch student exam results securely for authenticated user.
 */
export async function getStudentResultsList(
  userId: string,
  userCourseId: string | null,
  userSemester: number | null,
  targetSemester?: number
): Promise<StudentResultSummary[]> {
  const currentSem = targetSemester || userSemester || 3;

  const results = await db
    .select({
      sr: studentResults,
      examTitle: exams.title,
      examType: exams.examType,
      examSem: exams.semester,
      subjName: examSubjects.subjectName,
    })
    .from(studentResults)
    .innerJoin(exams, eq(studentResults.examId, exams.id))
    .leftJoin(examSubjects, eq(studentResults.subjectId, examSubjects.subjectId))
    .where(
      and(
        eq(studentResults.userId, userId),
        eq(exams.semester, currentSem),
        eq(exams.published, true)
      )
    );

  if (results.length === 0) return [];

  // Group by exam
  const examMap = new Map<string, StudentResultSummary>();

  for (const r of results) {
    const key = r.examTitle;
    if (!examMap.has(key)) {
      examMap.set(key, {
        examTitle: r.examTitle,
        examType: r.examType,
        semester: r.examSem,
        overallTotal: 0,
        overallMax: 0,
        overallPercentage: 0,
        finalStatus: "PASS",
        subjectResults: [],
      });
    }

    const summary = examMap.get(key)!;
    summary.overallTotal += r.sr.totalMarks;
    summary.overallMax += r.sr.maxMarks;
    if (r.sr.resultStatus === "FAIL" || r.sr.resultStatus === "ABSENT") {
      summary.finalStatus = r.sr.resultStatus as any;
    }

    summary.subjectResults.push({
      subjectName: r.subjName || "Academic Paper",
      internalMarks: r.sr.internalMarks,
      externalMarks: r.sr.externalMarks,
      practicalMarks: r.sr.practicalMarks,
      totalMarks: r.sr.totalMarks,
      maxMarks: r.sr.maxMarks,
      grade: r.sr.grade,
      status: r.sr.resultStatus,
      remarks: r.sr.remarks,
    });
  }

  const summaries = Array.from(examMap.values());
  summaries.forEach((s) => {
    s.overallPercentage = s.overallMax > 0 ? Number(((s.overallTotal / s.overallMax) * 100).toFixed(2)) : 0;
  });

  return summaries;
}
