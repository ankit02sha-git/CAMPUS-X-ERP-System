import { db } from "@/server/db";
import { academicCalendarEvents } from "@/server/db/schema";
import { asc } from "drizzle-orm";

export async function getAcademicCalendarEvents() {
  return await db
    .select()
    .from(academicCalendarEvents)
    .orderBy(asc(academicCalendarEvents.startDate));
}
