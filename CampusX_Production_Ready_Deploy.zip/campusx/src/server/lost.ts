import { and, asc, desc, eq, gte, or, sql, type SQL } from "drizzle-orm";
import { ilike } from "@/server/db/like";
import { db } from "@/server/db";
import { lostCategories, lostImages, lostMessages, lostPosts, lostReports, lostResponses, lostThreads, users } from "@/server/db/schema";

export const PAGE_SIZE = 12;
const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");
export const firstImage = sql<string | null>`(select url from ${lostImages} where ${lostImages.postId} = ${lostPosts.id} order by ${lostImages.order} limit 1)`;

export type Filters = { kind: "LOST" | "FOUND"; q?: string; category?: string; location?: string; since?: string; status?: string; page?: number };

export async function listPosts(f: Filters) {
  const w: SQL[] = [eq(lostPosts.hidden, false), eq(lostPosts.kind, f.kind)];
  if (f.q) { const l = `%${esc(f.q)}%`; w.push(or(ilike(lostPosts.title, l), ilike(lostPosts.description, l))!); }
  if (f.category) w.push(eq(lostPosts.categoryId, f.category));
  if (f.location) w.push(ilike(lostPosts.location, `%${esc(f.location)}%`));
  if (f.since && /^\d{4}-\d{2}-\d{2}$/.test(f.since)) w.push(gte(lostPosts.occurredOn, f.since));
  if (f.status && ["LOST", "POSSIBLY_FOUND", "FOUND", "CLOSED"].includes(f.status)) w.push(eq(lostPosts.status, f.status as "LOST"));
  const where = and(...w);
  const page = Math.max(1, f.page ?? 1);
  const [rows, [{ n }]] = await Promise.all([
    db.select({ p: lostPosts, category: lostCategories.name, image: firstImage, author: users.name })
      .from(lostPosts).innerJoin(lostCategories, eq(lostCategories.id, lostPosts.categoryId)).innerJoin(users, eq(users.id, lostPosts.authorId))
      .where(where).orderBy(desc(lostPosts.createdAt)).limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE),
    db.select({ n: sql<number>`count(*)` }).from(lostPosts).where(where),
  ]);
  return { rows, total: Number(n), pages: Math.max(1, Math.ceil(Number(n) / PAGE_SIZE)), page };
}
export const activeCategories = () => db.select().from(lostCategories).where(eq(lostCategories.active, true)).orderBy(asc(lostCategories.order));

/** Public-safe view of a post. Never returns email/phone. Student ID only if the author opted in. */
export async function getPost(id: string, viewer: { id: string; role: string }) {
  const [row] = await db.select({ p: lostPosts, category: lostCategories.name, author: users.name, authorId: users.id, authorStudentId: users.studentId, showId: users.showStudentId })
    .from(lostPosts).innerJoin(lostCategories, eq(lostCategories.id, lostPosts.categoryId)).innerJoin(users, eq(users.id, lostPosts.authorId)).where(eq(lostPosts.id, id)).limit(1);
  if (!row) return null;
  const isOwner = row.p.authorId === viewer.id, isAdmin = viewer.role === "ADMIN";
  if (row.p.hidden && !isOwner && !isAdmin) return null;
  const images = await db.select().from(lostImages).where(eq(lostImages.postId, id)).orderBy(asc(lostImages.order));
  const post = { ...row.p, details: isOwner || isAdmin ? row.p.details : null };
  return { post, category: row.category, author: row.author, studentId: row.showId ? row.authorStudentId : null, images, isOwner, isAdmin };
}

/** Responses: owner/admin see all (with optional contact info); others only see their own. */
export async function getResponses(postId: string, viewer: { id: string }, canSeeAll: boolean) {
  const where = canSeeAll ? eq(lostResponses.postId, postId) : and(eq(lostResponses.postId, postId), eq(lostResponses.userId, viewer.id));
  return db.select({ r: lostResponses, name: users.name }).from(lostResponses).innerJoin(users, eq(users.id, lostResponses.userId)).where(where).orderBy(desc(lostResponses.createdAt));
}
export async function getThreads(postId: string, viewer: { id: string }) {
  return db.select({ t: lostThreads, ownerName: sql<string>`(select name from ${users} where ${users.id} = ${lostThreads.ownerId})`, otherName: sql<string>`(select name from ${users} where ${users.id} = ${lostThreads.otherId})` })
    .from(lostThreads).where(and(eq(lostThreads.postId, postId), or(eq(lostThreads.ownerId, viewer.id), eq(lostThreads.otherId, viewer.id)))).orderBy(desc(lostThreads.createdAt));
}
export async function getMessages(threadId: string, viewerId: string) {
  const [t] = await db.select().from(lostThreads).where(and(eq(lostThreads.id, threadId), or(eq(lostThreads.ownerId, viewerId), eq(lostThreads.otherId, viewerId)))).limit(1);
  if (!t) return null;
  const messages = await db.select({ id: lostMessages.id, body: lostMessages.body, senderId: lostMessages.senderId, createdAt: lostMessages.createdAt }).from(lostMessages).where(eq(lostMessages.threadId, threadId)).orderBy(asc(lostMessages.createdAt)).limit(300);
  return { thread: t, messages };
}
export async function reportsForAdmin() {
  return db.select({ r: lostReports, title: lostPosts.title, postId: lostPosts.id, hidden: lostPosts.hidden, reporter: users.name }).from(lostReports)
    .innerJoin(lostPosts, eq(lostPosts.id, lostReports.postId)).innerJoin(users, eq(users.id, lostReports.reporterId)).orderBy(asc(lostReports.status), desc(lostReports.createdAt)).limit(100);
}
