import { db } from "@/server/db";
import { grievanceTickets, users } from "@/server/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { createId } from "@/utils/id";

export async function getStudentGrievanceTickets(userId: string) {
  return await db
    .select()
    .from(grievanceTickets)
    .where(eq(grievanceTickets.userId, userId))
    .orderBy(desc(grievanceTickets.createdAt));
}

export async function getAdminGrievanceTickets() {
  return await db
    .select({
      gt: grievanceTickets,
      studentName: users.name,
      studentId: users.studentId,
    })
    .from(grievanceTickets)
    .innerJoin(users, eq(grievanceTickets.userId, users.id))
    .orderBy(desc(grievanceTickets.createdAt));
}

export async function createGrievanceTicket(
  userId: string,
  category: "ACADEMIC" | "FEE" | "TIMETABLE" | "INFRASTRUCTURE" | "TECHNICAL",
  subject: string,
  description: string
) {
  const randomNum = Math.floor(1000 + Math.random() * 9000);
  const ticketNumber = `TCK-2026-${randomNum}`;

  const [ticket] = await db
    .insert(grievanceTickets)
    .values({
      id: createId(),
      ticketNumber,
      category,
      subject,
      description,
      userId,
      status: "OPEN",
    })
    .returning();

  return ticket;
}

export async function updateAdminGrievanceStatus(
  ticketId: string,
  status: "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED",
  adminResponse?: string
) {
  const isResolved = status === "RESOLVED" || status === "CLOSED";
  await db
    .update(grievanceTickets)
    .set({
      status,
      adminResponse: adminResponse || null,
      resolvedAt: isResolved ? new Date() : null,
      updatedAt: new Date(),
    })
    .where(eq(grievanceTickets.id, ticketId));

  return { success: true };
}
