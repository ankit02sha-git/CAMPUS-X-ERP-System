import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { db } from "@/server/db";
import { users } from "@/server/db/schema";

/**
 * Custom Authorization Error Class
 * Thrown when an unauthenticated user or unauthorized role attempts to invoke a protected Server Action.
 */
export class AuthError extends Error {
  constructor(public code: "UNAUTHORIZED" | "FORBIDDEN" = "UNAUTHORIZED") {
    super(code);
  }
}

/**
 * getCurrentUser
 * Retrieves the currently authenticated user from the database based on the NextAuth session token.
 * Re-queries the database directly so account deactivations or role changes take effect immediately,
 * preventing stale JWT token security risks.
 */
export async function getCurrentUser() {
  const session = await auth();
  if (!session?.user?.id) return null;

  const [dbUser] = await db
    .select()
    .from(users)
    .where(eq(users.id, session.user.id))
    .limit(1);

  if (!dbUser || !dbUser.active) return null;
  return dbUser;
}

/**
 * requireUser
 * Guard function for Server Actions that require a logged-in user (student or admin).
 * Throws an AuthError("UNAUTHORIZED") if no active session exists.
 */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("UNAUTHORIZED");
  return user;
}

/**
 * requireAdmin
 * Guard function for Server Actions that strictly require Administrator privileges.
 * Throws an AuthError("FORBIDDEN") if the user is not an active ADMIN.
 */
export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "ADMIN") throw new AuthError("FORBIDDEN");
  return user;
}

/**
 * pageUser
 * Guard function for Server Component Pages.
 * Redirects unauthenticated visitors to the /login page instead of throwing an unhandled exception.
 */
export async function pageUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/**
 * pageAdmin
 * Guard function for Server Component Admin Pages.
 * Redirects non-admin students to /dashboard if they attempt to access admin control panel routes.
 */
export async function pageAdmin() {
  const user = await pageUser();
  if (user.role !== "ADMIN") redirect("/dashboard");
  return user;
}
