import { relations } from "drizzle-orm";
import { index, integer, primaryKey, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
import { createId } from "@/utils/id";

// Enums are stored as TEXT (SQLite has no native enums) and typed via `as const` arrays. Add roles like FACULTY here later.
export const roleEnum = ["STUDENT", "ADMIN"] as const;
export const dayEnum = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"] as const;
export const submissionStatusEnum = ["PENDING", "SUBMITTED", "COMPLETED"] as const;
export const eventStatusEnum = ["DRAFT", "PUBLISHED", "CANCELLED"] as const;
export const priorityEnum = ["LOW", "NORMAL", "HIGH", "URGENT"] as const;
export const mealEnum = ["BREAKFAST", "LUNCH", "SNACKS", "BEVERAGES"] as const;
export const lostKindEnum = ["LOST", "FOUND"] as const;
export const lostStatusEnum = ["LOST", "POSSIBLY_FOUND", "FOUND", "CLOSED"] as const;
export const reportStatusEnum = ["OPEN", "RESOLVED", "DISMISSED"] as const;
export const contactPrefEnum = ["IN_APP", "PICKUP_AT_OFFICE"] as const;
export const notifTypeEnum = [
  "LOST_RESPONSE", "LOST_FOUND", "LOST_MESSAGE", "ASSIGNMENT_ADDED", "ASSIGNMENT_DEADLINE",
  "EVENT_ADDED", "ANNOUNCEMENT", "TIMETABLE_UPDATE", "ADMIN_MESSAGE",
] as const;

export const activationStatusEnum = ["NOT_ACTIVATED", "ACTIVATED"] as const;
export const otpTypeEnum = ["ACTIVATION", "FORGOT_PASSWORD"] as const;

const id = () => text("id").primaryKey().$defaultFn(createId);
const createdAt = () => integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date());
const updatedAt = () => integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()).$onUpdate(() => new Date());

// ───────── Identity ─────────
export const courses = sqliteTable("courses", {
  id: id(),
  code: text("code").notNull().unique(), // BCA | BBA | BCOM | BJMC
  name: text("name").notNull(),
  description: text("description"),
  semesters: integer("semesters").notNull().default(6),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
});

export const studentsMaster = sqliteTable("students_master", {
  id: id(),
  studentId: text("student_id").notNull().unique(), // e.g. SHC2504022
  fullName: text("full_name").notNull(),
  registeredMobile: text("registered_mobile").notNull(),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  department: text("department"),
  academicYear: text("academic_year"), // e.g. 1st Year / 2025-2026
  semester: integer("semester"),
  section: text("section"),
  rollNumber: text("roll_number"),
  dob: text("dob"),
  admissionSession: text("admission_session"),
  fatherName: text("father_name"),
  motherName: text("mother_name"),
  parentContact: text("parent_contact"),
  localAddress: text("local_address"),
  activationStatus: text("activation_status", { enum: activationStatusEnum }).notNull().default("NOT_ACTIVATED"),
  status: text("status").notNull().default("ACTIVE"), // ACTIVE | DISABLED
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("sm_student_id_idx").on(t.studentId),
  index("sm_course_idx").on(t.courseId, t.semester),
]);

export const users = sqliteTable("users", {
  id: id(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role", { enum: roleEnum }).notNull().default("STUDENT"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  semester: integer("semester"),
  studentId: text("student_id").unique(),
  showStudentId: integer("show_student_id", { mode: "boolean" }).notNull().default(false),
  image: text("image"),
  isDemo: integer("is_demo", { mode: "boolean" }).notNull().default(false),
  registeredMobile: text("registered_mobile"),
  department: text("department"),
  academicYear: text("academic_year"),
  section: text("section"),
  rollNumber: text("roll_number"),
  dob: text("dob"),
  fatherName: text("father_name"),
  motherName: text("mother_name"),
  parentContact: text("parent_contact"),
  localAddress: text("local_address"),
  activationStatus: text("activation_status").notNull().default("ACTIVATED"),
  studentMasterId: text("student_master_id").references(() => studentsMaster.id, { onDelete: "set null" }),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("users_role_idx").on(t.role), index("users_course_sem_idx").on(t.courseId, t.semester), index("users_name_idx").on(t.name), index("users_student_id_idx").on(t.studentId)]);

export const otps = sqliteTable("otps", {
  id: id(),
  studentId: text("student_id").notNull(),
  mobile: text("mobile").notNull(),
  otpHash: text("otp_hash").notNull(),
  rawOtpForDev: text("raw_otp_for_dev"),
  type: text("type", { enum: otpTypeEnum }).notNull(),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
  attempts: integer("attempts").notNull().default(0),
  used: integer("used", { mode: "boolean" }).notNull().default(false),
  createdAt: createdAt(),
}, (t) => [
  index("otps_lookup_idx").on(t.studentId, t.type, t.used),
]);

// Placeholder stats (clearly flagged demo). A real attendance module can replace this later.
export const studentStats = sqliteTable("student_stats", {
  id: id(),
  userId: text("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  attendancePct: integer("attendance_pct").notNull().default(0),
  studyStreak: integer("study_streak").notNull().default(0),
  progressPct: integer("progress_pct").notNull().default(0),
  isDemo: integer("is_demo", { mode: "boolean" }).notNull().default(true),
});

// ───────── Academics ─────────
export const timetable = sqliteTable("timetable_entries", {
  id: id(),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  day: text("day", { enum: dayEnum }).notNull(),
  startTime: text("start_time").notNull(), // "09:00"
  endTime: text("end_time").notNull(),
  subject: text("subject").notNull(),
  faculty: text("faculty"),
  room: text("room"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("tt_lookup_idx").on(t.courseId, t.semester, t.day)]);

// Official College Timetable Architecture
export const timetablesMaster = sqliteTable("timetables_master", {
  id: id(),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  academicYear: text("academic_year"), // e.g. "3rd Year"
  section: text("section"), // e.g. "A"
  title: text("title").notNull().default("CLASS TIME TABLE"), // e.g. "BCA Vth SEMESTER"
  effectiveDate: text("effective_date").notNull().default("20th July, 2026"), // e.g. "20th July, 2026"
  classAdvisor: text("class_advisor"), // e.g. "Mr Izhar Ahmad"
  published: integer("published", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("ttm_course_sem_idx").on(t.courseId, t.semester, t.published),
]);

export const timetableSlots = sqliteTable("timetable_slots", {
  id: id(),
  timetableId: text("timetable_id").notNull().references(() => timetablesMaster.id, { onDelete: "cascade" }),
  day: text("day", { enum: dayEnum }).notNull(),
  startPeriod: integer("start_period").notNull(), // 1 to 6
  spanPeriods: integer("span_periods").notNull().default(1), // 1 to 6 (for merged cells)
  entryType: text("entry_type").notNull().default("NORMAL_CLASS"),
  facultyName: text("faculty_name"), // Stored SEPARATELY
  subjectName: text("subject_name"), // Stored SEPARATELY
  isSpecialActivity: integer("is_special_activity", { mode: "boolean" }).notNull().default(false),
  activityTitle: text("activity_title"), // e.g. "Club Activity"
  activityDescription: text("activity_description"), // e.g. "[students will join their respective clubs]"
  colorTheme: text("color_theme"), // e.g. "amber", "emerald", "blue", "purple", "rose"
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("tts_lookup_idx").on(t.timetableId, t.day, t.startPeriod),
]);

export const notes = sqliteTable("notes", {
  id: id(),
  title: text("title").notNull(),
  description: text("description"),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  subject: text("subject").notNull(),
  fileUrl: text("file_url").notNull(),
  fileName: text("file_name"),
  fileType: text("file_type"),
  uploadedById: text("uploaded_by_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("notes_lookup_idx").on(t.courseId, t.semester, t.subject), index("notes_title_idx").on(t.title)]);

export const assignments = sqliteTable("assignments", {
  id: id(),
  title: text("title").notNull(),
  description: text("description"),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  subject: text("subject").notNull(),
  dueDate: integer("due_date", { mode: "timestamp_ms" }).notNull(),
  attachmentUrl: text("attachment_url"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("asg_lookup_idx").on(t.courseId, t.semester, t.dueDate)]);

export const assignmentSubmissions = sqliteTable("assignment_submissions", {
  id: id(),
  assignmentId: text("assignment_id").notNull().references(() => assignments.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status", { enum: submissionStatusEnum }).notNull().default("PENDING"),
  updatedAt: updatedAt(),
}, (t) => [uniqueIndex("asub_unique").on(t.assignmentId, t.userId)]);

// ───────── Campus life ─────────
export const datePrecisionEnum = ["EXACT_DATE", "DATE_RANGE", "MONTH_ONLY", "TBD"] as const;
export const eventLifecycleEnum = ["UPCOMING", "ONGOING", "COMPLETED", "TBD", "CANCELLED"] as const;
export const sourceTypeEnum = ["USER_SUPPLIED", "OFFICIAL_WEBSITE", "ADMIN_ENTERED", "VERIFIED"] as const;
export const verificationStatusEnum = ["UNVERIFIED", "VERIFIED"] as const;

export const events = sqliteTable("events", {
  id: id(),
  title: text("title").notNull(),
  slug: text("slug"),
  shortDescription: text("short_description"),
  description: text("description"),
  date: text("date").notNull(),
  startDate: text("start_date"),
  endDate: text("end_date"),
  datePrecision: text("date_precision", { enum: datePrecisionEnum }).notNull().default("EXACT_DATE"),
  startTime: text("start_time"),
  endTime: text("end_time"),
  location: text("location"),
  venue: text("venue"),
  category: text("category").notNull().default("CULTURAL"),
  imageUrl: text("image_url"),
  status: text("status", { enum: eventStatusEnum }).notNull().default("PUBLISHED"),
  eventStatus: text("event_status", { enum: eventLifecycleEnum }).notNull().default("UPCOMING"),
  featured: integer("featured", { mode: "boolean" }).notNull().default(false),
  registrationEnabled: integer("registration_enabled", { mode: "boolean" }).notNull().default(false),
  registrationDeadline: text("registration_deadline"),
  registrationUrl: text("registration_url"),
  contactInfo: text("contact_info"),
  organizer: text("organizer"),
  tags: text("tags"),
  sourceType: text("source_type", { enum: sourceTypeEnum }).notNull().default("USER_SUPPLIED"),
  sourceUrl: text("source_url"),
  verificationStatus: text("verification_status", { enum: verificationStatusEnum }).notNull().default("UNVERIFIED"),
  published: integer("published", { mode: "boolean" }).notNull().default(true),
  deletedAt: text("deleted_at"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("events_date_idx").on(t.date, t.status)]);

export const eventRegistrations = sqliteTable("event_registrations", {
  id: id(),
  eventId: text("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("REGISTERED"),
  registeredAt: integer("registered_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [
  uniqueIndex("ereg_unique_idx").on(t.eventId, t.userId),
  index("ereg_event_idx").on(t.eventId),
  index("ereg_user_idx").on(t.userId),
]);

export const announcements = sqliteTable("announcements", {
  id: id(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull().default("General"),
  priority: text("priority", { enum: priorityEnum }).notNull().default("NORMAL"),
  published: integer("published", { mode: "boolean" }).notNull().default(false),
  publishedAt: integer("published_at", { mode: "timestamp_ms" }),
  createdById: text("created_by_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("ann_pub_idx").on(t.published, t.publishedAt)]);

export const announcementReads = sqliteTable("announcement_reads", {
  announcementId: text("announcement_id").notNull().references(() => announcements.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  readAt: integer("read_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [primaryKey({ columns: [t.announcementId, t.userId] })]);

export const canteenItems = sqliteTable("canteen_items", {
  id: id(),
  date: text("date").notNull(),
  meal: text("meal", { enum: mealEnum }).notNull(),
  name: text("name").notNull(),
  price: integer("price").notNull(), // INR
  available: integer("available", { mode: "boolean" }).notNull().default(true),
  imageUrl: text("image_url"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("canteen_date_idx").on(t.date, t.meal)]);

// ───────── Lost & Found ─────────
export const lostCategories = sqliteTable("lost_categories", {
  id: id(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  order: integer("order").notNull().default(0),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
});

export const lostPosts = sqliteTable("lost_posts", {
  id: id(),
  kind: text("kind", { enum: lostKindEnum }).notNull().default("LOST"),
  status: text("status", { enum: lostStatusEnum }).notNull().default("LOST"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  details: text("details"), // identifying details: visible only to owner + admins
  categoryId: text("category_id").notNull().references(() => lostCategories.id),
  location: text("location").notNull(),
  occurredOn: text("occurred_on").notNull(),
  approxTime: text("approx_time"),
  contactPref: text("contact_pref", { enum: contactPrefEnum }).notNull().default("IN_APP"),
  hidden: integer("hidden", { mode: "boolean" }).notNull().default(false),
  authorId: text("author_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("lp_feed_idx").on(t.kind, t.status, t.hidden, t.createdAt),
  index("lp_cat_idx").on(t.categoryId), index("lp_loc_idx").on(t.location), index("lp_author_idx").on(t.authorId),
]);

export const lostImages = sqliteTable("lost_images", {
  id: id(),
  postId: text("post_id").notNull().references(() => lostPosts.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  order: integer("order").notNull().default(0),
}, (t) => [index("li_post_idx").on(t.postId)]);

export const lostResponses = sqliteTable("lost_responses", {
  id: id(),
  postId: text("post_id").notNull().references(() => lostPosts.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  message: text("message").notNull(),
  foundAt: text("found_at").notNull(),
  foundOn: text("found_on").notNull(),
  imageUrl: text("image_url"),
  contactInfo: text("contact_info"), // visible only to post owner
  createdAt: createdAt(),
}, (t) => [index("lr_post_idx").on(t.postId, t.createdAt)]);

// Private thread between post owner and one other student. Polling now; maps 1:1 to a realtime channel later.
export const lostThreads = sqliteTable("lost_threads", {
  id: id(),
  postId: text("post_id").notNull().references(() => lostPosts.id, { onDelete: "cascade" }),
  ownerId: text("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  otherId: text("other_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex("lt_unique").on(t.postId, t.ownerId, t.otherId), index("lt_owner_idx").on(t.ownerId), index("lt_other_idx").on(t.otherId)]);

export const lostMessages = sqliteTable("lost_messages", {
  id: id(),
  threadId: text("thread_id").notNull().references(() => lostThreads.id, { onDelete: "cascade" }),
  senderId: text("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  createdAt: createdAt(),
}, (t) => [index("lm_thread_idx").on(t.threadId, t.createdAt)]);

export const lostReports = sqliteTable("lost_reports", {
  id: id(),
  postId: text("post_id").notNull().references(() => lostPosts.id, { onDelete: "cascade" }),
  reporterId: text("reporter_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  reason: text("reason").notNull(),
  status: text("status", { enum: reportStatusEnum }).notNull().default("OPEN"),
  resolution: text("resolution"),
  createdAt: createdAt(),
}, (t) => [index("lrep_status_idx").on(t.status, t.createdAt)]);

// ───────── Notifications ─────────
export const notifications = sqliteTable("notifications", {
  id: id(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: text("type", { enum: notifTypeEnum }).notNull(),
  title: text("title").notNull(),
  body: text("body"),
  link: text("link"),
  read: integer("read", { mode: "boolean" }).notNull().default(false),
  createdAt: createdAt(),
}, (t) => [index("notif_user_idx").on(t.userId, t.read, t.createdAt)]);

// ───────── Fees & Payments ─────────
export const fineTypeEnum = ["NONE", "PER_DAY", "FIXED", "PERCENTAGE"] as const;
export const paymentStatusEnum = ["PAID", "PENDING", "FAILED", "REFUNDED", "ADJUSTED"] as const;

export const feeStructures = sqliteTable("fee_structures", {
  id: id(),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  academicSession: text("academic_session").notNull().default("2026-27"),
  admissionFee: integer("admission_fee").notNull().default(2000),
  tuitionFee: integer("tuition_fee").notNull(),
  studentDevelopmentFee: integer("student_development_fee").notNull().default(1000),
  universityExamFee: text("university_exam_fee").notNull().default("AS_PER_UNIVERSITY"),
  sourceNote: text("source_note").default("Fee structure reference: Study Hall College official website — Fee Structure 2026-27."),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("fs_course_session_idx").on(t.courseId, t.academicSession),
]);

export const feeDueRules = sqliteTable("fee_due_rules", {
  id: id(),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  academicSession: text("academic_session").notNull().default("2026-27"),
  dueDate: text("due_date").notNull().default("2026-10-15"),
  fineType: text("fine_type", { enum: fineTypeEnum }).notNull().default("PER_DAY"),
  fineValue: integer("fine_value").notNull().default(50),
  maxFine: integer("max_fine").default(2500),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("fdr_course_session_idx").on(t.courseId, t.academicSession),
]);

export const feePayments = sqliteTable("fee_payments", {
  id: id(),
  studentId: text("student_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  feeStructureId: text("fee_structure_id").notNull().references(() => feeStructures.id, { onDelete: "cascade" }),
  amount: integer("amount").notNull(),
  feeType: text("fee_type").notNull().default("TUITION_FEE"),
  paymentDate: text("payment_date").notNull(),
  paymentMethod: text("payment_method").notNull().default("UPI"),
  transactionId: text("transaction_id").notNull().unique(),
  receiptNumber: text("receipt_number").notNull().unique(),
  status: text("status", { enum: paymentStatusEnum }).notNull().default("PAID"),
  notes: text("notes"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("fp_student_idx").on(t.studentId, t.paymentDate),
  index("fp_txn_idx").on(t.transactionId),
  index("fp_receipt_idx").on(t.receiptNumber),
]);

// ───────── Subjects & Attendance ─────────
export const attendanceStatusEnum = ["PRESENT", "ABSENT", "LATE"] as const;

export const subjects = sqliteTable("subjects", {
  id: id(),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  credits: integer("credits").notNull().default(3),
  facultyName: text("faculty_name"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("subj_code_course_sem").on(t.courseId, t.semester, t.code),
  index("subj_course_sem_idx").on(t.courseId, t.semester),
]);

export const attendanceSessions = sqliteTable("attendance_sessions", {
  id: id(),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  section: text("section").notNull().default("A"),
  subjectId: text("subject_id").notNull().references(() => subjects.id, { onDelete: "cascade" }),
  date: text("date").notNull(), // YYYY-MM-DD
  startTime: text("start_time"),
  facultyId: text("faculty_id").references(() => users.id, { onDelete: "set null" }),
  totalStudents: integer("total_students").notNull().default(0),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("atts_course_sem_sub_date_idx").on(t.courseId, t.semester, t.section, t.subjectId, t.date),
]);

export const attendanceRecords = sqliteTable("attendance_records", {
  id: id(),
  sessionId: text("session_id").notNull().references(() => attendanceSessions.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  studentMasterId: text("student_master_id").references(() => studentsMaster.id, { onDelete: "set null" }),
  status: text("status", { enum: attendanceStatusEnum }).notNull().default("PRESENT"),
  remarks: text("remarks"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("attr_session_user_idx").on(t.sessionId, t.userId),
  index("attr_user_idx").on(t.userId),
]);

// ───────── Exams & Results ─────────
export const examTypeEnum = ["INTERNAL", "SEMESTER", "PRACTICAL", "OTHER"] as const;
export const resultStatusEnum = ["PASS", "FAIL", "ABSENT", "WITHHELD", "NOT_PUBLISHED"] as const;

export const exams = sqliteTable("exams", {
  id: id(),
  title: text("title").notNull(),
  examType: text("exam_type", { enum: examTypeEnum }).notNull().default("INTERNAL"),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  semester: integer("semester").notNull(),
  academicYear: text("academic_year"),
  section: text("section"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  instructions: text("instructions"),
  published: integer("published", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("exams_course_sem_idx").on(t.courseId, t.semester, t.published),
]);

export const examSubjects = sqliteTable("exam_subjects", {
  id: id(),
  examId: text("exam_id").notNull().references(() => exams.id, { onDelete: "cascade" }),
  subjectId: text("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  subjectName: text("subject_name").notNull(),
  examDate: text("exam_date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  venue: text("venue"),
  maxMarks: integer("max_marks").notNull().default(100),
  passMarks: integer("pass_marks").notNull().default(40),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("esub_exam_idx").on(t.examId),
]);

export const studentResults = sqliteTable("student_results", {
  id: id(),
  examId: text("exam_id").notNull().references(() => exams.id, { onDelete: "cascade" }),
  subjectId: text("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  studentMasterId: text("student_master_id").references(() => studentsMaster.id, { onDelete: "set null" }),
  internalMarks: integer("internal_marks"),
  externalMarks: integer("external_marks"),
  practicalMarks: integer("practical_marks"),
  totalMarks: integer("total_marks").notNull(),
  maxMarks: integer("max_marks").notNull().default(100),
  grade: text("grade"),
  resultStatus: text("result_status", { enum: resultStatusEnum }).notNull().default("PASS"),
  remarks: text("remarks"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("sr_exam_user_subj_idx").on(t.examId, t.userId, t.subjectId),
  index("sr_user_idx").on(t.userId),
]);

// ───────── Academic Calendar ─────────
export const calendarCategoryEnum = ["SEMESTER_START", "SEMESTER_END", "EXAM", "HOLIDAY", "EVENT", "DEADLINE", "COLLEGE_DATE"] as const;

export const academicCalendarEvents = sqliteTable("academic_calendar_events", {
  id: id(),
  title: text("title").notNull(),
  category: text("category", { enum: calendarCategoryEnum }).notNull().default("COLLEGE_DATE"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date"),
  description: text("description"),
  courseId: text("course_id").references(() => courses.id, { onDelete: "cascade" }),
  department: text("department"),
  isGlobal: integer("is_global", { mode: "boolean" }).notNull().default(true),
  createdById: text("created_by_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("ace_dates_idx").on(t.startDate, t.isGlobal),
]);

// ───────── Grievance / Help Desk ─────────
export const grievanceCategoryEnum = ["ACADEMIC", "FEE", "TIMETABLE", "INFRASTRUCTURE", "TECHNICAL"] as const;
export const grievanceStatusEnum = ["OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"] as const;

export const grievanceTickets = sqliteTable("grievance_tickets", {
  id: id(),
  ticketNumber: text("ticket_number").notNull().unique(), // e.g. TCK-2026-001
  category: text("category", { enum: grievanceCategoryEnum }).notNull().default("ACADEMIC"),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status", { enum: grievanceStatusEnum }).notNull().default("OPEN"),
  priority: text("priority", { enum: priorityEnum }).notNull().default("NORMAL"),
  adminResponse: text("admin_response"),
  resolvedAt: integer("resolved_at", { mode: "timestamp_ms" }),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("gt_user_idx").on(t.userId, t.createdAt),
  index("gt_status_idx").on(t.status, t.createdAt),
]);

// ───────── Directories ─────────
export const facultyDirectory = sqliteTable("faculty_directory", {
  id: id(),
  name: text("name").notNull(),
  department: text("department").notNull(),
  designation: text("designation").notNull(),
  qualification: text("qualification"),
  subjectsTaught: text("subjects_taught"),
  email: text("email"),
  officeRoom: text("office_room"),
  avatarUrl: text("avatar_url"),
  order: integer("order").notNull().default(0),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("fac_dept_idx").on(t.department, t.active),
]);

export const campusDirectory = sqliteTable("campus_directory", {
  id: id(),
  name: text("name").notNull(),
  category: text("category").notNull().default("DEPARTMENT"),
  building: text("building").notNull().default("Main Block"),
  floor: text("floor"),
  roomNumber: text("room_number"),
  description: text("description"),
  openingHours: text("opening_hours"),
  imageUrl: text("image_url"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [
  index("cd_cat_idx").on(t.category, t.active),
]);

// ───────── Relations ─────────
export const usersRel = relations(users, ({ one, many }) => ({
  course: one(courses, { fields: [users.courseId], references: [courses.id] }),
  stats: one(studentStats, { fields: [users.id], references: [studentStats.userId] }),
  payments: many(feePayments),
}));
export const lostPostsRel = relations(lostPosts, ({ one, many }) => ({
  author: one(users, { fields: [lostPosts.authorId], references: [users.id] }),
  category: one(lostCategories, { fields: [lostPosts.categoryId], references: [lostCategories.id] }),
  images: many(lostImages),
  responses: many(lostResponses),
  reports: many(lostReports),
}));
export const lostImagesRel = relations(lostImages, ({ one }) => ({ post: one(lostPosts, { fields: [lostImages.postId], references: [lostPosts.id] }) }));
export const lostResponsesRel = relations(lostResponses, ({ one }) => ({
  post: one(lostPosts, { fields: [lostResponses.postId], references: [lostPosts.id] }),
  user: one(users, { fields: [lostResponses.userId], references: [users.id] }),
}));
export const lostReportsRel = relations(lostReports, ({ one }) => ({
  post: one(lostPosts, { fields: [lostReports.postId], references: [lostPosts.id] }),
  reporter: one(users, { fields: [lostReports.reporterId], references: [users.id] }),
}));
export const lostThreadsRel = relations(lostThreads, ({ one, many }) => ({
  post: one(lostPosts, { fields: [lostThreads.postId], references: [lostPosts.id] }),
  messages: many(lostMessages),
}));
export const lostMessagesRel = relations(lostMessages, ({ one }) => ({
  thread: one(lostThreads, { fields: [lostMessages.threadId], references: [lostThreads.id] }),
  sender: one(users, { fields: [lostMessages.senderId], references: [users.id] }),
}));
export const assignmentsRel = relations(assignments, ({ one, many }) => ({
  course: one(courses, { fields: [assignments.courseId], references: [courses.id] }),
  submissions: many(assignmentSubmissions),
}));
export const notesRel = relations(notes, ({ one }) => ({ course: one(courses, { fields: [notes.courseId], references: [courses.id] }) }));
export const timetablesMasterRel = relations(timetablesMaster, ({ one, many }) => ({
  course: one(courses, { fields: [timetablesMaster.courseId], references: [courses.id] }),
  slots: many(timetableSlots),
}));
export const timetableSlotsRel = relations(timetableSlots, ({ one }) => ({
  timetable: one(timetablesMaster, { fields: [timetableSlots.timetableId], references: [timetablesMaster.id] }),
}));
export const feeStructuresRel = relations(feeStructures, ({ one, many }) => ({
  course: one(courses, { fields: [feeStructures.courseId], references: [courses.id] }),
  payments: many(feePayments),
}));
export const feeDueRulesRel = relations(feeDueRules, ({ one }) => ({
  course: one(courses, { fields: [feeDueRules.courseId], references: [courses.id] }),
}));
export const feePaymentsRel = relations(feePayments, ({ one }) => ({
  student: one(users, { fields: [feePayments.studentId], references: [users.id] }),
  feeStructure: one(feeStructures, { fields: [feePayments.feeStructureId], references: [feeStructures.id] }),
}));

export const eventsRel = relations(events, ({ many }) => ({
  registrations: many(eventRegistrations),
}));

export const eventRegistrationsRel = relations(eventRegistrations, ({ one }) => ({
  event: one(events, { fields: [eventRegistrations.eventId], references: [events.id] }),
  user: one(users, { fields: [eventRegistrations.userId], references: [users.id] }),
}));

export type User = typeof users.$inferSelect;
export type Course = typeof courses.$inferSelect;
export type StudentMaster = typeof studentsMaster.$inferSelect;
export type Otp = typeof otps.$inferSelect;
export type TimetableMaster = typeof timetablesMaster.$inferSelect;
export type TimetableSlot = typeof timetableSlots.$inferSelect;
export type FeeStructure = typeof feeStructures.$inferSelect;
export type FeeDueRule = typeof feeDueRules.$inferSelect;
export type FeePayment = typeof feePayments.$inferSelect;
export type Event = typeof events.$inferSelect;
export type EventRegistration = typeof eventRegistrations.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type AttendanceSession = typeof attendanceSessions.$inferSelect;
export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type Exam = typeof exams.$inferSelect;
export type ExamSubject = typeof examSubjects.$inferSelect;
export type StudentResult = typeof studentResults.$inferSelect;
export type AcademicCalendarEvent = typeof academicCalendarEvents.$inferSelect;
export type GrievanceTicket = typeof grievanceTickets.$inferSelect;
export type FacultyDirectory = typeof facultyDirectory.$inferSelect;
export type CampusDirectory = typeof campusDirectory.$inferSelect;





