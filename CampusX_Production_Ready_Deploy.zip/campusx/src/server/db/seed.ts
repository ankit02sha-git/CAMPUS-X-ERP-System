import "dotenv/config";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "./index";
import { courses, lostCategories, lostImages, lostPosts, studentStats, users, notifications, studentsMaster } from "./schema";

const COURSES = [
  { code: "BCA", name: "Bachelor of Computer Applications", semesters: 6 },
  { code: "BBA", name: "Bachelor of Business Administration", semesters: 6 },
  { code: "BCOM", name: "Bachelor of Commerce", semesters: 6 },
  { code: "BJMC", name: "Bachelor of Journalism & Mass Communication", semesters: 6 },
];
const CATEGORIES = ["ID Card", "Wallet", "Phone", "Keys", "Bag", "Books", "Electronics", "Clothing", "Accessories", "Other"];
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

async function main() {
  const prod = process.env.NODE_ENV === "production";
  const adminEmail = process.env.SEED_ADMIN_EMAIL;
  const adminPw = process.env.SEED_ADMIN_PASSWORD;
  const studentPw = process.env.SEED_DEMO_STUDENT_PASSWORD;
  if (!adminEmail || !adminPw) throw new Error("Set SEED_ADMIN_EMAIL and SEED_ADMIN_PASSWORD (see .env.example).");
  if (prod && (adminPw.length < 12)) throw new Error("Use a strong SEED_ADMIN_PASSWORD (12+ chars) in production.");

  // Idempotent: upserts only, never deletes existing data.
  for (const c of COURSES) await db.insert(courses).values(c).onConflictDoNothing({ target: courses.code });
  for (const [i, name] of CATEGORIES.entries())
    await db.insert(lostCategories).values({ name, slug: slug(name), order: i }).onConflictDoNothing({ target: lostCategories.slug });

  await db.insert(users).values({
    name: "CampusX Admin", email: adminEmail.toLowerCase(), passwordHash: await bcrypt.hash(adminPw, 12), role: "ADMIN",
  }).onConflictDoNothing({ target: users.email });

  if (!prod && studentPw) {
    const [bca] = await db.select().from(courses).where(eq(courses.code, "BCA"));
    const hash = await bcrypt.hash(studentPw, 12);
    const demo = [
      { name: "Aarav Sharma", email: "aarav.demo@campusx.local", studentId: "DEMO-SHC-001", stats: { attendancePct: 87, studyStreak: 12, progressPct: 64 } },
      { name: "Diya Verma", email: "diya.demo@campusx.local", studentId: "DEMO-SHC-002", stats: { attendancePct: 92, studyStreak: 5, progressPct: 71 } },
    ];
    for (const d of demo) {
      const ins = await db.insert(users).values({
        name: d.name, email: d.email, passwordHash: hash, courseId: bca.id, semester: 3, studentId: d.studentId, isDemo: true,
      }).onConflictDoNothing({ target: users.email }).returning();
      if (ins[0]) await db.insert(studentStats).values({ userId: ins[0].id, ...d.stats, isDemo: true });
    }
    const [aarav] = await db.select().from(users).where(eq(users.email, "aarav.demo@campusx.local"));
    const existing = await db.select().from(lostPosts).where(eq(lostPosts.authorId, aarav.id)).limit(1);
    if (!existing.length) {
      const cats = await db.select().from(lostCategories);
      const cat = (n: string) => cats.find((c) => c.name === n)!.id;
      const today = new Date().toISOString().slice(0, 10);
      const [p1] = await db.insert(lostPosts).values({
        kind: "LOST", title: "Black Wallet (DEMO)", description: "Black leather wallet with college ID. Demo post for illustration.",
        categoryId: cat("Wallet"), location: "Library", occurredOn: today, approxTime: "14:00", authorId: aarav.id,
      }).returning();
      void p1; void lostImages; void notifications;
    }
  }
  // Seed master students records for activation
  const [bcaCourse] = await db.select().from(courses).where(eq(courses.code, "BCA")).limit(1);
  if (bcaCourse) {
    const masterStudents = [
      { studentId: "SHC2504023", fullName: "Rahul Verma", registeredMobile: "+919876543210", courseId: bcaCourse.id, semester: 2, section: "A", department: "Computer Applications", academicYear: "1st Year", rollNumber: "2504023" },
      { studentId: "DEMO-SHC-001", fullName: "Aarav Sharma", registeredMobile: "+919876543211", courseId: bcaCourse.id, semester: 3, section: "A", department: "Computer Applications", academicYear: "2nd Year", rollNumber: "101" },
      { studentId: "DEMO-SHC-002", fullName: "Diya Verma", registeredMobile: "+919876543212", courseId: bcaCourse.id, semester: 3, section: "B", department: "Computer Applications", academicYear: "2nd Year", rollNumber: "102" },
      { studentId: "SHC2025001", fullName: "Ananya Roy", registeredMobile: "+919876548210", courseId: bcaCourse.id, semester: 1, section: "A", department: "Computer Applications", academicYear: "1st Year", rollNumber: "2025001" },
    ];
    for (const ms of masterStudents) {
      await db.insert(studentsMaster).values({
        ...ms,
        activationStatus: (ms.studentId === "DEMO-SHC-001" || ms.studentId === "DEMO-SHC-002") ? "ACTIVATED" : "NOT_ACTIVATED",
      }).onConflictDoNothing({ target: studentsMaster.studentId });
    }
  }

  console.log("Seed complete.");
  process.exit(0);
}
main().catch((e) => { console.error(e); process.exit(1); });
