import { db } from "./index";
import { eq, and } from "drizzle-orm";
import { courses, timetableSlots, timetablesMaster } from "./schema";

export async function seedBcom5Timetable() {
  console.log("Seeding B.Com 5th Semester Official Timetable...");

  // 1. Find or insert BCOM course
  let [bcom] = await db.select().from(courses).where(eq(courses.code, "BCOM")).limit(1);
  if (!bcom) {
    [bcom] = await db
      .insert(courses)
      .values({ code: "BCOM", name: "Bachelor of Commerce", semesters: 6 })
      .returning();
  }

  // 2. Find or create master timetable entry for BCOM Sem 5
  let masterId: string;
  const [existingMaster] = await db
    .select()
    .from(timetablesMaster)
    .where(and(eq(timetablesMaster.courseId, bcom.id), eq(timetablesMaster.semester, 5)))
    .limit(1);

  if (!existingMaster) {
    const [tm] = await db
      .insert(timetablesMaster)
      .values({
        courseId: bcom.id,
        semester: 5,
        academicYear: "3rd Year",
        section: "A",
        title: "B.COM V Semester",
        effectiveDate: "20th July, 2026",
        classAdvisor: "Mr Ankit Srivastava",
        published: true,
      })
      .returning();
    masterId = tm.id;
  } else {
    masterId = existingMaster.id;
    await db
      .update(timetablesMaster)
      .set({
        title: "B.COM V Semester",
        effectiveDate: "20th July, 2026",
        classAdvisor: "Mr Ankit Srivastava",
        published: true,
      })
      .where(eq(timetablesMaster.id, masterId));

    // Clear old slots for B.Com 5th sem to replace cleanly
    await db.delete(timetableSlots).where(eq(timetableSlots.timetableId, masterId));
  }

  // 3. Define the exact slots
  const slots = [
    // --- MONDAY ---
    { day: "MONDAY", startPeriod: 1, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Export Import Procedure & Documentation", facultyName: "Ms Roshini" },
    { day: "MONDAY", startPeriod: 2, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Cost Accounting", facultyName: "Ms Roshini" },
    { day: "MONDAY", startPeriod: 3, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Employability Enhancement Program - Aptitude", facultyName: "Dr Naval" },
    { day: "MONDAY", startPeriod: 4, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "PDP", facultyName: "Dr Ruth" },
    { day: "MONDAY", startPeriod: 5, spanPeriods: 1, entryType: "FREE_PERIOD", subjectName: "FREE PERIOD", facultyName: null },
    { day: "MONDAY", startPeriod: 6, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Foreign Trade of India", facultyName: "Ms SY" },

    // --- TUESDAY ---
    { day: "TUESDAY", startPeriod: 1, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Export Import Procedure & Documentation", facultyName: "Ms Roshini" },
    { day: "TUESDAY", startPeriod: 2, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Foreign Trade of India", facultyName: "Ms SY" },
    { day: "TUESDAY", startPeriod: 3, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Cost Accounting", facultyName: "Ms Roshini" },
    {
      day: "TUESDAY",
      startPeriod: 4,
      spanPeriods: 1,
      entryType: "LIBRARY_ACTIVITY",
      isSpecialActivity: true,
      activityTitle: "LIBRARY",
      activityDescription: "[NEWSPAPER READING/\nASSIGNMENTS/\nNOTES MAKING]",
      facultyName: "Ms Amrita",
      colorTheme: "amber",
    },
    { day: "TUESDAY", startPeriod: 5, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Summer Internship / Minor Project", facultyName: "AS" },
    { day: "TUESDAY", startPeriod: 6, spanPeriods: 1, entryType: "FREE_PERIOD", subjectName: "FREE PERIOD", facultyName: null },

    // --- WEDNESDAY ---
    { day: "WEDNESDAY", startPeriod: 1, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Cost Accounting", facultyName: "Ms Roshini" },
    { day: "WEDNESDAY", startPeriod: 2, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Export Import Procedure & Documentation", facultyName: "Ms Roshini" },
    { day: "WEDNESDAY", startPeriod: 3, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "CRITICAL DIALOGUE", facultyName: "Mr A S" },
    { day: "WEDNESDAY", startPeriod: 4, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Company Law & Practice", facultyName: "Ms S M M" },
    { day: "WEDNESDAY", startPeriod: 5, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Summer Internship / Minor Project", facultyName: "AS" },
    { day: "WEDNESDAY", startPeriod: 6, spanPeriods: 1, entryType: "FREE_PERIOD", subjectName: "FREE PERIOD", facultyName: null },

    // --- THURSDAY ---
    { day: "THURSDAY", startPeriod: 1, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Foreign Trade of India", facultyName: "Ms SY" },
    { day: "THURSDAY", startPeriod: 2, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Export Import Procedure & Documentation", facultyName: "Ms Roshini" },
    { day: "THURSDAY", startPeriod: 3, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "LIFE PLAN", facultyName: null },
    { day: "THURSDAY", startPeriod: 4, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Theatres", facultyName: "Mr S T D" },
    { day: "THURSDAY", startPeriod: 5, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Company Law & Practice", facultyName: "Ms S M M" },
    { day: "THURSDAY", startPeriod: 6, spanPeriods: 1, entryType: "FREE_PERIOD", subjectName: "FREE PERIOD", facultyName: null },

    // --- FRIDAY ---
    { day: "FRIDAY", startPeriod: 1, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Cost Accounting", facultyName: "Ms Roshini" },
    { day: "FRIDAY", startPeriod: 2, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Company Law & Practice", facultyName: "Ms S M M" },
    { day: "FRIDAY", startPeriod: 3, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "PDP", facultyName: "Dr Ruth" },
    {
      day: "FRIDAY",
      startPeriod: 4,
      spanPeriods: 3, // P4 + P5 + P6 merged cell
      entryType: "MERGED_ACTIVITY",
      isSpecialActivity: true,
      activityTitle: "CLUB ACTIVITIES",
      colorTheme: "purple",
    },

    // --- SATURDAY ---
    { day: "SATURDAY", startPeriod: 1, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Foreign Trade of India", facultyName: "Ms SY" },
    { day: "SATURDAY", startPeriod: 2, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Company Law & Practice", facultyName: "Ms S M M" },
    {
      day: "SATURDAY",
      startPeriod: 3,
      spanPeriods: 1,
      entryType: "LIBRARY_ACTIVITY",
      isSpecialActivity: true,
      activityTitle: "LIBRARY",
      facultyName: null,
      colorTheme: "amber",
    },
    { day: "SATURDAY", startPeriod: 4, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "Employability Enhancement Program - Aptitude", facultyName: "Dr Naval" },
    { day: "SATURDAY", startPeriod: 5, spanPeriods: 1, entryType: "FREE_PERIOD", subjectName: "FREE PERIOD", facultyName: null },
    { day: "SATURDAY", startPeriod: 6, spanPeriods: 1, entryType: "NORMAL_CLASS", subjectName: "SPORTS", facultyName: "Mr Vishwajeet", colorTheme: "emerald" },
  ];

  for (const s of slots) {
    await db.insert(timetableSlots).values({
      timetableId: masterId,
      day: s.day as "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY",
      startPeriod: s.startPeriod,
      spanPeriods: s.spanPeriods,
      entryType: s.entryType,
      facultyName: s.facultyName || null,
      subjectName: s.subjectName || null,
      isSpecialActivity: Boolean(s.isSpecialActivity),
      activityTitle: s.activityTitle || null,
      activityDescription: s.activityDescription || null,
      colorTheme: s.colorTheme || null,
    });
  }

  console.log("B.Com 5th Semester Timetable Seeded Successfully!");
}

if (require.main === module) {
  seedBcom5Timetable()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("B.Com timetable seed failed:", err);
      process.exit(1);
    });
}
