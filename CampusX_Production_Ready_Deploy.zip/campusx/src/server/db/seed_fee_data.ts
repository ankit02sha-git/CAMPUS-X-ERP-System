import { db } from "./index";
import { eq, inArray } from "drizzle-orm";
import { courses, users, feeStructures, feeDueRules, feePayments } from "./schema";
import { OFFICIAL_FEE_DEFAULTS, computeKnownAnnualFee } from "../../lib/fees";

export async function seedFeeData() {
  console.log("=== Seeding Official Fee Structures & Demo Student Payments ===");

  const allCourses = await db.select().from(courses);
  if (allCourses.length === 0) {
    console.log("No courses found in database.");
    return;
  }

  // 1. Seed Fee Structures and Due Rules for all 4 courses (BCA, BBA, BCOM, BJMC)
  const feeStructureMap = new Map<string, string>(); // courseId -> feeStructureId

  for (const def of OFFICIAL_FEE_DEFAULTS) {
    const matchedCourse = allCourses.find(
      (c) => c.code.toUpperCase() === def.code || c.code.toUpperCase().replace(".", "") === def.code
    );

    if (!matchedCourse) continue;

    let [existingFs] = await db
      .select()
      .from(feeStructures)
      .where(eq(feeStructures.courseId, matchedCourse.id))
      .limit(1);

    if (!existingFs) {
      [existingFs] = await db
        .insert(feeStructures)
        .values({
          courseId: matchedCourse.id,
          academicSession: "2026-27",
          admissionFee: def.admissionFee,
          tuitionFee: def.tuitionFee,
          studentDevelopmentFee: def.studentDevelopmentFee,
          universityExamFee: def.universityExamFee,
          sourceNote:
            "Fee structure reference: Study Hall College official website — Fee Structure 2026-27.",
        })
        .returning();
      console.log(`✓ Inserted Fee Structure for ${def.code}`);
    }
    feeStructureMap.set(matchedCourse.id, existingFs.id);

    // Seed Due Date Rule
    let [existingRule] = await db
      .select()
      .from(feeDueRules)
      .where(eq(feeDueRules.courseId, matchedCourse.id))
      .limit(1);

    if (!existingRule) {
      await db.insert(feeDueRules).values({
        courseId: matchedCourse.id,
        academicSession: "2026-27",
        dueDate: "2026-10-15",
        fineType: "PER_DAY",
        fineValue: 50,
        maxFine: 2500,
        active: true,
      });
      console.log(`✓ Inserted Fee Due Rule for ${def.code}`);
    }
  }

  // 2. Fetch Existing Student Users
  const studentUsers = await db
    .select()
    .from(users)
    .where(eq(users.role, "STUDENT"));

  console.log(`Found ${studentUsers.length} existing student user records.`);

  let seededPaymentsCount = 0;
  let receiptCounter = 1001;

  for (const student of studentUsers) {
    // If courseId is missing, default to BCA course
    const courseId = student.courseId || allCourses.find((c) => c.code === "BCA")?.id;
    if (!courseId) continue;

    const fsId = feeStructureMap.get(courseId);
    if (!fsId) continue;

    // Check if student already has payments
    const existingPayments = await db
      .select()
      .from(feePayments)
      .where(eq(feePayments.studentId, student.id));

    if (existingPayments.length > 0) {
      console.log(`Student ${student.name} (${student.studentId || student.id}) already has payments. Skipping.`);
      continue;
    }

    // Determine target payment ratio (0%, 35%, 60%, or 100%) based on student ID char code
    const [targetFs] = await db.select().from(feeStructures).where(eq(feeStructures.id, fsId)).limit(1);
    if (!targetFs) continue;

    const totalKnownFee = computeKnownAnnualFee(targetFs);
    const hash = (student.id + (student.studentId || "")).split("").reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
    const ratioVariant = hash % 4; // 0 = 100% paid, 1 = 60% paid, 2 = 35% paid, 3 = 0% paid

    let totalToPay = 0;
    if (ratioVariant === 0) totalToPay = totalKnownFee;
    else if (ratioVariant === 1) totalToPay = Math.round((totalKnownFee * 0.6) / 1000) * 1000;
    else if (ratioVariant === 2) totalToPay = Math.round((totalKnownFee * 0.35) / 1000) * 1000;
    else totalToPay = 0;

    if (totalToPay === 0) continue;

    // Create 1 or 2 payment records totaling totalToPay
    const numTransactions = totalToPay >= 40000 ? 2 : 1;
    const paymentMethods = ["UPI", "BANK_TRANSFER", "CASH", "CARD"];
    const feeTypes = ["ADMISSION_FEE", "TUITION_FEE", "DEVELOPMENT_FEE"];

    let remainingToDistribute = totalToPay;

    for (let i = 0; i < numTransactions; i++) {
      const isLast = i === numTransactions - 1;
      const amt = isLast
        ? remainingToDistribute
        : Math.round((remainingToDistribute * 0.4) / 1000) * 1000;

      if (amt <= 0) continue;
      remainingToDistribute -= amt;

      const dateStr = i === 0 ? "2026-07-25" : "2026-08-28";
      const method = paymentMethods[(hash + i) % paymentMethods.length];
      const feeType = feeTypes[i % feeTypes.length];
      const txnId = `TXN-2026-${method}-${Math.floor(100000 + Math.random() * 900000)}`;
      const receiptNo = `SHC-REC-2026-${receiptCounter++}`;

      await db.insert(feePayments).values({
        studentId: student.id,
        feeStructureId: fsId,
        amount: amt,
        feeType: feeType,
        paymentDate: dateStr,
        paymentMethod: method,
        transactionId: txnId,
        receiptNumber: receiptNo,
        status: "PAID",
        notes: `Demo Payment Entry #${i + 1} (${feeType})`,
      });

      seededPaymentsCount++;
    }
  }

  console.log(`✓ Fee seeding completed. Generated ${seededPaymentsCount} demo payment records.`);
}

if (require.main === module) {
  seedFeeData()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Fee seeding failed:", err);
      process.exit(1);
    });
}
