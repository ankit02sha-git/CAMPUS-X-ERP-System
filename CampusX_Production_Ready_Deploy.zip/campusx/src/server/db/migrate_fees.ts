import { db } from "./index";
import { sql } from "drizzle-orm";

async function main() {
  console.log("Running migration: creating fee tables...");

  await db.run(sql`
    CREATE TABLE IF NOT EXISTS fee_structures (
      id TEXT PRIMARY KEY NOT NULL,
      course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      academic_session TEXT NOT NULL DEFAULT '2026-27',
      admission_fee INTEGER NOT NULL DEFAULT 2000,
      tuition_fee INTEGER NOT NULL,
      student_development_fee INTEGER NOT NULL DEFAULT 1000,
      university_exam_fee TEXT NOT NULL DEFAULT 'AS_PER_UNIVERSITY',
      source_note TEXT DEFAULT 'Fee structure reference: Study Hall College official website — Fee Structure 2026-27.',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  await db.run(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS fs_course_session_idx ON fee_structures(course_id, academic_session);
  `);

  await db.run(sql`
    CREATE TABLE IF NOT EXISTS fee_due_rules (
      id TEXT PRIMARY KEY NOT NULL,
      course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      academic_session TEXT NOT NULL DEFAULT '2026-27',
      due_date TEXT NOT NULL DEFAULT '2026-10-15',
      fine_type TEXT NOT NULL DEFAULT 'PER_DAY',
      fine_value INTEGER NOT NULL DEFAULT 50,
      max_fine INTEGER DEFAULT 2500,
      active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  await db.run(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS fdr_course_session_idx ON fee_due_rules(course_id, academic_session);
  `);

  await db.run(sql`
    CREATE TABLE IF NOT EXISTS fee_payments (
      id TEXT PRIMARY KEY NOT NULL,
      student_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      fee_structure_id TEXT NOT NULL REFERENCES fee_structures(id) ON DELETE CASCADE,
      amount INTEGER NOT NULL,
      fee_type TEXT NOT NULL DEFAULT 'TUITION_FEE',
      payment_date TEXT NOT NULL,
      payment_method TEXT NOT NULL DEFAULT 'UPI',
      transaction_id TEXT NOT NULL UNIQUE,
      receipt_number TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'PAID',
      notes TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  await db.run(sql`
    CREATE INDEX IF NOT EXISTS fp_student_idx ON fee_payments(student_id, payment_date);
  `);
  await db.run(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS fp_txn_idx ON fee_payments(transaction_id);
  `);
  await db.run(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS fp_receipt_idx ON fee_payments(receipt_number);
  `);

  console.log("Migration SUCCESS: Fee tables created safely.");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Fee migration failed:", err);
    process.exit(1);
  });
