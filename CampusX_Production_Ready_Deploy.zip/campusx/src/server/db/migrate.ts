import "dotenv/config";
import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import { migrate } from "drizzle-orm/libsql/migrator";

// Creates dev.db automatically on first run, then applies ./drizzle/*.sql.
async function main() {
  const client = createClient({ url: process.env.DATABASE_URL ?? "file:./dev.db" });
  await client.execute("PRAGMA foreign_keys = ON");
  await migrate(drizzle(client), { migrationsFolder: "./drizzle" });
  client.close();
  console.log("Migrations applied.");
}
main().catch((e) => { console.error(e); process.exit(1); });
