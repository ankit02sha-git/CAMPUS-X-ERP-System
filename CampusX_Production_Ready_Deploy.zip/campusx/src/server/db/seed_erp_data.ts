import "dotenv/config";
import { db } from "./index";
import {
  courses,
  users,
  studentsMaster,
  subjects,
  attendanceSessions,
  attendanceRecords,
  exams,
  examSubjects,
  studentResults,
  academicCalendarEvents,
  grievanceTickets,
  facultyDirectory,
  campusDirectory,
} from "./schema";
import { eq, and } from "drizzle-orm";
import { createId } from "@/utils/id";

async function seedErpData() {
  console.log("=== Seeding Core ERP & Student Portal Data ===");

  const [bca] = await db.select().from(courses).where(eq(courses.code, "BCA")).limit(1);
  const [bcom] = await db.select().from(courses).where(eq(courses.code, "BCOM")).limit(1);

  if (!bca) {
    console.error("BCA course not found. Run npm run seed first.");
    process.exit(1);
  }

  // 1. Seed Subjects for BCA Sem 3
  const bcaSubjects = [
    { code: "BCA-301", name: "Artificial Intelligence", credits: 4, facultyName: "Mr Izhar Ahmad" },
    { code: "BCA-302", name: "Data Structures & Algorithms", credits: 4, facultyName: "Ms Priya Saxena" },
    { code: "BCA-303", name: "Database Management Systems", credits: 4, facultyName: "Mr Izhar Ahmad" },
    { code: "BCA-304", name: "Operating Systems", credits: 3, facultyName: "Mr Izhar Ahmad" },
    { code: "BCA-305", name: "Cyber Law & Ethics", credits: 2, facultyName: "Ms Ananya Singh" },
  ];

  const createdSubjects: Record<string, string> = {};

  for (const s of bcaSubjects) {
    let [existing] = await db
      .select()
      .from(subjects)
      .where(and(eq(subjects.courseId, bca.id), eq(subjects.semester, 3), eq(subjects.code, s.code)))
      .limit(1);

    if (!existing) {
      [existing] = await db
        .insert(subjects)
        .values({
          id: createId(),
          courseId: bca.id,
          semester: 3,
          code: s.code,
          name: s.name,
          credits: s.credits,
          facultyName: s.facultyName,
        })
        .returning();
    }
    createdSubjects[s.code] = existing.id;
  }

  // Fetch demo student
  const [aarav] = await db.select().from(users).where(eq(users.email, "aarav.demo@campusx.local")).limit(1);
  const [diya] = await db.select().from(users).where(eq(users.email, "diya.demo@campusx.local")).limit(1);

  if (aarav) {
    const today = new Date().toISOString().slice(0, 10);

    // 2. Attendance Data for Artificial Intelligence (High Attendance ~ 86.5%)
    const aiSubjId = createdSubjects["BCA-301"];
    if (aiSubjId) {
      // Create 37 past class sessions
      for (let i = 1; i <= 37; i++) {
        const dateStr = `2026-08-${String((i % 25) + 1).padStart(2, "0")}`;
        const [sess] = await db
          .insert(attendanceSessions)
          .values({
            id: createId(),
            courseId: bca.id,
            semester: 3,
            section: "A",
            subjectId: aiSubjId,
            date: dateStr,
            startTime: "09:00",
            totalStudents: 30,
          })
          .returning();

        // Aarav present 32 times, absent 5 times
        const isAbsent = i === 5 || i === 12 || i === 18 || i === 27 || i === 34;
        await db.insert(attendanceRecords).values({
          id: createId(),
          sessionId: sess.id,
          userId: aarav.id,
          status: isAbsent ? "ABSENT" : "PRESENT",
        }).onConflictDoNothing();
      }
    }

    // 2b. Attendance Data for Cyber Law (Low Attendance ~ 66.7% - Triggering Warning!)
    const cyberSubjId = createdSubjects["BCA-305"];
    if (cyberSubjId) {
      for (let i = 1; i <= 15; i++) {
        const dateStr = `2026-09-${String((i % 20) + 1).padStart(2, "0")}`;
        const [sess] = await db
          .insert(attendanceSessions)
          .values({
            id: createId(),
            courseId: bca.id,
            semester: 3,
            section: "A",
            subjectId: cyberSubjId,
            date: dateStr,
            startTime: "11:00",
            totalStudents: 30,
          })
          .returning();

        // Aarav present 10, absent 5
        const isAbsent = i === 2 || i === 4 || i === 7 || i === 11 || i === 14;
        await db.insert(attendanceRecords).values({
          id: createId(),
          sessionId: sess.id,
          userId: aarav.id,
          status: isAbsent ? "ABSENT" : "PRESENT",
        }).onConflictDoNothing();
      }
    }

    // 3. Exams & Results Data
    const [exam1] = await db
      .insert(exams)
      .values({
        id: createId(),
        title: "BCA 3rd Semester Mid-Term Examination 2026",
        examType: "INTERNAL",
        courseId: bca.id,
        semester: 3,
        academicYear: "2nd Year",
        section: "A",
        startDate: "2026-10-10",
        endDate: "2026-10-16",
        instructions: "Reporting time is 09:30 AM. Mobile phones and smartwatches strictly prohibited in exam hall.",
        published: true,
      })
      .onConflictDoNothing()
      .returning();

    if (exam1 && aiSubjId) {
      const [exSubj1] = await db
        .insert(examSubjects)
        .values({
          id: createId(),
          examId: exam1.id,
          subjectId: aiSubjId,
          subjectName: "Artificial Intelligence",
          examDate: "2026-10-10",
          startTime: "10:00 AM",
          endTime: "01:00 PM",
          venue: "Main Auditorium Block B",
          maxMarks: 100,
          passMarks: 40,
        })
        .onConflictDoNothing()
        .returning();

      // Demo result for Aarav
      await db
        .insert(studentResults)
        .values({
          id: createId(),
          examId: exam1.id,
          subjectId: aiSubjId,
          userId: aarav.id,
          internalMarks: 24,
          externalMarks: 62,
          totalMarks: 86,
          maxMarks: 100,
          grade: "A+",
          resultStatus: "PASS",
          remarks: "Outstanding analytical performance.",
        })
        .onConflictDoNothing();
    }

    // 4. Academic Calendar Events
    const calEvents = [
      { title: "Commencement of BCA/BBA Semester III Classes", category: "SEMESTER_START", startDate: "2026-07-20", isGlobal: true, description: "Official start date of Semester III academic session." },
      { title: "Mid-Term Examination Week", category: "EXAM", startDate: "2026-10-10", endDate: "2026-10-16", isGlobal: true, description: "Internal assessment examinations for all undergraduate cohorts." },
      { title: "Gandhi Jayanti Holiday", category: "HOLIDAY", startDate: "2026-10-02", isGlobal: true, description: "College closed on account of Gandhi Jayanti." },
      { title: "AAGAT 2026 Annual Youth Fest", category: "EVENT", startDate: "2026-11-14", endDate: "2026-11-16", isGlobal: true, description: "Annual cultural & sports flagship fest of Study Hall College." },
      { title: "End Semester University Exams", category: "EXAM", startDate: "2026-12-15", endDate: "2026-12-28", isGlobal: true, description: "Lucknow University semester final examinations." },
    ];

    for (const ce of calEvents) {
      await db.insert(academicCalendarEvents).values({
        id: createId(),
        ...ce,
        category: ce.category as any,
      }).onConflictDoNothing();
    }

    // 5. Grievance Tickets
    await db
      .insert(grievanceTickets)
      .values({
        id: createId(),
        ticketNumber: "TCK-2026-0891",
        category: "INFRASTRUCTURE",
        subject: "Projector Display Flickering in Room 204",
        description: "The ceiling projector in Computer Lab Room 204 flickers during AI lecture presentations.",
        userId: aarav.id,
        status: "RESOLVED",
        priority: "NORMAL",
        adminResponse: "IT support replaced the HDMI display cabling on Sept 22. Issue resolved.",
        resolvedAt: new Date(Date.now() - 86400000 * 3),
      })
      .onConflictDoNothing();

    await db
      .insert(grievanceTickets)
      .values({
        id: createId(),
        ticketNumber: "TCK-2026-0942",
        category: "TIMETABLE",
        subject: "Timetable Clash Query for Elective Session",
        description: "Seeking clarification regarding the Friday afternoon lab period timing.",
        userId: aarav.id,
        status: "OPEN",
        priority: "NORMAL",
      })
      .onConflictDoNothing();
  }

  // 6. Faculty Directory
  const facultyMembers = [
    { name: "Mr Izhar Ahmad", department: "Computer Applications", designation: "Head of Department (HOD) & Assistant Professor", qualification: "M.Tech (CSE), MCA", subjectsTaught: "Artificial Intelligence, Operating Systems, C++", email: "izhar.ahmad@studyhall.ac.in", officeRoom: "Room 104, Main Academic Block", order: 1 },
    { name: "Dr Smriti Verma", department: "Commerce & Management", designation: "Associate Professor & Dean", qualification: "Ph.D, M.Com, MBA", subjectsTaught: "Corporate Accounting, Financial Management", email: "smriti.verma@studyhall.ac.in", officeRoom: "Room 201, Commerce Wing", order: 2 },
    { name: "Ms Ananya Singh", department: "Journalism & Mass Comm", designation: "Assistant Professor", qualification: "M.A. (Mass Communication)", subjectsTaught: "Media Ethics, Digital Journalism, Public Relations", email: "ananya.singh@studyhall.ac.in", officeRoom: "Media Lab, 2nd Floor", order: 3 },
    { name: "Dr Rajesh Gupta", department: "Business Administration", designation: "Assistant Professor", qualification: "Ph.D (Management), MBA", subjectsTaught: "Business Statistics, Strategic Management", email: "rajesh.gupta@studyhall.ac.in", officeRoom: "Room 108, BBA Block", order: 4 },
  ];

  for (const fm of facultyMembers) {
    await db.insert(facultyDirectory).values({
      id: createId(),
      ...fm,
    }).onConflictDoNothing();
  }

  // 7. Campus Directory
  const campusLocations = [
    { name: "Central Computer Laboratory 1", category: "LAB", building: "Main Block", floor: "2nd Floor", roomNumber: "Lab 204", description: "60 High-performance i7 workstations with Linux & Windows dual-boot setup.", openingHours: "08:30 AM - 04:30 PM" },
    { name: "Study Hall College Library", category: "LIBRARY", building: "Academic Wing B", floor: "1st Floor", roomNumber: "LIB-101", description: "Over 15,000 academic titles, reference journals, e-library kiosks and quiet study zones.", openingHours: "08:00 AM - 05:00 PM" },
    { name: "College Canteen & Refreshment Center", category: "CANTEEN", building: "Campus Plaza", floor: "Ground Floor", roomNumber: "Canteen Hall", description: "Fresh meals, snacks, beverages and outdoor seating area.", openingHours: "08:30 AM - 04:00 PM" },
    { name: "Department of Computer Applications (BCA Office)", category: "DEPARTMENT", building: "Main Block", floor: "1st Floor", roomNumber: "Room 104", description: "Faculty cabins, HOD office, and student query helpdesk.", openingHours: "09:00 AM - 04:00 PM" },
    { name: "Main Multipurpose Auditorium", category: "ACTIVITY_AREA", building: "Auditorium Block", floor: "Ground Floor", roomNumber: "Auditorium 1", description: "500-seat soundproof hall for seminars, annual youth fests and guest lectures.", openingHours: "Event Based" },
  ];

  for (const cl of campusLocations) {
    await db.insert(campusDirectory).values({
      id: createId(),
      ...cl,
    }).onConflictDoNothing();
  }

  console.log("=== Core ERP Seed Data Complete ===");
  process.exit(0);
}

seedErpData().catch((e) => {
  console.error("Failed to seed ERP data:", e);
  process.exit(1);
});
