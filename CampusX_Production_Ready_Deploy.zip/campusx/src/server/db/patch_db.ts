import { createClient } from "@libsql/client";

async function main() {
  const client = createClient({ url: process.env.DATABASE_URL ?? "file:./dev.db" });
  const columns = ["dob", "father_name", "mother_name", "parent_contact", "local_address"];
  
  for (const col of columns) {
    try {
      await client.execute(`ALTER TABLE users ADD COLUMN ${col} TEXT`);
      console.log(`Added column ${col} to users`);
    } catch (e: any) {
      console.log(`Column ${col} on users: ${e?.message || "already exists"}`);
    }

    try {
      await client.execute(`ALTER TABLE students_master ADD COLUMN ${col} TEXT`);
      console.log(`Added column ${col} to students_master`);
    } catch (e: any) {
      console.log(`Column ${col} on students_master: ${e?.message || "already exists"}`);
    }
  }

  console.log("Database schema patch completed successfully.");
}

main().catch(console.error);
