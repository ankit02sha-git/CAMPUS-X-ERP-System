import { db } from "./index";
import { sql } from "drizzle-orm";

async function migrateEventsV2() {
  console.log("=== Running Additive Database Migration for Events V2 Columns ===");

  const columnsToAdd = [
    { name: "registration_url", type: "TEXT" },
    { name: "contact_info", type: "TEXT" },
    { name: "organizer", type: "TEXT" },
    { name: "tags", type: "TEXT" },
    { name: "deleted_at", type: "TEXT" },
  ];

  for (const col of columnsToAdd) {
    try {
      await db.run(sql.raw(`ALTER TABLE events ADD COLUMN ${col.name} ${col.type}`));
      console.log(`✓ Added column '${col.name}' to table 'events'.`);
    } catch (e: any) {
      if (e.message?.includes("duplicate column name")) {
        console.log(`- Column '${col.name}' already exists.`);
      } else {
        console.error(`- Note on column '${col.name}':`, e.message);
      }
    }
  }

  console.log("=== Migration V2 Complete ===");
}

migrateEventsV2()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("Migration failed:", e);
    process.exit(1);
  });
