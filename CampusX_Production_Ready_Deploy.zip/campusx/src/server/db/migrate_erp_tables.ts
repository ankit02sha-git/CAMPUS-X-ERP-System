import "dotenv/config";
import { db } from "./index";
import { sql } from "drizzle-orm";

async function runErpMigrations() {
  console.log("=== Running Additive Migrations for Core ERP & Student Portal Tables ===");

  const tableQueries = [
    `CREATE TABLE IF NOT EXISTS subjects (
      id TEXT PRIMARY KEY NOT NULL,
      course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      semester INTEGER NOT NULL,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 3,
      faculty_name TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS attendance_sessions (
      id TEXT PRIMARY KEY NOT NULL,
      course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      semester INTEGER NOT NULL,
      section TEXT NOT NULL DEFAULT 'A',
      subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      start_time TEXT,
      faculty_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      total_students INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS attendance_records (
      id TEXT PRIMARY KEY NOT NULL,
      session_id TEXT NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_master_id TEXT REFERENCES students_master(id) ON DELETE SET NULL,
      status TEXT NOT NULL DEFAULT 'PRESENT',
      remarks TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS exams (
      id TEXT PRIMARY KEY NOT NULL,
      title TEXT NOT NULL,
      exam_type TEXT NOT NULL DEFAULT 'INTERNAL',
      course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      semester INTEGER NOT NULL,
      academic_year TEXT,
      section TEXT,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      instructions TEXT,
      published INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS exam_subjects (
      id TEXT PRIMARY KEY NOT NULL,
      exam_id TEXT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
      subject_name TEXT NOT NULL,
      exam_date TEXT NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      venue TEXT,
      max_marks INTEGER NOT NULL DEFAULT 100,
      pass_marks INTEGER NOT NULL DEFAULT 40,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS student_results (
      id TEXT PRIMARY KEY NOT NULL,
      exam_id TEXT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      student_master_id TEXT REFERENCES students_master(id) ON DELETE SET NULL,
      internal_marks INTEGER,
      external_marks INTEGER,
      practical_marks INTEGER,
      total_marks INTEGER NOT NULL,
      max_marks INTEGER NOT NULL DEFAULT 100,
      grade TEXT,
      result_status TEXT NOT NULL DEFAULT 'PASS',
      remarks TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS academic_calendar_events (
      id TEXT PRIMARY KEY NOT NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'COLLEGE_DATE',
      start_date TEXT NOT NULL,
      end_date TEXT,
      description TEXT,
      course_id TEXT REFERENCES courses(id) ON DELETE CASCADE,
      department TEXT,
      is_global INTEGER NOT NULL DEFAULT 1,
      created_by_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS grievance_tickets (
      id TEXT PRIMARY KEY NOT NULL,
      ticket_number TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL DEFAULT 'ACADEMIC',
      subject TEXT NOT NULL,
      description TEXT NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'OPEN',
      priority TEXT NOT NULL DEFAULT 'NORMAL',
      admin_response TEXT,
      resolved_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS faculty_directory (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      department TEXT NOT NULL,
      designation TEXT NOT NULL,
      qualification TEXT,
      subjects_taught TEXT,
      email TEXT,
      office_room TEXT,
      avatar_url TEXT,
      "order" INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,

    `CREATE TABLE IF NOT EXISTS campus_directory (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'DEPARTMENT',
      building TEXT NOT NULL DEFAULT 'Main Block',
      floor TEXT,
      room_number TEXT,
      description TEXT,
      opening_hours TEXT,
      image_url TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );`,
  ];

  for (const query of tableQueries) {
    try {
      await db.run(sql.raw(query));
    } catch (e: any) {
      console.log(`Note on migration query: ${e.message}`);
    }
  }

  console.log("=== Additive Migrations Complete ===");
}

runErpMigrations()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("Migration failed:", e);
    process.exit(1);
  });
