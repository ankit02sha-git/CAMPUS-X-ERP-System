import { sql, type SQL } from "drizzle-orm";
import type { AnySQLiteColumn } from "drizzle-orm/sqlite-core";

/** SQLite replacement for Postgres ILIKE. LIKE is case-insensitive for ASCII; callers pass a pre-escaped
 *  pattern (\%, \_, \\ escaped) and we declare `\` as the escape character. */
export function ilike(col: AnySQLiteColumn, pattern: string): SQL {
  return sql`${col} LIKE ${pattern} ESCAPE '\\'`;
}
