import { db } from "./index";
import { sql } from "drizzle-orm";

export async function runTimetableMigration() {
  console.log("Running timetable additive migration...");

  // 1. Create timetables_master table
  await db.run(sql`
    CREATE TABLE IF NOT EXISTS timetables_master (
      id TEXT PRIMARY KEY NOT NULL,
      course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      semester INTEGER NOT NULL,
      academic_year TEXT,
      section TEXT,
      title TEXT NOT NULL DEFAULT 'CLASS TIME TABLE',
      effective_date TEXT NOT NULL DEFAULT '20th July, 2026',
      class_advisor TEXT,
      published INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  // 2. Create timetable_slots table
  await db.run(sql`
    CREATE TABLE IF NOT EXISTS timetable_slots (
      id TEXT PRIMARY KEY NOT NULL,
      timetable_id TEXT NOT NULL REFERENCES timetables_master(id) ON DELETE CASCADE,
      day TEXT NOT NULL,
      start_period INTEGER NOT NULL,
      span_periods INTEGER NOT NULL DEFAULT 1,
      faculty_name TEXT,
      subject_name TEXT,
      is_special_activity INTEGER NOT NULL DEFAULT 0,
      activity_title TEXT,
      activity_description TEXT,
      color_theme TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  console.log("Timetable migration completed successfully.");
}

if (require.main === module) {
  runTimetableMigration()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Timetable migration failed:", err);
      process.exit(1);
    });
}
