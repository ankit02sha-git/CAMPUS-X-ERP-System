import { db } from "./index";
import { sql } from "drizzle-orm";

export async function runAdditiveMigration() {
  console.log("Running additive database migration...");

  // 1. Create students_master table
  await db.run(sql`
    CREATE TABLE IF NOT EXISTS students_master (
      id TEXT PRIMARY KEY NOT NULL,
      student_id TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      registered_mobile TEXT NOT NULL,
      course_id TEXT REFERENCES courses(id) ON DELETE SET NULL,
      department TEXT,
      academic_year TEXT,
      semester INTEGER,
      section TEXT,
      roll_number TEXT,
      dob TEXT,
      admission_session TEXT,
      activation_status TEXT NOT NULL DEFAULT 'NOT_ACTIVATED',
      status TEXT NOT NULL DEFAULT 'ACTIVE',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  // 2. Create otps table
  await db.run(sql`
    CREATE TABLE IF NOT EXISTS otps (
      id TEXT PRIMARY KEY NOT NULL,
      student_id TEXT NOT NULL,
      mobile TEXT NOT NULL,
      otp_hash TEXT NOT NULL,
      raw_otp_for_dev TEXT,
      type TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      used INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );
  `);

  // 3. Safely add missing columns to users table
  const userColumnsRaw = await db.all(sql`PRAGMA table_info(users)`);
  const existingCols = new Set((userColumnsRaw as { name: string }[]).map((c) => c.name));

  if (!existingCols.has("registered_mobile")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN registered_mobile TEXT;`);
  }
  if (!existingCols.has("department")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN department TEXT;`);
  }
  if (!existingCols.has("academic_year")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN academic_year TEXT;`);
  }
  if (!existingCols.has("section")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN section TEXT;`);
  }
  if (!existingCols.has("roll_number")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN roll_number TEXT;`);
  }
  if (!existingCols.has("activation_status")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN activation_status TEXT NOT NULL DEFAULT 'ACTIVATED';`);
  }
  if (!existingCols.has("student_master_id")) {
    await db.run(sql`ALTER TABLE users ADD COLUMN student_master_id TEXT REFERENCES students_master(id) ON DELETE SET NULL;`);
  }

  console.log("Additive database migration completed successfully.");
}

if (require.main === module) {
  runAdditiveMigration()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Migration failed:", err);
      process.exit(1);
    });
}
