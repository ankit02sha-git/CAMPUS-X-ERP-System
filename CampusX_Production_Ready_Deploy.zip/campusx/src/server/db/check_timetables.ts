import { db } from "./index";
import { timetablesMaster, timetableSlots, courses } from "./schema";
import { eq } from "drizzle-orm";

async function check() {
  const ms = await db
    .select({ t: timetablesMaster, code: courses.code })
    .from(timetablesMaster)
    .innerJoin(courses, eq(timetablesMaster.courseId, courses.id));

  console.log("Found Timetables:", ms.map(x => ({ id: x.t.id, course: x.code, semester: x.t.semester, section: x.t.section, title: x.t.title })));

  for (const item of ms) {
    const slots = await db
      .select()
      .from(timetableSlots)
      .where(eq(timetableSlots.timetableId, item.t.id));

    const academicPairs = slots
      .filter(s => s.entryType === "NORMAL_CLASS" && s.subjectName && !s.isSpecialActivity)
      .map(s => `${s.subjectName} — ${s.facultyName || "N/A"}`);

    const uniquePairs = Array.from(new Set(academicPairs));

    console.log(`\nAcademic Subjects/Faculty for ${item.code} Semester ${item.t.semester}:`);
    console.log(uniquePairs);
  }

  process.exit(0);
}

check().catch(e => { console.error(e); process.exit(1); });
