import { db } from "./index";
import { sql } from "drizzle-orm";

async function addColumn(table: string, columnDef: string) {
  try {
    await db.run(sql.raw(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`));
    console.log(`✓ Added column ${columnDef.split(" ")[0]} to ${table}`);
  } catch (e: any) {
    if (e.message?.includes("duplicate column name")) {
      // Column already exists, skip
    } else {
      console.warn(`Column warning (${table}):`, e.message);
    }
  }
}

async function main() {
  console.log("=== Migrating Events Schema ===");

  // 1. Add missing columns to events table safely
  await addColumn("events", "slug TEXT");
  await addColumn("events", "short_description TEXT");
  await addColumn("events", "start_date TEXT");
  await addColumn("events", "end_date TEXT");
  await addColumn("events", "date_precision TEXT NOT NULL DEFAULT 'EXACT_DATE'");
  await addColumn("events", "venue TEXT");
  await addColumn("events", "event_status TEXT NOT NULL DEFAULT 'UPCOMING'");
  await addColumn("events", "featured INTEGER NOT NULL DEFAULT 0");
  await addColumn("events", "registration_enabled INTEGER NOT NULL DEFAULT 0");
  await addColumn("events", "registration_deadline TEXT");
  await addColumn("events", "source_type TEXT NOT NULL DEFAULT 'USER_SUPPLIED'");
  await addColumn("events", "source_url TEXT");
  await addColumn("events", "verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED'");
  await addColumn("events", "published INTEGER NOT NULL DEFAULT 1");

  // 2. Create event_registrations table
  await db.run(sql`
    CREATE TABLE IF NOT EXISTS event_registrations (
      id TEXT PRIMARY KEY NOT NULL,
      event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'REGISTERED',
      registered_at INTEGER NOT NULL
    );
  `);

  await db.run(sql`
    CREATE UNIQUE INDEX IF NOT EXISTS ereg_unique_idx ON event_registrations(event_id, user_id);
  `);
  await db.run(sql`
    CREATE INDEX IF NOT EXISTS ereg_event_idx ON event_registrations(event_id);
  `);
  await db.run(sql`
    CREATE INDEX IF NOT EXISTS ereg_user_idx ON event_registrations(user_id);
  `);

  console.log("Migration SUCCESS: Events schema updated.");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Migration failed:", err);
    process.exit(1);
  });
