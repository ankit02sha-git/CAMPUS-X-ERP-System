import "dotenv/config";
import { db } from "./index";
import { studentsMaster } from "./schema";
import { eq } from "drizzle-orm";
import { todayKey } from "@/lib/utils";

async function seedBirthdays() {
  const todayStr = todayKey(); // e.g. "2026-09-27"
  const parts = todayStr.split("-");
  const month = parts[1];
  const day = parts[2];

  // Give Aarav Sharma and Diya Verma birthdays TODAY for testing
  const todayDob1 = `2004-${month}-${day}`;
  const todayDob2 = `2005-${month}-${day}`;

  const updates = [
    { studentId: "DEMO-SHC-001", dob: todayDob1 },
    { studentId: "DEMO-SHC-002", dob: todayDob2 },
    { studentId: "SHC2504023", dob: "2003-03-15" },
    { studentId: "SHC2025001", dob: "2004-11-20" },
  ];

  for (const item of updates) {
    await db
      .update(studentsMaster)
      .set({ dob: item.dob, status: "ACTIVE" })
      .where(eq(studentsMaster.studentId, item.studentId));
  }

  console.log(`Updated student DOBs for testing. Today's date set to: ${todayStr}`);
  process.exit(0);
}

seedBirthdays().catch((err) => {
  console.error("Failed to seed birthdays:", err);
  process.exit(1);
});
