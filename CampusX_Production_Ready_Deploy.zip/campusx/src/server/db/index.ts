import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import * as schema from "./schema";

// Local SQLite file (DATABASE_URL="file:./dev.db"). No database server needed.
const g = globalThis as unknown as { __db?: ReturnType<typeof drizzle<typeof schema>> };
const client = createClient({
  url: process.env.DATABASE_URL ?? "file:./dev.db",
  authToken: process.env.DATABASE_AUTH_TOKEN,
});
void client.execute("PRAGMA foreign_keys = ON"); // enforce relationships / cascades
export const db = g.__db ?? drizzle(client, { schema });
if (process.env.NODE_ENV !== "production") g.__db = db;
export { schema };
