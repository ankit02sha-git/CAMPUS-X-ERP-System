import "dotenv/config";
import { db } from "./index";
import { subjects } from "./schema";
import { eq, or } from "drizzle-orm";

async function updateDbmsFaculty() {
  await db
    .update(subjects)
    .set({ facultyName: "Mr Izhar Ahmad" })
    .where(or(eq(subjects.code, "BCA-303"), eq(subjects.name, "Database Management Systems")));

  console.log("Updated faculty of Database Management Systems to Mr Izhar Ahmad.");
  process.exit(0);
}

updateDbmsFaculty().catch((err) => {
  console.error("Failed to update DBMS faculty:", err);
  process.exit(1);
});
