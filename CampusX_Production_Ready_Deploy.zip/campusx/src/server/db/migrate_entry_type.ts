import { db } from "./index";
import { sql } from "drizzle-orm";

async function main() {
  console.log("Running migration: adding entry_type column to timetable_slots...");
  try {
    await db.run(sql`ALTER TABLE timetable_slots ADD COLUMN entry_type TEXT NOT NULL DEFAULT 'NORMAL_CLASS'`);
    console.log("Migration SUCCESS: Column entry_type added.");
  } catch (e: any) {
    if (e.message?.includes("duplicate column name")) {
      console.log("Column entry_type already exists. Skipping.");
    } else {
      throw e;
    }
  }
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Migration failed:", err);
    process.exit(1);
  });
