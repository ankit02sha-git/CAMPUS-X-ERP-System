import { db } from "./index";
import { events, eventRegistrations } from "./schema";
import { eq, or, like, sql } from "drizzle-orm";

async function mergeAagatRecords() {
  console.log("=== Merging & Deduplicating AAGAT / Freshers Events ===");

  const all = await db.select().from(events);
  const matches = all.filter((e) => {
    const t = e.title.toLowerCase();
    const d = (e.description || "").toLowerCase();
    const s = (e.shortDescription || "").toLowerCase();
    return t.includes("aagat") || t.includes("fresher") || d.includes("aagat") || s.includes("aagat");
  });

  console.log(`Found ${matches.length} matching record(s) in DB.`);

  let canonicalId: string;

  if (matches.length === 0) {
    // Insert new canonical record
    canonicalId = crypto.randomUUID();
    await db.insert(events).values({
      id: canonicalId,
      title: "AAGAT",
      slug: "aagat-cultural-welcome-2026",
      shortDescription: "Official Cultural Welcome & Freshers celebration for 1st-year students.",
      description: "Study Hall College presents AAGAT — the official Cultural Welcome and Freshers Party 2026. A vibrant celebration featuring music, dance, student titles, and talent showcases.",
      date: "2026-10-01",
      startDate: "2026-10-01",
      endDate: "2026-10-01",
      datePrecision: "EXACT_DATE",
      startTime: "11:00 AM",
      endTime: "04:00 PM",
      venue: "Study Hall College Main Auditorium",
      location: "Study Hall College Main Auditorium",
      category: "CULTURAL",
      featured: true,
      registrationEnabled: true,
      sourceType: "USER_SUPPLIED",
      sourceUrl: "https://www.studyhallcollege.org/",
      verificationStatus: "VERIFIED",
      eventStatus: "UPCOMING",
      published: true,
      status: "PUBLISHED",
    });
    console.log(`Created new canonical AAGAT event record with ID: ${canonicalId}`);
  } else {
    // Pick the primary one (prefer one with title AAGAT or the first match)
    const primary = matches.find((m) => m.title === "AAGAT") || matches[0];
    canonicalId = primary.id;

    // Update primary record to exact canonical details
    await db
      .update(events)
      .set({
        title: "AAGAT",
        slug: "aagat-cultural-welcome-2026",
        shortDescription: "Official Cultural Welcome & Freshers celebration for 1st-year students.",
        description: "Study Hall College presents AAGAT — the official Cultural Welcome and Freshers Party 2026. A vibrant celebration featuring music, dance, student titles, and talent showcases.",
        date: "2026-10-01",
        startDate: "2026-10-01",
        endDate: "2026-10-01",
        datePrecision: "EXACT_DATE",
        startTime: "11:00 AM",
        endTime: "04:00 PM",
        venue: "Study Hall College Main Auditorium",
        location: "Study Hall College Main Auditorium",
        category: "CULTURAL",
        featured: true,
        registrationEnabled: true,
        sourceType: "USER_SUPPLIED",
        sourceUrl: "https://www.studyhallcollege.org/",
        verificationStatus: "VERIFIED",
        eventStatus: "UPCOMING",
        published: true,
        status: "PUBLISHED",
      })
      .where(eq(events.id, canonicalId));

    console.log(`Updated primary canonical event record (ID: ${canonicalId}) to title 'AAGAT'.`);

    // Remove duplicates and re-assign registrations
    const duplicates = matches.filter((m) => m.id !== canonicalId);
    for (const dup of duplicates) {
      console.log(`Deduplicating duplicate event record: ID=${dup.id}, Title='${dup.title}'`);
      
      // Reassign registrations to canonical ID before deletion
      await db
        .update(eventRegistrations)
        .set({ eventId: canonicalId })
        .where(eq(eventRegistrations.eventId, dup.id));

      // Delete duplicate event record
      await db.delete(events).where(eq(events.id, dup.id));
    }
  }

  // Final check
  const finalCheck = await db.select().from(events);
  const remaining = finalCheck.filter((e) => {
    const t = e.title.toLowerCase();
    return t.includes("aagat") || t.includes("fresher");
  });

  console.log(`\nVerification: Remaining AAGAT/Freshers events in DB: ${remaining.length}`);
  remaining.forEach((r) => {
    console.log(`  - ID: ${r.id}, Title: ${r.title}, Date: ${r.date}`);
  });
}

mergeAagatRecords()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("Merge error:", e);
    process.exit(1);
  });
