import { db } from "./index";
import { eq } from "drizzle-orm";
import { courses, timetableSlots, timetablesMaster } from "./schema";

export async function seedBca5Timetable() {
  console.log("Seeding BCA 5th Semester Official Timetable...");

  // Find or insert BCA course
  let [bca] = await db.select().from(courses).where(eq(courses.code, "BCA")).limit(1);
  if (!bca) {
    [bca] = await db
      .insert(courses)
      .values({ code: "BCA", name: "Bachelor of Computer Applications", semesters: 6 })
      .returning();
  }

  // Delete existing master timetable for BCA Sem 5 if re-seeding
  const existingMaster = await db
    .select()
    .from(timetablesMaster)
    .where(eq(timetablesMaster.courseId, bca.id))
    .then((rows) => rows.find((r) => r.semester === 5));

  let masterId = existingMaster?.id;

  if (!existingMaster) {
    const [tm] = await db
      .insert(timetablesMaster)
      .values({
        courseId: bca.id,
        semester: 5,
        academicYear: "3rd Year",
        section: "A",
        title: "BCA Vth SEMESTER",
        effectiveDate: "20th July, 2026",
        classAdvisor: "Mr Izhar Ahmad",
        published: true,
      })
      .returning();
    masterId = tm.id;
  } else {
    // Update header info
    await db
      .update(timetablesMaster)
      .set({
        title: "BCA Vth SEMESTER",
        effectiveDate: "20th July, 2026",
        classAdvisor: "Mr Izhar Ahmad",
        published: true,
      })
      .where(eq(timetablesMaster.id, masterId!));

    // Clear old slots for this master ID to replace cleanly
    await db.delete(timetableSlots).where(eq(timetableSlots.timetableId, masterId!));
  }

  const slots = [
    // MONDAY
    { day: "MONDAY", startPeriod: 1, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "AI" },
    { day: "MONDAY", startPeriod: 2, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "CL&IS" },
    { day: "MONDAY", startPeriod: 3, spanPeriods: 1, facultyName: "Dr Mahendra", subjectName: "EEP-PDP(BCA + BAJMC)" },
    { day: "MONDAY", startPeriod: 4, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "CN" },
    { day: "MONDAY", startPeriod: 5, spanPeriods: 1, facultyName: "Mr Vishwajeet", subjectName: "SPORTS", colorTheme: "emerald" },
    { day: "MONDAY", startPeriod: 6, spanPeriods: 1, facultyName: "Ms. Amrita", subjectName: "LIBRARY" },

    // TUESDAY
    { day: "TUESDAY", startPeriod: 1, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "AI" },
    { day: "TUESDAY", startPeriod: 2, spanPeriods: 2, facultyName: "Mr. Izhar", subjectName: "IT-VV" }, // P2 + P3
    { day: "TUESDAY", startPeriod: 4, spanPeriods: 1, facultyName: "Dr Naval", subjectName: "EEP-Aptitude" },
    { day: "TUESDAY", startPeriod: 5, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "CN" },
    { day: "TUESDAY", startPeriod: 6, spanPeriods: 1, facultyName: "Mr Prashant", subjectName: "DA" },

    // WEDNESDAY
    { day: "WEDNESDAY", startPeriod: 1, spanPeriods: 1, facultyName: "Mr. Shubham", subjectName: "THEATRE", colorTheme: "amber" },
    { day: "WEDNESDAY", startPeriod: 2, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "AI" },
    { day: "WEDNESDAY", startPeriod: 3, spanPeriods: 1, facultyName: "Dr Mahendra", subjectName: "EEP-PDP(BCA + BAJMC)" },
    { day: "WEDNESDAY", startPeriod: 4, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "Unix" },
    { day: "WEDNESDAY", startPeriod: 5, spanPeriods: 1, facultyName: "Dr Naval", subjectName: "CD" },
    { day: "WEDNESDAY", startPeriod: 6, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "CL&IS" },

    // THURSDAY
    { day: "THURSDAY", startPeriod: 1, spanPeriods: 2, facultyName: "Mr. Prashant Kushwaha", subjectName: "DA Lab" }, // P1 + P2
    { day: "THURSDAY", startPeriod: 3, spanPeriods: 1, facultyName: "Mariya Maam", subjectName: "Life Plan" },
    { day: "THURSDAY", startPeriod: 4, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "CL&IS" },
    { day: "THURSDAY", startPeriod: 5, spanPeriods: 1, facultyName: "Mr Prashant", subjectName: "DA" },
    { day: "THURSDAY", startPeriod: 6, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "Unix" },

    // FRIDAY
    { day: "FRIDAY", startPeriod: 1, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "CN" },
    { day: "FRIDAY", startPeriod: 2, spanPeriods: 1, facultyName: "Mr Prashant", subjectName: "DA" },
    { day: "FRIDAY", startPeriod: 3, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "Unix" },
    {
      day: "FRIDAY",
      startPeriod: 4,
      spanPeriods: 3, // P4 + P5 + P6
      isSpecialActivity: true,
      activityTitle: "Club Activity",
      activityDescription: "[students will join their respective clubs]",
      colorTheme: "purple",
    },

    // SATURDAY
    { day: "SATURDAY", startPeriod: 1, spanPeriods: 1, facultyName: "Mr Prashant", subjectName: "DA" },
    { day: "SATURDAY", startPeriod: 2, spanPeriods: 1, facultyName: "Mr Izhar", subjectName: "CL&IS" },
    { day: "SATURDAY", startPeriod: 3, spanPeriods: 1, facultyName: "Mrs Archana", subjectName: "CN" },
    {
      day: "SATURDAY",
      startPeriod: 4,
      spanPeriods: 3, // P4 + P5 + P6
      facultyName: "Mr. Prashant / Mr Izhar",
      subjectName: "Project Phase-I",
      isSpecialActivity: true,
      activityTitle: "Project Phase-I",
      colorTheme: "blue",
    },
  ];

  for (const s of slots) {
    await db.insert(timetableSlots).values({
      timetableId: masterId!,
      day: s.day as "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY",
      startPeriod: s.startPeriod,
      spanPeriods: s.spanPeriods,
      facultyName: s.facultyName || null,
      subjectName: s.subjectName || null,
      isSpecialActivity: Boolean(s.isSpecialActivity),
      activityTitle: s.activityTitle || null,
      activityDescription: s.activityDescription || null,
      colorTheme: s.colorTheme || null,
    });
  }

  console.log("BCA 5th Semester Timetable Seeded Successfully!");
}

if (require.main === module) {
  seedBca5Timetable()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Timetable seed failed:", err);
      process.exit(1);
    });
}
