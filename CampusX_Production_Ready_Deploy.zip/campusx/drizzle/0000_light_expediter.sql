CREATE TABLE `academic_calendar_events` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`category` text DEFAULT 'COLLEGE_DATE' NOT NULL,
	`start_date` text NOT NULL,
	`end_date` text,
	`description` text,
	`course_id` text,
	`department` text,
	`is_global` integer DEFAULT true NOT NULL,
	`created_by_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`created_by_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `ace_dates_idx` ON `academic_calendar_events` (`start_date`,`is_global`);--> statement-breakpoint
CREATE TABLE `announcement_reads` (
	`announcement_id` text NOT NULL,
	`user_id` text NOT NULL,
	`read_at` integer NOT NULL,
	PRIMARY KEY(`announcement_id`, `user_id`),
	FOREIGN KEY (`announcement_id`) REFERENCES `announcements`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `announcements` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`content` text NOT NULL,
	`category` text DEFAULT 'General' NOT NULL,
	`priority` text DEFAULT 'NORMAL' NOT NULL,
	`published` integer DEFAULT false NOT NULL,
	`published_at` integer,
	`created_by_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`created_by_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `ann_pub_idx` ON `announcements` (`published`,`published_at`);--> statement-breakpoint
CREATE TABLE `assignment_submissions` (
	`id` text PRIMARY KEY NOT NULL,
	`assignment_id` text NOT NULL,
	`user_id` text NOT NULL,
	`status` text DEFAULT 'PENDING' NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`assignment_id`) REFERENCES `assignments`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `asub_unique` ON `assignment_submissions` (`assignment_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `assignments` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`subject` text NOT NULL,
	`due_date` integer NOT NULL,
	`attachment_url` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `asg_lookup_idx` ON `assignments` (`course_id`,`semester`,`due_date`);--> statement-breakpoint
CREATE TABLE `attendance_records` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`user_id` text NOT NULL,
	`student_master_id` text,
	`status` text DEFAULT 'PRESENT' NOT NULL,
	`remarks` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `attendance_sessions`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`student_master_id`) REFERENCES `students_master`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `attr_session_user_idx` ON `attendance_records` (`session_id`,`user_id`);--> statement-breakpoint
CREATE INDEX `attr_user_idx` ON `attendance_records` (`user_id`);--> statement-breakpoint
CREATE TABLE `attendance_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`section` text DEFAULT 'A' NOT NULL,
	`subject_id` text NOT NULL,
	`date` text NOT NULL,
	`start_time` text,
	`faculty_id` text,
	`total_students` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`faculty_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `atts_course_sem_sub_date_idx` ON `attendance_sessions` (`course_id`,`semester`,`section`,`subject_id`,`date`);--> statement-breakpoint
CREATE TABLE `campus_directory` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`category` text DEFAULT 'DEPARTMENT' NOT NULL,
	`building` text DEFAULT 'Main Block' NOT NULL,
	`floor` text,
	`room_number` text,
	`description` text,
	`opening_hours` text,
	`image_url` text,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `cd_cat_idx` ON `campus_directory` (`category`,`active`);--> statement-breakpoint
CREATE TABLE `canteen_items` (
	`id` text PRIMARY KEY NOT NULL,
	`date` text NOT NULL,
	`meal` text NOT NULL,
	`name` text NOT NULL,
	`price` integer NOT NULL,
	`available` integer DEFAULT true NOT NULL,
	`image_url` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `canteen_date_idx` ON `canteen_items` (`date`,`meal`);--> statement-breakpoint
CREATE TABLE `courses` (
	`id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`description` text,
	`semesters` integer DEFAULT 6 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `courses_code_unique` ON `courses` (`code`);--> statement-breakpoint
CREATE TABLE `event_registrations` (
	`id` text PRIMARY KEY NOT NULL,
	`event_id` text NOT NULL,
	`user_id` text NOT NULL,
	`status` text DEFAULT 'REGISTERED' NOT NULL,
	`registered_at` integer NOT NULL,
	FOREIGN KEY (`event_id`) REFERENCES `events`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `ereg_unique_idx` ON `event_registrations` (`event_id`,`user_id`);--> statement-breakpoint
CREATE INDEX `ereg_event_idx` ON `event_registrations` (`event_id`);--> statement-breakpoint
CREATE INDEX `ereg_user_idx` ON `event_registrations` (`user_id`);--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`slug` text,
	`short_description` text,
	`description` text,
	`date` text NOT NULL,
	`start_date` text,
	`end_date` text,
	`date_precision` text DEFAULT 'EXACT_DATE' NOT NULL,
	`start_time` text,
	`end_time` text,
	`location` text,
	`venue` text,
	`category` text DEFAULT 'CULTURAL' NOT NULL,
	`image_url` text,
	`status` text DEFAULT 'PUBLISHED' NOT NULL,
	`event_status` text DEFAULT 'UPCOMING' NOT NULL,
	`featured` integer DEFAULT false NOT NULL,
	`registration_enabled` integer DEFAULT false NOT NULL,
	`registration_deadline` text,
	`registration_url` text,
	`contact_info` text,
	`organizer` text,
	`tags` text,
	`source_type` text DEFAULT 'USER_SUPPLIED' NOT NULL,
	`source_url` text,
	`verification_status` text DEFAULT 'UNVERIFIED' NOT NULL,
	`published` integer DEFAULT true NOT NULL,
	`deleted_at` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `events_date_idx` ON `events` (`date`,`status`);--> statement-breakpoint
CREATE TABLE `exam_subjects` (
	`id` text PRIMARY KEY NOT NULL,
	`exam_id` text NOT NULL,
	`subject_id` text,
	`subject_name` text NOT NULL,
	`exam_date` text NOT NULL,
	`start_time` text NOT NULL,
	`end_time` text NOT NULL,
	`venue` text,
	`max_marks` integer DEFAULT 100 NOT NULL,
	`pass_marks` integer DEFAULT 40 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `esub_exam_idx` ON `exam_subjects` (`exam_id`);--> statement-breakpoint
CREATE TABLE `exams` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`exam_type` text DEFAULT 'INTERNAL' NOT NULL,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`academic_year` text,
	`section` text,
	`start_date` text NOT NULL,
	`end_date` text NOT NULL,
	`instructions` text,
	`published` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `exams_course_sem_idx` ON `exams` (`course_id`,`semester`,`published`);--> statement-breakpoint
CREATE TABLE `faculty_directory` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`department` text NOT NULL,
	`designation` text NOT NULL,
	`qualification` text,
	`subjects_taught` text,
	`email` text,
	`office_room` text,
	`avatar_url` text,
	`order` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `fac_dept_idx` ON `faculty_directory` (`department`,`active`);--> statement-breakpoint
CREATE TABLE `fee_due_rules` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`academic_session` text DEFAULT '2026-27' NOT NULL,
	`due_date` text DEFAULT '2026-10-15' NOT NULL,
	`fine_type` text DEFAULT 'PER_DAY' NOT NULL,
	`fine_value` integer DEFAULT 50 NOT NULL,
	`max_fine` integer DEFAULT 2500,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `fdr_course_session_idx` ON `fee_due_rules` (`course_id`,`academic_session`);--> statement-breakpoint
CREATE TABLE `fee_payments` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`fee_structure_id` text NOT NULL,
	`amount` integer NOT NULL,
	`fee_type` text DEFAULT 'TUITION_FEE' NOT NULL,
	`payment_date` text NOT NULL,
	`payment_method` text DEFAULT 'UPI' NOT NULL,
	`transaction_id` text NOT NULL,
	`receipt_number` text NOT NULL,
	`status` text DEFAULT 'PAID' NOT NULL,
	`notes` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`student_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`fee_structure_id`) REFERENCES `fee_structures`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `fee_payments_transaction_id_unique` ON `fee_payments` (`transaction_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `fee_payments_receipt_number_unique` ON `fee_payments` (`receipt_number`);--> statement-breakpoint
CREATE INDEX `fp_student_idx` ON `fee_payments` (`student_id`,`payment_date`);--> statement-breakpoint
CREATE INDEX `fp_txn_idx` ON `fee_payments` (`transaction_id`);--> statement-breakpoint
CREATE INDEX `fp_receipt_idx` ON `fee_payments` (`receipt_number`);--> statement-breakpoint
CREATE TABLE `fee_structures` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`academic_session` text DEFAULT '2026-27' NOT NULL,
	`admission_fee` integer DEFAULT 2000 NOT NULL,
	`tuition_fee` integer NOT NULL,
	`student_development_fee` integer DEFAULT 1000 NOT NULL,
	`university_exam_fee` text DEFAULT 'AS_PER_UNIVERSITY' NOT NULL,
	`source_note` text DEFAULT 'Fee structure reference: Study Hall College official website — Fee Structure 2026-27.',
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `fs_course_session_idx` ON `fee_structures` (`course_id`,`academic_session`);--> statement-breakpoint
CREATE TABLE `grievance_tickets` (
	`id` text PRIMARY KEY NOT NULL,
	`ticket_number` text NOT NULL,
	`category` text DEFAULT 'ACADEMIC' NOT NULL,
	`subject` text NOT NULL,
	`description` text NOT NULL,
	`user_id` text NOT NULL,
	`status` text DEFAULT 'OPEN' NOT NULL,
	`priority` text DEFAULT 'NORMAL' NOT NULL,
	`admin_response` text,
	`resolved_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `grievance_tickets_ticket_number_unique` ON `grievance_tickets` (`ticket_number`);--> statement-breakpoint
CREATE INDEX `gt_user_idx` ON `grievance_tickets` (`user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `gt_status_idx` ON `grievance_tickets` (`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_categories` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`slug` text NOT NULL,
	`order` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `lost_categories_name_unique` ON `lost_categories` (`name`);--> statement-breakpoint
CREATE UNIQUE INDEX `lost_categories_slug_unique` ON `lost_categories` (`slug`);--> statement-breakpoint
CREATE TABLE `lost_images` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`url` text NOT NULL,
	`order` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `li_post_idx` ON `lost_images` (`post_id`);--> statement-breakpoint
CREATE TABLE `lost_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`thread_id` text NOT NULL,
	`sender_id` text NOT NULL,
	`body` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`thread_id`) REFERENCES `lost_threads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lm_thread_idx` ON `lost_messages` (`thread_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_posts` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text DEFAULT 'LOST' NOT NULL,
	`status` text DEFAULT 'LOST' NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`details` text,
	`category_id` text NOT NULL,
	`location` text NOT NULL,
	`occurred_on` text NOT NULL,
	`approx_time` text,
	`contact_pref` text DEFAULT 'IN_APP' NOT NULL,
	`hidden` integer DEFAULT false NOT NULL,
	`author_id` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`category_id`) REFERENCES `lost_categories`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lp_feed_idx` ON `lost_posts` (`kind`,`status`,`hidden`,`created_at`);--> statement-breakpoint
CREATE INDEX `lp_cat_idx` ON `lost_posts` (`category_id`);--> statement-breakpoint
CREATE INDEX `lp_loc_idx` ON `lost_posts` (`location`);--> statement-breakpoint
CREATE INDEX `lp_author_idx` ON `lost_posts` (`author_id`);--> statement-breakpoint
CREATE TABLE `lost_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`reporter_id` text NOT NULL,
	`reason` text NOT NULL,
	`status` text DEFAULT 'OPEN' NOT NULL,
	`resolution` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lrep_status_idx` ON `lost_reports` (`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_responses` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`user_id` text NOT NULL,
	`message` text NOT NULL,
	`found_at` text NOT NULL,
	`found_on` text NOT NULL,
	`image_url` text,
	`contact_info` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `lr_post_idx` ON `lost_responses` (`post_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `lost_threads` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`owner_id` text NOT NULL,
	`other_id` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`post_id`) REFERENCES `lost_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`other_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `lt_unique` ON `lost_threads` (`post_id`,`owner_id`,`other_id`);--> statement-breakpoint
CREATE INDEX `lt_owner_idx` ON `lost_threads` (`owner_id`);--> statement-breakpoint
CREATE INDEX `lt_other_idx` ON `lost_threads` (`other_id`);--> statement-breakpoint
CREATE TABLE `notes` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`subject` text NOT NULL,
	`file_url` text NOT NULL,
	`file_name` text,
	`file_type` text,
	`uploaded_by_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`uploaded_by_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `notes_lookup_idx` ON `notes` (`course_id`,`semester`,`subject`);--> statement-breakpoint
CREATE INDEX `notes_title_idx` ON `notes` (`title`);--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`type` text NOT NULL,
	`title` text NOT NULL,
	`body` text,
	`link` text,
	`read` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `notif_user_idx` ON `notifications` (`user_id`,`read`,`created_at`);--> statement-breakpoint
CREATE TABLE `otps` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`mobile` text NOT NULL,
	`otp_hash` text NOT NULL,
	`raw_otp_for_dev` text,
	`type` text NOT NULL,
	`expires_at` integer NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`used` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `otps_lookup_idx` ON `otps` (`student_id`,`type`,`used`);--> statement-breakpoint
CREATE TABLE `student_results` (
	`id` text PRIMARY KEY NOT NULL,
	`exam_id` text NOT NULL,
	`subject_id` text,
	`user_id` text NOT NULL,
	`student_master_id` text,
	`internal_marks` integer,
	`external_marks` integer,
	`practical_marks` integer,
	`total_marks` integer NOT NULL,
	`max_marks` integer DEFAULT 100 NOT NULL,
	`grade` text,
	`result_status` text DEFAULT 'PASS' NOT NULL,
	`remarks` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`student_master_id`) REFERENCES `students_master`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `sr_exam_user_subj_idx` ON `student_results` (`exam_id`,`user_id`,`subject_id`);--> statement-breakpoint
CREATE INDEX `sr_user_idx` ON `student_results` (`user_id`);--> statement-breakpoint
CREATE TABLE `student_stats` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`attendance_pct` integer DEFAULT 0 NOT NULL,
	`study_streak` integer DEFAULT 0 NOT NULL,
	`progress_pct` integer DEFAULT 0 NOT NULL,
	`is_demo` integer DEFAULT true NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `student_stats_user_id_unique` ON `student_stats` (`user_id`);--> statement-breakpoint
CREATE TABLE `students_master` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`full_name` text NOT NULL,
	`registered_mobile` text NOT NULL,
	`course_id` text,
	`department` text,
	`academic_year` text,
	`semester` integer,
	`section` text,
	`roll_number` text,
	`dob` text,
	`admission_session` text,
	`father_name` text,
	`mother_name` text,
	`parent_contact` text,
	`local_address` text,
	`activation_status` text DEFAULT 'NOT_ACTIVATED' NOT NULL,
	`status` text DEFAULT 'ACTIVE' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `students_master_student_id_unique` ON `students_master` (`student_id`);--> statement-breakpoint
CREATE INDEX `sm_student_id_idx` ON `students_master` (`student_id`);--> statement-breakpoint
CREATE INDEX `sm_course_idx` ON `students_master` (`course_id`,`semester`);--> statement-breakpoint
CREATE TABLE `subjects` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`credits` integer DEFAULT 3 NOT NULL,
	`faculty_name` text,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `subj_code_course_sem` ON `subjects` (`course_id`,`semester`,`code`);--> statement-breakpoint
CREATE INDEX `subj_course_sem_idx` ON `subjects` (`course_id`,`semester`);--> statement-breakpoint
CREATE TABLE `timetable_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`day` text NOT NULL,
	`start_time` text NOT NULL,
	`end_time` text NOT NULL,
	`subject` text NOT NULL,
	`faculty` text,
	`room` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `tt_lookup_idx` ON `timetable_entries` (`course_id`,`semester`,`day`);--> statement-breakpoint
CREATE TABLE `timetable_slots` (
	`id` text PRIMARY KEY NOT NULL,
	`timetable_id` text NOT NULL,
	`day` text NOT NULL,
	`start_period` integer NOT NULL,
	`span_periods` integer DEFAULT 1 NOT NULL,
	`entry_type` text DEFAULT 'NORMAL_CLASS' NOT NULL,
	`faculty_name` text,
	`subject_name` text,
	`is_special_activity` integer DEFAULT false NOT NULL,
	`activity_title` text,
	`activity_description` text,
	`color_theme` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`timetable_id`) REFERENCES `timetables_master`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `tts_lookup_idx` ON `timetable_slots` (`timetable_id`,`day`,`start_period`);--> statement-breakpoint
CREATE TABLE `timetables_master` (
	`id` text PRIMARY KEY NOT NULL,
	`course_id` text NOT NULL,
	`semester` integer NOT NULL,
	`academic_year` text,
	`section` text,
	`title` text DEFAULT 'CLASS TIME TABLE' NOT NULL,
	`effective_date` text DEFAULT '20th July, 2026' NOT NULL,
	`class_advisor` text,
	`published` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `ttm_course_sem_idx` ON `timetables_master` (`course_id`,`semester`,`published`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`role` text DEFAULT 'STUDENT' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`course_id` text,
	`semester` integer,
	`student_id` text,
	`show_student_id` integer DEFAULT false NOT NULL,
	`image` text,
	`is_demo` integer DEFAULT false NOT NULL,
	`registered_mobile` text,
	`department` text,
	`academic_year` text,
	`section` text,
	`roll_number` text,
	`dob` text,
	`father_name` text,
	`mother_name` text,
	`parent_contact` text,
	`local_address` text,
	`activation_status` text DEFAULT 'ACTIVATED' NOT NULL,
	`student_master_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`student_master_id`) REFERENCES `students_master`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_email_unique` ON `users` (`email`);--> statement-breakpoint
CREATE UNIQUE INDEX `users_student_id_unique` ON `users` (`student_id`);--> statement-breakpoint
CREATE INDEX `users_role_idx` ON `users` (`role`);--> statement-breakpoint
CREATE INDEX `users_course_sem_idx` ON `users` (`course_id`,`semester`);--> statement-breakpoint
CREATE INDEX `users_name_idx` ON `users` (`name`);--> statement-breakpoint
CREATE INDEX `users_student_id_idx` ON `users` (`student_id`);